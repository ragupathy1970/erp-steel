﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 02-03-2018
' Time: 14:57
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'

Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Imports VST.Constants




Partial Public Class testReport
    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
    End Sub
    Dim cryRpt As New ReportDocument

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        cryRpt.Load("c:\vst\report\customerr.rpt")
        Dim crParameterDiscreteValue As New ParameterDiscreteValue
        Dim param1Fileds As New CrystalDecisions.Shared.ParameterFields
        Dim param1Field As New CrystalDecisions.Shared.ParameterField
        Dim param1val As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim param2Field As New CrystalDecisions.Shared.ParameterField
        Dim param2val As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim param3Field As New CrystalDecisions.Shared.ParameterField
        Dim param3val As New CrystalDecisions.Shared.ParameterDiscreteValue
        Dim param4Field As New CrystalDecisions.Shared.ParameterField
        Dim param4val As New CrystalDecisions.Shared.ParameterDiscreteValue

        param1Field.Name = "gCompanyName"
        param1val.Value = gCompanyName
        param1Field.CurrentValues.Add(param1val)
        param1Fileds.Add(param1Field) ' To add parameter in parameterslist

        param2Field.Name = "gAddress"
        param2val.Value = gCompanyAdd1
        param2Field.CurrentValues.Add(param2val)
        param1Fileds.Add(param2Field)

        param3Field.Name = "gadd2"
        param3val.Value = gcompanyAdd2
        param3Field.CurrentValues.Add(param3val)
        param1Fileds.Add(param3Field)

        param4Field.Name = "gcity"
        param4val.Value = gcompanyCity
        param4Field.CurrentValues.Add(param4val)
        param1Fileds.Add(param4Field)

        CrystalReportViewer1.ParameterFieldInfo = param1Fileds 'to pass parameter inf.to CRV
        CrystalReportViewer1.ReportSource = cryRpt
        CrystalReportViewer1.Refresh()
    End Sub


    Private Sub cmdPdf_Click(sender As Object, e As EventArgs) Handles cmdPdf.Click
        Try
            Dim CrExportOptions As ExportOptions
            Dim CrDiskFileDestinationOptions As New DiskFileDestinationOptions()
            Dim CrFormatTypeOptions As New PdfRtfWordFormatOptions()
            CrDiskFileDestinationOptions.DiskFileName = "c:\printouts\crystalExport.pdf"
            CrExportOptions = cryRpt.ExportOptions
            With CrExportOptions
                .ExportDestinationType = ExportDestinationType.DiskFile
                .ExportFormatType = ExportFormatType.PortableDocFormat
                .DestinationOptions = CrDiskFileDestinationOptions
                .FormatOptions = CrFormatTypeOptions
            End With
            cryRpt.Export()
            Diagnostics.Process.Start("c:\printouts\crystalExport.pdf")

        Catch ex As Exception
            MsgBox(ex.ToString)
        End Try
    End Sub
End Class
