﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:32
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Windows.Forms
Public Class Constants
	
	Public Enum ScreenMode
		Add = 1
		Edit = 2
		Delete = 3
		Cancel = 4
	End Enum
	
	Public Enum Colors
		Blue = 1 'ok button
		Red = 2  ' cancel and exit button
		Green = 3 ' save button
		Yellow = 4
		Orange = 5 'edit button
	End Enum
	

	Public Shared gCompanyName As String = ""
    Public Shared gCompanyShortName As String
    Public Shared gCompanyAdd1 As String = ""
    Public Shared gcompanyAdd2 As String = ""
    Public Shared gcompanyCity As String = ""

    Public Shared gUserName As String 
	Public shared gPassword As String 
	Public Shared gUserId As Integer = 0
	Public Shared gSysDate As Date
	Public Shared gSysTime As Integer = 0
    Public Shared gVersion As String

End Class
