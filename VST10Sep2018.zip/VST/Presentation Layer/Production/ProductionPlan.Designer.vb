﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 07-02-2018
' Time: 10:35
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class ProductionPlan
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.grpHeader = New System.Windows.Forms.GroupBox()
        Me.txtPlanNo = New System.Windows.Forms.TextBox()
        Me.cmbMonth = New System.Windows.Forms.ComboBox()
        Me.DtPlan = New System.Windows.Forms.DateTimePicker()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.groupBox1 = New System.Windows.Forms.GroupBox()
        Me.lvwProductionPlan = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colOrderNo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colProdQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPlanQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtTotalPlanQty = New System.Windows.Forms.TextBox()
        Me.grpEntry = New System.Windows.Forms.GroupBox()
        Me.txtOrderNo = New System.Windows.Forms.TextBox()
        Me.txtItemId = New System.Windows.Forms.TextBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.cmdAddItem = New System.Windows.Forms.Button()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpHeader.SuspendLayout()
        Me.groupBox1.SuspendLayout()
        Me.grpEntry.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpHeader
        '
        Me.grpHeader.Controls.Add(Me.txtPlanNo)
        Me.grpHeader.Controls.Add(Me.cmbMonth)
        Me.grpHeader.Controls.Add(Me.DtPlan)
        Me.grpHeader.Controls.Add(Me.label3)
        Me.grpHeader.Controls.Add(Me.label2)
        Me.grpHeader.Controls.Add(Me.label1)
        Me.grpHeader.Location = New System.Drawing.Point(13, 24)
        Me.grpHeader.Name = "grpHeader"
        Me.grpHeader.Size = New System.Drawing.Size(857, 105)
        Me.grpHeader.TabIndex = 7
        Me.grpHeader.TabStop = False
        '
        'txtPlanNo
        '
        Me.txtPlanNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPlanNo.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txtPlanNo.Location = New System.Drawing.Point(78, 28)
        Me.txtPlanNo.Name = "txtPlanNo"
        Me.txtPlanNo.Size = New System.Drawing.Size(87, 22)
        Me.txtPlanNo.TabIndex = 5
        '
        'cmbMonth
        '
        Me.cmbMonth.FormattingEnabled = True
        Me.cmbMonth.Location = New System.Drawing.Point(716, 57)
        Me.cmbMonth.Name = "cmbMonth"
        Me.cmbMonth.Size = New System.Drawing.Size(99, 24)
        Me.cmbMonth.TabIndex = 4
        '
        'DtPlan
        '
        Me.DtPlan.Cursor = System.Windows.Forms.Cursors.Default
        Me.DtPlan.CustomFormat = "dd-MMM-yyyy"
        Me.DtPlan.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DtPlan.Location = New System.Drawing.Point(716, 19)
        Me.DtPlan.Name = "DtPlan"
        Me.DtPlan.Size = New System.Drawing.Size(99, 22)
        Me.DtPlan.TabIndex = 2
        Me.DtPlan.Value = New Date(2018, 2, 8, 9, 52, 24, 0)
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(593, 63)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(117, 16)
        Me.label3.TabIndex = 2
        Me.label3.Text = "Plan for the Month"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(637, 22)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(73, 19)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Plan Date"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(24, 30)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(52, 19)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Plan ID"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.lvwProductionPlan)
        Me.groupBox1.Controls.Add(Me.label9)
        Me.groupBox1.Controls.Add(Me.txtTotalPlanQty)
        Me.groupBox1.Location = New System.Drawing.Point(13, 193)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(857, 205)
        Me.groupBox1.TabIndex = 0
        Me.groupBox1.TabStop = False
        '
        'lvwProductionPlan
        '
        Me.lvwProductionPlan.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwProductionPlan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwProductionPlan.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colOrderNo, Me.colItemid, Me.colDescription, Me.colUom, Me.colQty, Me.colProdQty, Me.colPlanQty, Me.colSlnoKey, Me.colUomKey})
        Me.lvwProductionPlan.FullRowSelect = True
        Me.lvwProductionPlan.GridLines = True
        Me.lvwProductionPlan.Location = New System.Drawing.Point(14, 26)
        Me.lvwProductionPlan.Name = "lvwProductionPlan"
        Me.lvwProductionPlan.Size = New System.Drawing.Size(828, 132)
        Me.lvwProductionPlan.TabIndex = 20
        Me.lvwProductionPlan.UseCompatibleStateImageBehavior = False
        Me.lvwProductionPlan.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 46
        '
        'colOrderNo
        '
        Me.colOrderNo.Text = "Order No."
        Me.colOrderNo.Width = 69
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 82
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 288
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Order Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colQty.Width = 100
        '
        'colProdQty
        '
        Me.colProdQty.Text = "Produced Qty"
        Me.colProdQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colProdQty.Width = 120
        '
        'colPlanQty
        '
        Me.colPlanQty.Text = "Plan Qty"
        Me.colPlanQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colPlanQty.Width = 120
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = ""
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = ""
        Me.colUomKey.Width = 0
        '
        'label9
        '
        Me.label9.BackColor = System.Drawing.Color.Transparent
        Me.label9.Location = New System.Drawing.Point(649, 166)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(72, 15)
        Me.label9.TabIndex = 19
        Me.label9.Text = "Total"
        '
        'txtTotalPlanQty
        '
        Me.txtTotalPlanQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalPlanQty.Location = New System.Drawing.Point(723, 163)
        Me.txtTotalPlanQty.Name = "txtTotalPlanQty"
        Me.txtTotalPlanQty.Size = New System.Drawing.Size(100, 22)
        Me.txtTotalPlanQty.TabIndex = 18
        Me.txtTotalPlanQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'grpEntry
        '
        Me.grpEntry.Controls.Add(Me.txtOrderNo)
        Me.grpEntry.Controls.Add(Me.txtItemId)
        Me.grpEntry.Controls.Add(Me.cmdAdd)
        Me.grpEntry.Controls.Add(Me.cmbUom)
        Me.grpEntry.Controls.Add(Me.label8)
        Me.grpEntry.Controls.Add(Me.label7)
        Me.grpEntry.Controls.Add(Me.label6)
        Me.grpEntry.Controls.Add(Me.label5)
        Me.grpEntry.Controls.Add(Me.label4)
        Me.grpEntry.Controls.Add(Me.txtQty)
        Me.grpEntry.Controls.Add(Me.cmdAddItem)
        Me.grpEntry.Controls.Add(Me.txtDescription)
        Me.grpEntry.Location = New System.Drawing.Point(13, 135)
        Me.grpEntry.Name = "grpEntry"
        Me.grpEntry.Size = New System.Drawing.Size(857, 52)
        Me.grpEntry.TabIndex = 9
        Me.grpEntry.TabStop = False
        '
        'txtOrderNo
        '
        Me.txtOrderNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOrderNo.Location = New System.Drawing.Point(16, 20)
        Me.txtOrderNo.Name = "txtOrderNo"
        Me.txtOrderNo.Size = New System.Drawing.Size(75, 22)
        Me.txtOrderNo.TabIndex = 15
        '
        'txtItemId
        '
        Me.txtItemId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemId.Location = New System.Drawing.Point(100, 20)
        Me.txtItemId.Name = "txtItemId"
        Me.txtItemId.Size = New System.Drawing.Size(75, 22)
        Me.txtItemId.TabIndex = 14
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(738, 10)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 13
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'cmbUom
        '
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(565, 21)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(59, 24)
        Me.cmbUom.TabIndex = 6
        '
        'label8
        '
        Me.label8.BackColor = System.Drawing.Color.Transparent
        Me.label8.Location = New System.Drawing.Point(562, 6)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(38, 15)
        Me.label8.TabIndex = 12
        Me.label8.Text = "UOM"
        '
        'label7
        '
        Me.label7.BackColor = System.Drawing.Color.Transparent
        Me.label7.Location = New System.Drawing.Point(15, 3)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(72, 15)
        Me.label7.TabIndex = 10
        Me.label7.Text = "Order No"
        '
        'label6
        '
        Me.label6.BackColor = System.Drawing.Color.Transparent
        Me.label6.Location = New System.Drawing.Point(633, 6)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(72, 15)
        Me.label6.TabIndex = 8
        Me.label6.Text = "Quantity"
        '
        'label5
        '
        Me.label5.BackColor = System.Drawing.Color.Transparent
        Me.label5.Location = New System.Drawing.Point(208, 5)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(77, 15)
        Me.label5.TabIndex = 7
        Me.label5.Text = "Description"
        '
        'label4
        '
        Me.label4.BackColor = System.Drawing.Color.Transparent
        Me.label4.Location = New System.Drawing.Point(103, 3)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(72, 15)
        Me.label4.TabIndex = 6
        Me.label4.Text = "Item"
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(637, 21)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(87, 22)
        Me.txtQty.TabIndex = 7
        '
        'cmdAddItem
        '
        Me.cmdAddItem.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddItem.Location = New System.Drawing.Point(182, 21)
        Me.cmdAddItem.Name = "cmdAddItem"
        Me.cmdAddItem.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddItem.TabIndex = 2
        Me.cmdAddItem.Text = "+"
        Me.cmdAddItem.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(211, 21)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(348, 22)
        Me.txtDescription.TabIndex = 1
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(570, 408)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 15
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(759, 408)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 17
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(666, 408)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 16
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(474, 408)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 14
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'ProductionPlan
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(899, 489)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpEntry)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.grpHeader)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "ProductionPlan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Production Plan"
        Me.grpHeader.ResumeLayout(False)
        Me.grpHeader.PerformLayout()
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox1.PerformLayout()
        Me.grpEntry.ResumeLayout(False)
        Me.grpEntry.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private label9 As System.Windows.Forms.Label
    Private txtTotalPlanQty As System.Windows.Forms.TextBox
    Private label8 As System.Windows.Forms.Label
    Private cmbUom As System.Windows.Forms.ComboBox
    Private label7 As System.Windows.Forms.Label
    Private label6 As System.Windows.Forms.Label
    Private label4 As System.Windows.Forms.Label
    Private label5 As System.Windows.Forms.Label
    Private txtDescription As System.Windows.Forms.TextBox
    Private cmdAddItem As System.Windows.Forms.Button
    Private txtQty As System.Windows.Forms.TextBox
    Private label1 As System.Windows.Forms.Label
    Private label2 As System.Windows.Forms.Label
    Private label3 As System.Windows.Forms.Label
    Private DtPlan As System.Windows.Forms.DateTimePicker
    Private grpEntry As System.Windows.Forms.GroupBox
    Private groupBox1 As System.Windows.Forms.GroupBox
    Private grpHeader As System.Windows.Forms.GroupBox
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents cmbMonth As System.Windows.Forms.ComboBox
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colPlanQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colProdQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colOrderNo As System.Windows.Forms.ColumnHeader
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents lvwProductionPlan As System.Windows.Forms.ListView
    Private WithEvents txtItemId As System.Windows.Forms.TextBox
    Private WithEvents txtOrderNo As System.Windows.Forms.TextBox
    Private WithEvents txtPlanNo As System.Windows.Forms.TextBox
End Class
