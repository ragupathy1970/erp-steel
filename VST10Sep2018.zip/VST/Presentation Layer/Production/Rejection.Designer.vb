﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Rejection
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpSlitEntry = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtItemId = New System.Windows.Forms.TextBox()
        Me.grpSlitTrn = New System.Windows.Forms.GroupBox()
        Me.lvwRoll = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQtyinnos = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQtyintones = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.grpSlitHdr = New System.Windows.Forms.GroupBox()
        Me.lblMachine = New System.Windows.Forms.Label()
        Me.txtMachineID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.grpShift = New System.Windows.Forms.GroupBox()
        Me.rdoShift4 = New System.Windows.Forms.RadioButton()
        Me.rdoShift3 = New System.Windows.Forms.RadioButton()
        Me.rdoShift2 = New System.Windows.Forms.RadioButton()
        Me.rdoShift1 = New System.Windows.Forms.RadioButton()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtRejectionId = New System.Windows.Forms.TextBox()
        Me.dtProduction = New System.Windows.Forms.DateTimePicker()
        Me.grpSlitEntry.SuspendLayout()
        Me.grpSlitTrn.SuspendLayout()
        Me.grpSlitHdr.SuspendLayout()
        Me.grpShift.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(514, 414)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 39
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(703, 414)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 41
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(610, 414)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 40
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(418, 413)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 38
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'grpSlitEntry
        '
        Me.grpSlitEntry.Controls.Add(Me.Label3)
        Me.grpSlitEntry.Controls.Add(Me.Label2)
        Me.grpSlitEntry.Controls.Add(Me.cmbUom)
        Me.grpSlitEntry.Controls.Add(Me.cmdAdd)
        Me.grpSlitEntry.Controls.Add(Me.Label8)
        Me.grpSlitEntry.Controls.Add(Me.txtQty)
        Me.grpSlitEntry.Controls.Add(Me.txtDescription)
        Me.grpSlitEntry.Controls.Add(Me.Label6)
        Me.grpSlitEntry.Controls.Add(Me.txtItemId)
        Me.grpSlitEntry.ForeColor = System.Drawing.SystemColors.ControlText
        Me.grpSlitEntry.Location = New System.Drawing.Point(46, 167)
        Me.grpSlitEntry.Name = "grpSlitEntry"
        Me.grpSlitEntry.Size = New System.Drawing.Size(746, 67)
        Me.grpSlitEntry.TabIndex = 37
        Me.grpSlitEntry.TabStop = False
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(528, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 19)
        Me.Label3.TabIndex = 50
        Me.Label3.Text = "Quantity"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(469, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 19)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "UOM"
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(469, 33)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(50, 24)
        Me.cmbUom.TabIndex = 48
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(647, 27)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 12
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(125, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Item Description"
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(525, 35)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(62, 22)
        Me.txtQty.TabIndex = 11
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(122, 35)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(342, 22)
        Me.txtDescription.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(29, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Item ID"
        '
        'txtItemId
        '
        Me.txtItemId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemId.Location = New System.Drawing.Point(26, 36)
        Me.txtItemId.Name = "txtItemId"
        Me.txtItemId.Size = New System.Drawing.Size(87, 22)
        Me.txtItemId.TabIndex = 8
        '
        'grpSlitTrn
        '
        Me.grpSlitTrn.Controls.Add(Me.lvwRoll)
        Me.grpSlitTrn.Location = New System.Drawing.Point(42, 246)
        Me.grpSlitTrn.Name = "grpSlitTrn"
        Me.grpSlitTrn.Size = New System.Drawing.Size(751, 165)
        Me.grpSlitTrn.TabIndex = 36
        Me.grpSlitTrn.TabStop = False
        '
        'lvwRoll
        '
        Me.lvwRoll.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwRoll.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwRoll.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colItemid, Me.colDescription, Me.colUom, Me.colQty, Me.colQtyinnos, Me.colQtyintones, Me.colSlnoKey, Me.colUomKey})
        Me.lvwRoll.FullRowSelect = True
        Me.lvwRoll.GridLines = True
        Me.lvwRoll.Location = New System.Drawing.Point(12, 17)
        Me.lvwRoll.MultiSelect = False
        Me.lvwRoll.Name = "lvwRoll"
        Me.lvwRoll.Size = New System.Drawing.Size(725, 132)
        Me.lvwRoll.TabIndex = 1
        Me.lvwRoll.UseCompatibleStateImageBehavior = False
        Me.lvwRoll.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 59
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 98
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQtyinnos
        '
        Me.colQtyinnos.Text = "Qty in Nos"
        Me.colQtyinnos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colQtyinnos.Width = 80
        '
        'colQtyintones
        '
        Me.colQtyintones.Text = "Qty in tones"
        Me.colQtyintones.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colQtyintones.Width = 80
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 0
        '
        'grpSlitHdr
        '
        Me.grpSlitHdr.Controls.Add(Me.lblMachine)
        Me.grpSlitHdr.Controls.Add(Me.txtMachineID)
        Me.grpSlitHdr.Controls.Add(Me.Label12)
        Me.grpSlitHdr.Controls.Add(Me.grpShift)
        Me.grpSlitHdr.Controls.Add(Me.label1)
        Me.grpSlitHdr.Controls.Add(Me.label7)
        Me.grpSlitHdr.Controls.Add(Me.txtRejectionId)
        Me.grpSlitHdr.Controls.Add(Me.dtProduction)
        Me.grpSlitHdr.Location = New System.Drawing.Point(49, 9)
        Me.grpSlitHdr.Name = "grpSlitHdr"
        Me.grpSlitHdr.Size = New System.Drawing.Size(744, 148)
        Me.grpSlitHdr.TabIndex = 35
        Me.grpSlitHdr.TabStop = False
        '
        'lblMachine
        '
        Me.lblMachine.Location = New System.Drawing.Point(173, 55)
        Me.lblMachine.Name = "lblMachine"
        Me.lblMachine.Size = New System.Drawing.Size(116, 13)
        Me.lblMachine.TabIndex = 42
        '
        'txtMachineID
        '
        Me.txtMachineID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMachineID.Location = New System.Drawing.Point(125, 50)
        Me.txtMachineID.Name = "txtMachineID"
        Me.txtMachineID.Size = New System.Drawing.Size(42, 22)
        Me.txtMachineID.TabIndex = 41
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(44, 52)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(77, 18)
        Me.Label12.TabIndex = 40
        Me.Label12.Text = "Machine ID"
        '
        'grpShift
        '
        Me.grpShift.Controls.Add(Me.rdoShift4)
        Me.grpShift.Controls.Add(Me.rdoShift3)
        Me.grpShift.Controls.Add(Me.rdoShift2)
        Me.grpShift.Controls.Add(Me.rdoShift1)
        Me.grpShift.Location = New System.Drawing.Point(654, 44)
        Me.grpShift.Name = "grpShift"
        Me.grpShift.Size = New System.Drawing.Size(81, 95)
        Me.grpShift.TabIndex = 7
        Me.grpShift.TabStop = False
        Me.grpShift.Text = "Shift"
        '
        'rdoShift4
        '
        Me.rdoShift4.AutoSize = True
        Me.rdoShift4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift4.Location = New System.Drawing.Point(25, 72)
        Me.rdoShift4.Name = "rdoShift4"
        Me.rdoShift4.Size = New System.Drawing.Size(35, 20)
        Me.rdoShift4.TabIndex = 3
        Me.rdoShift4.TabStop = True
        Me.rdoShift4.Text = "G"
        Me.rdoShift4.UseVisualStyleBackColor = True
        '
        'rdoShift3
        '
        Me.rdoShift3.AutoSize = True
        Me.rdoShift3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift3.Location = New System.Drawing.Point(26, 54)
        Me.rdoShift3.Name = "rdoShift3"
        Me.rdoShift3.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift3.TabIndex = 2
        Me.rdoShift3.TabStop = True
        Me.rdoShift3.Text = "C"
        Me.rdoShift3.UseVisualStyleBackColor = True
        '
        'rdoShift2
        '
        Me.rdoShift2.AutoSize = True
        Me.rdoShift2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift2.Location = New System.Drawing.Point(26, 37)
        Me.rdoShift2.Name = "rdoShift2"
        Me.rdoShift2.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift2.TabIndex = 1
        Me.rdoShift2.TabStop = True
        Me.rdoShift2.Text = "B"
        Me.rdoShift2.UseVisualStyleBackColor = True
        '
        'rdoShift1
        '
        Me.rdoShift1.AutoSize = True
        Me.rdoShift1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift1.Location = New System.Drawing.Point(26, 20)
        Me.rdoShift1.Name = "rdoShift1"
        Me.rdoShift1.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift1.TabIndex = 7
        Me.rdoShift1.TabStop = True
        Me.rdoShift1.Text = "A"
        Me.rdoShift1.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.BackColor = System.Drawing.Color.Transparent
        Me.label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.label1.Location = New System.Drawing.Point(31, 19)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(93, 19)
        Me.label1.TabIndex = 28
        Me.label1.Text = "Rejection ID"
        '
        'label7
        '
        Me.label7.BackColor = System.Drawing.Color.Transparent
        Me.label7.Location = New System.Drawing.Point(527, 21)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(103, 20)
        Me.label7.TabIndex = 27
        Me.label7.Text = "Production Date"
        '
        'txtRejectionId
        '
        Me.txtRejectionId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRejectionId.Location = New System.Drawing.Point(126, 18)
        Me.txtRejectionId.Name = "txtRejectionId"
        Me.txtRejectionId.Size = New System.Drawing.Size(87, 22)
        Me.txtRejectionId.TabIndex = 1
        '
        'dtProduction
        '
        Me.dtProduction.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtProduction.CustomFormat = "dd-MMM-yyyy"
        Me.dtProduction.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtProduction.Location = New System.Drawing.Point(634, 20)
        Me.dtProduction.Name = "dtProduction"
        Me.dtProduction.Size = New System.Drawing.Size(99, 22)
        Me.dtProduction.TabIndex = 3
        Me.dtProduction.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Rejection
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(834, 455)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpSlitEntry)
        Me.Controls.Add(Me.grpSlitTrn)
        Me.Controls.Add(Me.grpSlitHdr)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "Rejection"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Rejection Entry"
        Me.grpSlitEntry.ResumeLayout(False)
        Me.grpSlitEntry.PerformLayout()
        Me.grpSlitTrn.ResumeLayout(False)
        Me.grpSlitHdr.ResumeLayout(False)
        Me.grpSlitHdr.PerformLayout()
        Me.grpShift.ResumeLayout(False)
        Me.grpShift.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents grpSlitEntry As System.Windows.Forms.GroupBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents txtItemId As System.Windows.Forms.TextBox
    Friend WithEvents grpSlitTrn As System.Windows.Forms.GroupBox
    Private WithEvents lvwRoll As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Friend WithEvents colUom As System.Windows.Forms.ColumnHeader
    Private WithEvents colQty As System.Windows.Forms.ColumnHeader
    Friend WithEvents colQtyinnos As System.Windows.Forms.ColumnHeader
    Friend WithEvents colQtyintones As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Friend WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Friend WithEvents grpSlitHdr As System.Windows.Forms.GroupBox
    Friend WithEvents lblMachine As System.Windows.Forms.Label
    Private WithEvents txtMachineID As System.Windows.Forms.TextBox
    Private WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents grpShift As System.Windows.Forms.GroupBox
    Friend WithEvents rdoShift4 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift1 As System.Windows.Forms.RadioButton
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents txtRejectionId As System.Windows.Forms.TextBox
    Private WithEvents dtProduction As System.Windows.Forms.DateTimePicker
End Class
