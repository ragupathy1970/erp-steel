﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 26-02-2018
' Time: 14:01
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Drawing
Imports System.IO
Imports System.Drawing.Printing
Imports System.Windows.Forms

Public Partial Class Report
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
Private Sub ReadDocument() 
    Dim docName As String = "test.txt"
    Dim docPath As String = "c:\printouts\"
    docPrint.DocumentName = docName
    Dim documentContents As String
    Dim stringToPrint As String
    Dim stream As New FileStream(docPath + docName, FileMode.Open)
    Try
        Dim reader As New StreamReader(stream)
        Try
            documentContents = reader.ReadToEnd()
        Finally
            reader.Dispose()
        End Try
    Finally
        stream.Dispose()
    End Try
    stringToPrint = documentContents

End Sub


'Sub docPrint_PrintPage(ByVal sender As Object, _
'    ByVal e As PrintPageEventArgs) Handles docPrint.PrintPage
'
'    Dim charactersOnPage As Integer = 0
'    Dim linesPerPage As Integer = 0
'
'    ' Sets the value of charactersOnPage to the number of characters 
'    ' of stringToPrint that will fit within the bounds of the page.
'    e.Graphics.MeasureString(stringToPrint, Me.Font, e.MarginBounds.Size, _
'        StringFormat.GenericTypographic, charactersOnPage, linesPerPage)
'
'    ' Draws the string within the bounds of the page.
'    e.Graphics.DrawString(stringToPrint, Me.Font, Brushes.Black, _
'        e.MarginBounds, StringFormat.GenericTypographic)
'
'    ' Remove the portion of the string that has been printed.
'    stringToPrint = stringToPrint.Substring(charactersOnPage)
'
'    ' Check to see if more pages are to be printed.
'    e.HasMorePages = stringToPrint.Length > 0
'
'    ' If there are no more pages, reset the string to be printed.
'    If Not e.HasMorePages Then
'        stringToPrint = documentContents
'    End If
'
'End Sub

	
	
	Sub Button1Click(sender As Object, e As EventArgs)
    ReadDocument()
    'dlgPrintPriview.Document = PrintDocument
    dlgPrintPriview.ShowDialog()
		
	End Sub
	
	Sub CtrlPrintPreviewClick(sender As Object, e As EventArgs)
		
	End Sub
End Class
