﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 07-02-2018
' Time: 15:31
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.constants
Imports VST.Production

Partial Public Class Order
    Dim thisScreenMode As Integer
    Dim i As Integer
    Dim lvw As New ListViewItem
    Dim ds As New DataSet
    Dim ds1 As New DataSet
    Dim trans As OdbcTransaction
    Dim dblTotal As Double
    Dim strSQL As String
    Dim csno As Integer = 0
    Dim citem As Integer = 1
    Dim cuom As Integer = 3
    Dim obj As Object
    Dim cqty As Integer = 4
    Dim crate As Integer = 5
    Dim cValue As Integer = 6
    Dim cMtns As Integer = 7
    Dim cNos As Integer = 8
    Dim cMtrs As Integer = 9
    Dim cCGST As Integer = 10
    Dim cSGST As Integer = 11
    Dim cIGST As Integer = 12
    Dim cSlnoKey As Integer = 13
    Dim cUomKey As Integer = 14
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim strDelRecSno As String = ""
    Dim dblUnitWeight As Double = 0
    Dim dblLength As Double = 0
    Dim intNos As Integer = 0
    Dim dblSGST As Double = 0
    Dim dblCGST As Double = 0
    Dim dblIGST As Double = 0
    Dim dblItemValue As Double = 0
    Dim dblSGSTValue As Double = 0
    Dim dblCGSTValue As Double = 0
    Dim dblIGSTValue As Double = 0
    Dim dblTaxable As Double = 0
    Dim dblSGSTTotal As Double = 0
    Dim dblCGSTTotal As Double = 0
    Dim dblIGSTTotal As Double = 0
    Dim dblRoundOff As Double = 0
    Dim dblTotalVal As Double = 0
    Dim strCustGST As String




    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
    End Sub


    Sub OrderLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = getUom()

        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        ds = getISI()

        If ds.Tables(0).Rows.Count > 0 Then
            cmbisi.DataSource = ds.Tables(0)
            cmbisi.DisplayMember = "isi_std_short_desc"
            cmbisi.ValueMember = "isi_std_id"
        End If

        Call initializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
    End Sub

    Public Sub initializeControls()
        Call getSysDateTime()
        txtOrderNo.Text = ""
        txtCustomerId.Text = ""
        txtCustomerOrderNo.Text = ""
        txtDescription.Text = ""
        txtItemID.Text = ""
        txtQty.Text = ""
        cmbUom.Text = ""
        cmbisi.Text = ""
        txtDeliveryId.Text = ""
        chkDeliverySame.Checked = False
        chkIsJobwork.Checked = False
        OrderDt.Value = gSysDate
        CustomerOrderDt.Value = gSysDate
        DeliveryDt.Value = gSysDate
        grpEntry.Enabled = True
        i = 0
        lvwOrder.Items.Clear()
        txtNetTotal.Text = ""
        txtCGSTTotal.Text = ""
        txtSGSTTotal.Text = ""
        txtIGSTTotal.Text = ""
        txtRoundOff.Text = ""
        txtTotalVal.Text = ""
        txtTaxable.Text = ""
        txtNetTotal.Text = ""
        dblTotal = 0
        dblCGSTValue = 0
        dblCGSTTotal = 0
        dblIGSTTotal = 0
        dblIGSTValue = 0
        dblTotalVal = 0
        dblTaxable = 0
        dblRoundOff = 0
        dblSGSTTotal = 0
        dblSGSTValue = 0
        dblIGSTTotal = 0
        dblIGSTValue = 0
        intDelRecSno = 0
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
        lblCustName.Text = ""
        lbladd1.Text = ""
        lbladd2.Text = ""
        lblcity.Text = ""
        lbldName.Text = ""
        lbldadd1.Text = ""
        lbldadd2.Text = ""
        lbldcity.Text = ""
    End Sub

    Public Sub EnableDisable(toggle As Boolean)
        txtOrderNo.Enabled = Not toggle
        OrderDt.Enabled = toggle
        txtCustomerId.Enabled = toggle
        txtCustomerOrderNo.Enabled = toggle
        CustomerOrderDt.Enabled = toggle
        DeliveryDt.Enabled = toggle
        cmbisi.Enabled = toggle
        If chkDeliverySame.Checked = True Then
            txtDeliveryId.Enabled = True
        Else
            txtDeliveryId.Enabled = False
        End If
        chkIsJobwork.Enabled = toggle
        txtItemID.Enabled = toggle
        txtDescription.Enabled = False
        txtRate.Enabled = toggle
        txtQty.Enabled = toggle
        cmbUom.Enabled = toggle
        cmdAdd.Enabled = toggle
        cmdAddItem.Enabled = toggle
        lvwOrder.Enabled = toggle
    End Sub

    Sub CmdEditClick(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtOrderNo.Focus()
    End Sub

    Sub CmdCancelClick(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call initializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub TxtOrderNoKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtOrderNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtOrderNo.Text <> "" Then
            ds = getOrderHdr(CInt(txtOrderNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateOrderHdr(CInt(txtOrderNo.Text))
                Call populateOrderTrn(CInt(txtOrderNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtOrderNo.Focus()
            End If

        End If
    End Sub

    Public Sub populateOrderHdr(intOrderNo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            OrderDt.Text = ds.Tables(0).Rows(0).Item("pro_ord_dt").ToString
            txtCustomerId.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
            ds1 = getCustomer(CInt(txtCustomerId.Text))
            populateCustAddress(ds1)
            txtCustomerOrderNo.Text = ds.Tables(0).Rows(0).Item("cust_ord_no").ToString
            CustomerOrderDt.Text = ds.Tables(0).Rows(0).Item("cust_ord_dt").ToString
            DeliveryDt.Text = ds.Tables(0).Rows(0).Item("delivery_dt").ToString
            cmbisi.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("isi_std_id").ToString)
            If IsDBNull(ds.Tables(0).Rows(0).Item("delivery_id").ToString) Or CInt(ds.Tables(0).Rows(0).Item("delivery_id").ToString) = 0 Then
                txtDeliveryId.Text = ""
                txtDeliveryId.Enabled = False
                chkDeliverySame.Checked = False
            Else
                txtDeliveryId.Enabled = True
                txtDeliveryId.Text = ds.Tables(0).Rows(0).Item("delivery_id").ToString
                chkDeliverySame.Checked = True
                ds1 = getShipment(CInt(txtDeliveryId.Text), CInt(txtCustomerId.Text))
                Call populateShipAddress(ds1)
            End If
            If CInt(ds.Tables(0).Rows(0).Item("is_jobwork").ToString) = 2 Then
                chkIsJobwork.Checked = True
            Else
                chkIsJobwork.Checked = False
            End If
        End If
    End Sub

    Public Sub populateOrderTrn(intOrderNo As Integer)
        ds = getOrderTrn(intOrderNo)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                dblCGSTValue = 0
                dblSGSTValue = 0
                dblIGSTValue = 0
                lvw = lvwOrder.Items.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                With lvw
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    Else
                        .SubItems.Add("")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_rate").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("pro_rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("pro_qty")) Then
                        .SubItems.Add("")
                    Else
                        .SubItems.Add(Format(CDbl(ds.Tables(0).Rows(n).Item("pro_rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("pro_qty").ToString), "#0.00"))
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_intones").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_innos").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_inmtrs").ToString)

                    dblCGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("pro_cgst")), 0, ds.Tables(0).Rows(n).Item("pro_cgst").ToString))
                    .SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    dblSGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("pro_sgst")), 0, ds.Tables(0).Rows(n).Item("pro_sgst").ToString))
                    .SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    dblIGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("pro_igst")), 0, ds.Tables(0).Rows(n).Item("pro_igst").ToString))
                    .SubItems.Add(Format(dblIGSTValue, "#0.00"))
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("pro_rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("pro_qty")) Then
                    Else
                        dblTaxable = dblTaxable + CDbl(ds.Tables(0).Rows(n).Item("pro_rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("pro_qty").ToString)
                        dblCGSTTotal = dblCGSTTotal + dblCGSTValue
                        dblSGSTTotal = dblSGSTTotal + dblSGSTValue
                        dblIGSTTotal = dblIGSTTotal + dblIGSTValue
                        dblCGSTValue = 0
                        dblSGSTValue = 0
                        dblIGSTValue = 0
                    End If

                End With
                i += 1
            Next
            dblTotalVal = dblTotalVal + dblTaxable + dblCGSTTotal + dblSGSTTotal + dblIGSTTotal
            dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
            dblTotal = dblTotalVal - dblRoundOff
            txtCGSTTotal.Text = Format(dblCGSTTotal, "#0.00")
            txtSGSTTotal.Text = Format(dblSGSTTotal, "#0.00")
            txtIGSTTotal.Text = Format(dblIGSTTotal, "#0.00")
            txtTaxable.Text = Format(dblTaxable, "#0.00")
            txtTotalVal.Text = Format(dblTotalVal, "#0.00")
            txtRoundOff.Text = Format(dblRoundOff, "#0.00")
            txtNetTotal.Text = Format(dblTotal, "#0.00")
        End If
    End Sub

    Sub CmdAddClick(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Try
            If validateItem() Then
                i += 1
                dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
                lvw = lvwOrder.Items.Add(i.ToString)
                lvw.SubItems.Add(txtItemID.Text.ToString)
                lvw.SubItems.Add(txtDescription.Text.ToString)
                lvw.SubItems.Add(cmbUom.Text)
                lvw.SubItems.Add(txtQty.Text)
                lvw.SubItems.Add(txtRate.Text)
                lvw.SubItems.Add(Format(dblItemValue, "#0.00"))
                If cmbUom.Text = "MT" Then
                    ds1 = getItem(CInt(txtItemID.Text))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        dblUnitWeight = CDbl(ds1.Tables(0).Rows(0).Item("unitWeight").ToString)
                        dblLength = CDbl(ds1.Tables(0).Rows(0).Item("item_length").ToString)
                    End If
                    lvw.SubItems.Add(txtQty.Text) 'mtns
                    intNos = Math.Round(Val(txtQty.Text) * 1000 / (dblUnitWeight * dblLength), 0)
                    lvw.SubItems.Add(intNos.ToString()) ' nos
                    lvw.SubItems.Add(intNos * dblLength) 'Mtrs
                End If
                If cmbUom.Text = "Nos" Then
                    ds1 = getItem(CInt(txtItemID.Text))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        dblUnitWeight = CDbl(ds1.Tables(0).Rows(0).Item("unitWeight").ToString)
                        dblLength = CDbl(ds1.Tables(0).Rows(0).Item("item_length").ToString)
                    End If
                    lvw.SubItems.Add(Val(txtQty.Text) * dblUnitWeight * dblLength / 1000) 'mtns
                    lvw.SubItems.Add(txtQty.Text) ' nos
                    lvw.SubItems.Add(Val(txtQty.Text) * dblLength) 'Mtrs
                End If
                If cmbUom.Text = "Mtrs" Then
                    ds1 = getItem(CInt(txtItemID.Text))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        dblUnitWeight = CDbl(ds1.Tables(0).Rows(0).Item("unitWeight").ToString)
                        dblLength = CDbl(ds1.Tables(0).Rows(0).Item("item_length").ToString)
                    End If
                    lvw.SubItems.Add((Val(txtQty.Text) / dblLength) * dblUnitWeight)
                    lvw.SubItems.Add(Math.Round(Val(txtQty.Text) / dblLength, 0))
                    lvw.SubItems.Add(txtQty.Text)
                End If
                If Mid(strCustGST, 1, 2) = "33" Then
                    dblCGST = CDbl(ds1.Tables(0).Rows(0).Item("CGST").ToString)
                    dblCGSTValue = Math.Round(dblItemValue * dblCGST / 100, 2)
                    lvw.SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    dblSGST = CDbl(ds1.Tables(0).Rows(0).Item("SGST").ToString)
                    dblSGSTValue = Math.Round(dblItemValue * dblSGST / 100, 2)
                    lvw.SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    lvw.SubItems.Add("")
                Else
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add("")
                    dblIGST = CDbl(ds1.Tables(0).Rows(0).Item("IGST").ToString)
                    dblIGSTValue = Math.Round(dblItemValue * dblIGST / 100, 2)
                    lvw.SubItems.Add(Format(dblIGSTValue, "#0.00"))
                End If
                lvw.SubItems.Add("")
                lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
                dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
                dblCGSTTotal = dblCGSTTotal + dblCGSTValue
                dblSGSTTotal = dblSGSTTotal + dblSGSTValue
                dblIGSTTotal = dblIGSTTotal + dblIGSTValue
                dblTotalVal = dblTaxable + dblCGSTTotal + dblSGSTTotal + dblIGSTTotal
                dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                dblTotal = dblTotalVal - dblRoundOff
                txtCGSTTotal.Text = Format(dblCGSTTotal, "#0.00")
                txtSGSTTotal.Text = Format(dblSGSTTotal, "#0.00")
                txtIGSTTotal.Text = Format(dblIGSTTotal, "#0.00")
                txtTaxable.Text = Format(dblTaxable, "#0.00")
                txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                txtNetTotal.Text = Format(dblTotal, "#0.00")
                Call clearItem()
            Else
                Call clearItem()
            End If
            txtItemID.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub clearItem()
        txtItemID.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtRate.Text = ""
        cmbUom.Text = ""
    End Sub

    Public Function validateItem() As Boolean
        If txtItemID.Text.Trim = "" Then
            MsgBox("Please Enter Item Id", MsgBoxStyle.Information, gCompanyShortName)
            txtItemID.Focus()
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please Select UOM", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus()
            Return False
        End If
        If cmbUom.Text = "MT" Or cmbUom.Text = "Nos" Then
        Else
            MsgBox("Invalid UOM Only MT and Nos are valid UOM")
            cmbUom.Focus()
            Return False

        End If
        If txtRate.Text = "" Then
            MsgBox("Please Enter Rate", MsgBoxStyle.Information, gCompanyShortName)
            txtRate.Focus()
            Return False
        End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
        End If
        For n = 0 To lvwOrder.Items.Count - 1
            If txtItemID.Text.Trim = lvwOrder.Items(n).SubItems(citem).Text.Trim Then
                MsgBox("Item Already Exists", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Next
        Return True
    End Function

    Sub setSlno()
        i = 0
        For n = 0 To lvwOrder.Items.Count - 1
            i += 1
            lvwOrder.Items(n).Text = i.ToString
        Next
    End Sub

    Sub LvwOrderKeyDown(sender As Object, e As KeyEventArgs) Handles lvwOrder.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwOrder.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        dblTotal = dblTotal - (CDbl(lvwOrder.SelectedItems(0).SubItems(crate).Text) * CDbl(lvwOrder.SelectedItems(0).SubItems(cqty).Text))
                        txtNetTotal.Text = Format(dblTotal, "#0.00")
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwOrder.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwOrder.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwOrder.Items.RemoveAt(lvwOrder.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub CmdDeleteClick(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtOrderNo.Focus()
    End Sub

    Public Function validateOrder() As Boolean
        If thisScreenMode = 2 Or thisScreenMode = 3 Then
            If txtOrderNo.Text = "" Then
                MsgBox("Please Enter Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtOrderNo.Focus()
                Return False
                Exit Function
            End If
            If thisScreenMode = 2 Then
                If lvwOrder.Items.Count = 0 Then
                    MsgBox("Please Add Item", MsgBoxStyle.Information, gCompanyShortName)
                    txtItemID.Focus()
                    Return False
                    Exit Function
                End If

            End If
        Else
            If txtCustomerId.Text = "" Then
                MsgBox("Please Enter Customer Number", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerId.Focus()
                Return False
                Exit Function
            End If
            If txtCustomerOrderNo.Text = "" Then
                MsgBox("Please Enter Customer Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerOrderNo.Focus()
                Return False
                Exit Function
            End If
            If DeliveryDt.Value < OrderDt.Value Then
                MsgBox("Delivery Date Less than Order Date Pls check", MsgBoxStyle.Information, gCompanyShortName)
                DeliveryDt.Focus()
                Return False
                Exit Function
            End If
            If chkDeliverySame.Checked = True Then
                If txtDeliveryId.Text = "" Then
                    MsgBox("Please Select Delivery Address", MsgBoxStyle.Information, gCompanyShortName)
                    txtDeliveryId.Focus()
                    Return False
                    Exit Function
                End If
            End If
            If lvwOrder.Items.Count = 0 Then
                MsgBox("Please Add Item", MsgBoxStyle.Information, gCompanyShortName)
                txtItemID.Focus()
                Return False
                Exit Function
            End If
        End If

        Return True
    End Function

    Sub CmdSaveClick(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveOrder()
    End Sub

    Public Sub saveOrder()
        Try
            If validateOrder() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "Select nextval('pro_ord_id_seq') AS pro_ord_id"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        txtOrderNo.Text = obj.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertOrderHdr()
                        Call InsertOrderTrn()
                        trans.Commit()
                    Case 2
                        If intDelRecSno > 1 Then
                            strDelRecSno = String.Join(",", arrDelTrn)
                            strDelRecSno = Mid(strDelRecSno, 2)
                        ElseIf intDelRecSno = 1 Then
                            strDelRecSno = arrDelTrn(1).ToString
                        End If
                        Call updateOrderHdr()
                        Call updateOrderTrn()

                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Order ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteOrderTrn()
                            Call deleteOrderHdr()
                            trans.Commit()

                        End If

                End Select
                Call initializeControls()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call initializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub InsertOrderHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertOrderHdr(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text)
            dt = Date.ParseExact(Format(CDate(OrderDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@pro_ord_dt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@cust_id", OdbcType.Int).Value = CInt(txtCustomerId.Text.Trim())
            cmd.Parameters.AddWithValue("@cust_ord_no", OdbcType.NText).Value = txtCustomerOrderNo.Text.Trim()
            dt = Date.ParseExact(Format(CDate(CustomerOrderDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@cust_ord_dt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            dt = Date.ParseExact(Format(CDate(DeliveryDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@delivery_dt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@delivery_id", OdbcType.Int).Value = Val(txtDeliveryId.Text.Trim)
            cmd.Parameters.AddWithValue("@pro_status", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@is_jobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            If Not cmbisi.Text.ToString.Trim = "" Then
                cmd.Parameters.AddWithValue("@isi_std_id", OdbcType.Int).Value = cmbisi.SelectedValue.ToString
            Else
                cmd.Parameters.AddWithValue("@isi_std_id", OdbcType.Int).Value = 0
            End If

            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub InsertOrderTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwOrder.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertOrderTrn(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text.Trim())
                cmd.Parameters.AddWithValue("@pro_sno", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@item_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@uom_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@pro_qty", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cqty).Text)
                cmd.Parameters.AddWithValue("@pro_rate", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(crate).Text)
                cmd.Parameters.AddWithValue("@pro_qty_intones", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cMtns).Text)
                cmd.Parameters.AddWithValue("@pro_qty_innos", OdbcType.Decimal).Value = Math.Round(CDec(lvwOrder.Items(n).SubItems(cNos).Text), 0)
                cmd.Parameters.AddWithValue("@pro_qty_inmtrs", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cMtrs).Text)
                cmd.Parameters.AddWithValue("@procgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cCGST).Text)
                cmd.Parameters.AddWithValue("@prosgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cSGST).Text)
                cmd.Parameters.AddWithValue("@proigst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cIGST).Text)
                cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
                cmd.ExecuteScalar()
            Next
            MsgBox("Order No : " & txtOrderNo.Text & " Created")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateOrderHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateOrderHdr(?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@proordid", OdbcType.Int).Value = CInt(txtOrderNo.Text)
            dt = Date.ParseExact(Format(CDate(OrderDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@proorddt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = CInt(txtCustomerId.Text.Trim())
            cmd.Parameters.AddWithValue("@custordno", OdbcType.NText).Value = txtCustomerOrderNo.Text.Trim()
            dt = Date.ParseExact(Format(CDate(CustomerOrderDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@custorddt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            dt = Date.ParseExact(Format(CDate(DeliveryDt.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@deliverydt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@deliveryid", OdbcType.Int).Value = Val(txtDeliveryId.Text.Trim)
            cmd.Parameters.AddWithValue("@prostatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@isjobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            If Not cmbisi.Text.ToString.Trim = "" Then
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = cmbisi.SelectedValue.ToString
            Else
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = 0
            End If

            'cmd.Parameters.Addwithvalue("@modify_dt", OdbcType.date).Value = format(gSysDate,"yyyyMMMdd")
            'cmd.Parameters.Addwithvalue("@modify_tm", OdbcType.Int).Value = gSysTime
            'cmd.Parameters.Addwithvalue("@modify_by", OdbcType.Int).Value = gUserId
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateOrderTrn()
        Dim cmd As New OdbcCommand

        Try
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delOrderTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text)
                    cmd.Parameters.AddWithValue("@pro_sno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwOrder.Items.Count - 1
                If Not lvwOrder.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateOrderTrn(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@pro_sno", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@item_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uom_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@pro_qty", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@pro_rate", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_intones", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cMtns).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_inNos", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cNos).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_inMtrs", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cMtrs).Text)
                    cmd.Parameters.AddWithValue("@procgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@prosgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@proigst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
                    cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                End If
            Next
            For n = 0 To lvwOrder.Items.Count - 1
                If lvwOrder.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertOrderTrn(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@pro_sno", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@item_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uom_id", OdbcType.Int).Value = CInt(lvwOrder.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@pro_qty", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@pro_rate", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_intones", OdbcType.Double).Value = CDec(lvwOrder.Items(n).SubItems(cMtrs).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_inNos", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cNos).Text)
                    cmd.Parameters.AddWithValue("@pro_qty_inMtrs", OdbcType.Decimal).Value = CDec(lvwOrder.Items(n).SubItems(cMtrs).Text)
                    cmd.Parameters.AddWithValue("@procgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@prosgst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@proigst", OdbcType.Decimal).Value = Val(lvwOrder.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
                    cmd.ExecuteScalar()
                End If
            Next

            'Call setSerialNumbers
            MsgBox("Order Number Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteOrderHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteOrderHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteOrderTrn()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteOrderTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@pro_ord_id", OdbcType.Int).Value = CInt(txtOrderNo.Text)
            cmd.ExecuteScalar()
            MsgBox("Order No : " & txtOrderNo.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub


    Sub TxtCustomerIdKeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerId.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerId.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If

    End Sub

    Sub TxtDeliveryIdKeyDown(sender As Object, e As KeyEventArgs) Handles txtDeliveryId.KeyDown
        If e.KeyCode = 120 Then
            If txtCustomerId.Text.Trim = "" Then
                MsgBox("Please Select Customer After You Select Delivery Address", MsgBoxStyle.Information, gCompanyShortName)
                Exit Sub
            End If

            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getShipment(0, CInt(txtCustomerId.Text.Trim))
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtDeliveryId.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Customer Delivery Address", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub CmbUomKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub


    Sub CmbisiKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbisi.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbisi.Text
        Dim typedT As String = t.Substring(0, cmbisi.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbisi.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub


    Sub TxtOrderNoPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtOrderNo.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtOrderNo.Text.Trim <> "" Then
            ds = getOrderHdr(CInt(txtOrderNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateOrderHdr(CInt(txtOrderNo.Text))
                Call populateOrderTrn(CInt(txtOrderNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtOrderNo.Focus()
            End If
        End If
    End Sub


    Sub ChkDeliverySameCheckedChanged(sender As Object, e As EventArgs) Handles chkDeliverySame.CheckedChanged
        If chkDeliverySame.Checked = True Then
            txtDeliveryId.Enabled = True
        Else
            txtDeliveryId.Enabled = False
            txtDeliveryId.Text = ""
        End If
    End Sub

    Sub TxtCustomerIdPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtCustomerId.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtCustomerId.Text = "" Then
                ds1 = getCustomer(CInt(txtCustomerId.Text))
                Call populateCustAddress(ds1)
            End If
        End If
    End Sub

    Public Sub populateCustAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblCustName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
            lbladd1.Text = ds2.Tables(0).Rows(0).Item("cust_address1").ToString
            lbladd2.Text = ds2.Tables(0).Rows(0).Item("cust_address2").ToString
            lblcity.Text = ds2.Tables(0).Rows(0).Item("cust_city").ToString
            strCustGST = ds2.Tables(0).Rows(0).Item("cust_gst").ToString
        Else
            MsgBox("No Customer Id Found", MsgBoxStyle.Information, gCompanyShortName)
            txtCustomerId.Text = ""
        End If

    End Sub

    Public Sub populateShipAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lbldName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
            lbldadd1.Text = ds2.Tables(0).Rows(0).Item("ship_address1").ToString
            lbldadd2.Text = ds2.Tables(0).Rows(0).Item("ship_address2").ToString
            lbldcity.Text = ds2.Tables(0).Rows(0).Item("ship_city").ToString
        Else
            MsgBox("No shippment Address Found", MsgBoxStyle.Information, gCompanyShortName)
            txtDeliveryId.Text = ""
        End If

    End Sub

    Sub TxtDeliveryIdPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtDeliveryId.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtDeliveryId.Text = "" Then
                ds1 = getShipment(CInt(txtDeliveryId.Text), CInt(txtCustomerId.Text))
                Call populateShipAddress(ds1)
            End If
        End If
    End Sub

    Sub LvwOrderDoubleClick(sender As Object, e As EventArgs) Handles lvwOrder.DoubleClick
        If Not lvwOrder.SelectedItems Is Nothing Then
            txtItemID.Text = lvwOrder.SelectedItems(0).SubItems(citem).Text.ToString
            cmbUom.Text = lvwOrder.SelectedItems(0).SubItems(cuom).Text.ToString
            txtRate.Text = lvwOrder.SelectedItems(0).SubItems(crate).Text.ToString
            txtQty.Text = lvwOrder.SelectedItems(0).SubItems(cqty).Text.ToString
        End If

    End Sub

    Sub TxtItemIDKeyDown(sender As Object, e As KeyEventArgs) Handles txtItemID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getItem()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub TxtItemIDPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemID.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemID.Text = "" Then
                ds1 = getItem(CInt(txtItemID.Text))
                Call populateItemDesc(ds1)
            End If
        End If

    End Sub


    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
        Else
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
            txtDeliveryId.Text = ""
        End If

    End Sub

    Sub TxtCustomerIdLeave(sender As Object, e As EventArgs) Handles txtCustomerId.Leave
        If Not txtCustomerId.Text = "" Then
            ds1 = getCustomer(CInt(txtCustomerId.Text))
            Call populateCustAddress(ds1)
        End If

    End Sub


    Sub TxtItemIDLeave(sender As Object, e As EventArgs) Handles txtItemID.Leave
        If Not txtItemID.Text = "" Then
            ds1 = getItem(CInt(txtItemID.Text))
            Call populateItemDesc(ds1)
        End If
    End Sub

    Sub OrderKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveOrder()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Sub TxtCustomerIdKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerId.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Sub TxtItemIDKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Sub TxtRateKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRate.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtRate.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If

    End Sub

    Sub TxtQtyKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtQty.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Sub TxtCustomerOrderNoKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerOrderNo.KeyPress
        If (isNumber(Asc(e.KeyChar)) Or isAlpha(Asc(e.KeyChar))) Then
        Else
            e.KeyChar = Nothing
        End If
    End Sub

    Sub CmdAddItemClick(sender As Object, e As EventArgs) Handles cmdAddItem.click
        Dim frmItemMaster As New Item
        frmItemMaster.ShowDialog()
    End Sub

    Private Sub grpLvwOrder_Enter(sender As Object, e As EventArgs) Handles grpLvwOrder.Enter

    End Sub

    Private Sub chkIsJobwork_CheckedChanged(sender As Object, e As EventArgs) Handles chkIsJobwork.CheckedChanged

    End Sub

    Private Sub txtCustomerId_TextChanged(sender As Object, e As EventArgs) Handles txtCustomerId.TextChanged

    End Sub

    Private Sub label11_Click(sender As Object, e As EventArgs) Handles label11.Click

    End Sub

    Private Sub grpHeader_Enter(sender As Object, e As EventArgs) Handles grpHeader.Enter

    End Sub
End Class
