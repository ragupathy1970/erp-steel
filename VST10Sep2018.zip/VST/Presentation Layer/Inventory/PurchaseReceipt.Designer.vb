﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PurchaseReceipt
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtBillDiscount = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtFrieghtCharges = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtOtherCharges = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTotalVal = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtRoundOff = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtIGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtSGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtCGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTaxable = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtNetTotal = New System.Windows.Forms.TextBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.lvwReceipt = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colPONo = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colHSN = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCoilID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ColPOQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colReceivedQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colRate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDiscount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colIGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.grpEntry = New System.Windows.Forms.GroupBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.txtCoilID = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.txtReceivedQty = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtPono = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.cmdAddItem = New System.Windows.Forms.Button()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtItemID = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cmbItemType = New System.Windows.Forms.ComboBox()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.chkIsJobwork = New System.Windows.Forms.CheckBox()
        Me.lblcity = New System.Windows.Forms.Label()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lbladd1 = New System.Windows.Forms.Label()
        Me.lblVenName = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.dtDeliveryDate = New System.Windows.Forms.DateTimePicker()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.txtDeliveryNo = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.dtDoDate = New System.Windows.Forms.DateTimePicker()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtDoNo = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.dtSoDate = New System.Windows.Forms.DateTimePicker()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.txtSoNo = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtVehicleNo = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.dtLrDate = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtLrNo = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.dtVendorInvDate = New System.Windows.Forms.DateTimePicker()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtVendorInvAmt = New System.Windows.Forms.TextBox()
        Me.txtVendorInvNo = New System.Windows.Forms.TextBox()
        Me.txtVendorID = New System.Windows.Forms.TextBox()
        Me.dtReceiptDate = New System.Windows.Forms.DateTimePicker()
        Me.txtReceiptID = New System.Windows.Forms.TextBox()
        Me.txtQtynos = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.colQtypcs = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.GroupBox3.SuspendLayout()
        Me.grpEntry.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(702, 481)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 34
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(891, 481)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 36
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(798, 481)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 35
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(606, 480)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 33
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtRemarks)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.txtBillDiscount)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.txtFrieghtCharges)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.txtOtherCharges)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtTotalVal)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.txtRoundOff)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtIGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.txtSGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.txtCGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtTaxable)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtNetTotal)
        Me.GroupBox3.Controls.Add(Me.label14)
        Me.GroupBox3.Controls.Add(Me.lvwReceipt)
        Me.GroupBox3.Location = New System.Drawing.Point(14, 239)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(982, 229)
        Me.GroupBox3.TabIndex = 27
        Me.GroupBox3.TabStop = False
        '
        'txtRemarks
        '
        Me.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRemarks.Location = New System.Drawing.Point(69, 166)
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(295, 51)
        Me.txtRemarks.TabIndex = 23
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(2, 166)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 19)
        Me.Label24.TabIndex = 59
        Me.Label24.Text = "Remarks"
        '
        'txtBillDiscount
        '
        Me.txtBillDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBillDiscount.Location = New System.Drawing.Point(277, 139)
        Me.txtBillDiscount.Name = "txtBillDiscount"
        Me.txtBillDiscount.Size = New System.Drawing.Size(87, 22)
        Me.txtBillDiscount.TabIndex = 22
        Me.txtBillDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(184, 139)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(84, 22)
        Me.Label26.TabIndex = 50
        Me.Label26.Text = "Bill Discount"
        '
        'txtFrieghtCharges
        '
        Me.txtFrieghtCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFrieghtCharges.Location = New System.Drawing.Point(481, 139)
        Me.txtFrieghtCharges.Name = "txtFrieghtCharges"
        Me.txtFrieghtCharges.Size = New System.Drawing.Size(87, 22)
        Me.txtFrieghtCharges.TabIndex = 24
        Me.txtFrieghtCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(385, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 22)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Freight Chgs."
        '
        'txtOtherCharges
        '
        Me.txtOtherCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOtherCharges.Location = New System.Drawing.Point(482, 167)
        Me.txtOtherCharges.Name = "txtOtherCharges"
        Me.txtOtherCharges.Size = New System.Drawing.Size(87, 22)
        Me.txtOtherCharges.TabIndex = 25
        Me.txtOtherCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(395, 167)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 22)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Other Chgs."
        '
        'txtTotalVal
        '
        Me.txtTotalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalVal.Enabled = False
        Me.txtTotalVal.Location = New System.Drawing.Point(482, 196)
        Me.txtTotalVal.Name = "txtTotalVal"
        Me.txtTotalVal.Size = New System.Drawing.Size(87, 22)
        Me.txtTotalVal.TabIndex = 26
        Me.txtTotalVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(403, 196)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(72, 22)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Total Value"
        '
        'txtRoundOff
        '
        Me.txtRoundOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoundOff.Enabled = False
        Me.txtRoundOff.ForeColor = System.Drawing.Color.Red
        Me.txtRoundOff.Location = New System.Drawing.Point(651, 169)
        Me.txtRoundOff.Name = "txtRoundOff"
        Me.txtRoundOff.Size = New System.Drawing.Size(87, 22)
        Me.txtRoundOff.TabIndex = 28
        Me.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(584, 170)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 19)
        Me.Label19.TabIndex = 42
        Me.Label19.Text = "Round Off"
        '
        'txtIGSTTotal
        '
        Me.txtIGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIGSTTotal.Enabled = False
        Me.txtIGSTTotal.Location = New System.Drawing.Point(823, 199)
        Me.txtIGSTTotal.Name = "txtIGSTTotal"
        Me.txtIGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtIGSTTotal.TabIndex = 32
        Me.txtIGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(756, 198)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 19)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "IGST Total"
        '
        'txtSGSTTotal
        '
        Me.txtSGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSGSTTotal.Enabled = False
        Me.txtSGSTTotal.Location = New System.Drawing.Point(824, 170)
        Me.txtSGSTTotal.Name = "txtSGSTTotal"
        Me.txtSGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtSGSTTotal.TabIndex = 31
        Me.txtSGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(751, 169)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(77, 19)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "SGST Total"
        '
        'txtCGSTTotal
        '
        Me.txtCGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCGSTTotal.Enabled = False
        Me.txtCGSTTotal.Location = New System.Drawing.Point(824, 141)
        Me.txtCGSTTotal.Name = "txtCGSTTotal"
        Me.txtCGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtCGSTTotal.TabIndex = 30
        Me.txtCGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(750, 141)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 19)
        Me.Label16.TabIndex = 36
        Me.Label16.Text = "CGST Total"
        '
        'txtTaxable
        '
        Me.txtTaxable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTaxable.Enabled = False
        Me.txtTaxable.Location = New System.Drawing.Point(652, 140)
        Me.txtTaxable.Name = "txtTaxable"
        Me.txtTaxable.Size = New System.Drawing.Size(87, 22)
        Me.txtTaxable.TabIndex = 27
        Me.txtTaxable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(597, 141)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(56, 19)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "Taxable "
        '
        'txtNetTotal
        '
        Me.txtNetTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNetTotal.Enabled = False
        Me.txtNetTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNetTotal.Location = New System.Drawing.Point(651, 199)
        Me.txtNetTotal.Name = "txtNetTotal"
        Me.txtNetTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtNetTotal.TabIndex = 29
        Me.txtNetTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(587, 199)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(66, 19)
        Me.label14.TabIndex = 32
        Me.label14.Text = "Net Total"
        '
        'lvwReceipt
        '
        Me.lvwReceipt.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwReceipt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwReceipt.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colPONo, Me.colHSN, Me.colItemid, Me.colDescription, Me.colCoilID, Me.colUom, Me.ColPOQty, Me.colQty, Me.colReceivedQty, Me.colQtypcs, Me.colRate, Me.colValue, Me.colDiscount, Me.colCGST, Me.colSGST, Me.colIGST, Me.colSlnoKey, Me.colUomKey})
        Me.lvwReceipt.FullRowSelect = True
        Me.lvwReceipt.GridLines = True
        Me.lvwReceipt.Location = New System.Drawing.Point(8, 12)
        Me.lvwReceipt.MultiSelect = False
        Me.lvwReceipt.Name = "lvwReceipt"
        Me.lvwReceipt.Size = New System.Drawing.Size(968, 121)
        Me.lvwReceipt.TabIndex = 1
        Me.lvwReceipt.UseCompatibleStateImageBehavior = False
        Me.lvwReceipt.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 41
        '
        'colPONo
        '
        Me.colPONo.Text = "Po No"
        Me.colPONo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colHSN
        '
        Me.colHSN.Text = "HSN"
        Me.colHSN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 75
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colCoilID
        '
        Me.colCoilID.Text = "Coil ID"
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ColPOQty
        '
        Me.ColPOQty.Text = "PO Qty"
        Me.ColPOQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.ColPOQty.Width = 70
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colQty.Width = 48
        '
        'colReceivedQty
        '
        Me.colReceivedQty.Text = "Rec. Qty"
        Me.colReceivedQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colReceivedQty.Width = 80
        '
        'colRate
        '
        Me.colRate.Text = "Rate"
        Me.colRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colRate.Width = 70
        '
        'colValue
        '
        Me.colValue.Text = "Value"
        Me.colValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colValue.Width = 100
        '
        'colDiscount
        '
        Me.colDiscount.Text = "Discount"
        Me.colDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colDiscount.Width = 70
        '
        'colCGST
        '
        Me.colCGST.Text = "CGST"
        Me.colCGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSGST
        '
        Me.colSGST.Text = "SGST"
        Me.colSGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colIGST
        '
        Me.colIGST.Text = "IGST"
        Me.colIGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 0
        '
        'grpEntry
        '
        Me.grpEntry.Controls.Add(Me.Label37)
        Me.grpEntry.Controls.Add(Me.txtQtynos)
        Me.grpEntry.Controls.Add(Me.Label35)
        Me.grpEntry.Controls.Add(Me.txtCoilID)
        Me.grpEntry.Controls.Add(Me.Label34)
        Me.grpEntry.Controls.Add(Me.txtReceivedQty)
        Me.grpEntry.Controls.Add(Me.Label33)
        Me.grpEntry.Controls.Add(Me.txtDiscount)
        Me.grpEntry.Controls.Add(Me.Label3)
        Me.grpEntry.Controls.Add(Me.txtPono)
        Me.grpEntry.Controls.Add(Me.label13)
        Me.grpEntry.Controls.Add(Me.Label2)
        Me.grpEntry.Controls.Add(Me.Label1)
        Me.grpEntry.Controls.Add(Me.Label8)
        Me.grpEntry.Controls.Add(Me.Label6)
        Me.grpEntry.Controls.Add(Me.txtRate)
        Me.grpEntry.Controls.Add(Me.cmbUom)
        Me.grpEntry.Controls.Add(Me.cmdAdd)
        Me.grpEntry.Controls.Add(Me.txtQty)
        Me.grpEntry.Controls.Add(Me.cmdAddItem)
        Me.grpEntry.Controls.Add(Me.txtDescription)
        Me.grpEntry.Controls.Add(Me.txtItemID)
        Me.grpEntry.Location = New System.Drawing.Point(12, 176)
        Me.grpEntry.Name = "grpEntry"
        Me.grpEntry.Size = New System.Drawing.Size(984, 56)
        Me.grpEntry.TabIndex = 26
        Me.grpEntry.TabStop = False
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.Transparent
        Me.Label35.Location = New System.Drawing.Point(439, 6)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(48, 19)
        Me.Label35.TabIndex = 57
        Me.Label35.Text = "Coil ID"
        '
        'txtCoilID
        '
        Me.txtCoilID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCoilID.Location = New System.Drawing.Point(439, 25)
        Me.txtCoilID.Name = "txtCoilID"
        Me.txtCoilID.Size = New System.Drawing.Size(75, 22)
        Me.txtCoilID.TabIndex = 16
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.Transparent
        Me.Label34.Location = New System.Drawing.Point(633, 8)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(59, 15)
        Me.Label34.TabIndex = 55
        Me.Label34.Text = "Rec Qty"
        '
        'txtReceivedQty
        '
        Me.txtReceivedQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtReceivedQty.Location = New System.Drawing.Point(636, 27)
        Me.txtReceivedQty.Name = "txtReceivedQty"
        Me.txtReceivedQty.Size = New System.Drawing.Size(55, 22)
        Me.txtReceivedQty.TabIndex = 19
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Location = New System.Drawing.Point(769, 8)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(64, 15)
        Me.Label33.TabIndex = 53
        Me.Label33.Text = "Discount"
        '
        'txtDiscount
        '
        Me.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscount.Location = New System.Drawing.Point(772, 27)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(74, 22)
        Me.txtDiscount.TabIndex = 21
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(8, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 19)
        Me.Label3.TabIndex = 51
        Me.Label3.Text = "Po No."
        '
        'txtPono
        '
        Me.txtPono.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPono.Location = New System.Drawing.Point(8, 25)
        Me.txtPono.Name = "txtPono"
        Me.txtPono.Size = New System.Drawing.Size(62, 22)
        Me.txtPono.TabIndex = 14
        '
        'label13
        '
        Me.label13.BackColor = System.Drawing.Color.Transparent
        Me.label13.Location = New System.Drawing.Point(694, 8)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(37, 15)
        Me.label13.TabIndex = 49
        Me.label13.Text = "Rate"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(572, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 15)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "Quantity"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(516, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 19)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "UOM"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(187, 5)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "Item Description"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(76, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 45
        Me.Label6.Text = "Item ID"
        '
        'txtRate
        '
        Me.txtRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRate.Location = New System.Drawing.Point(695, 27)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(74, 22)
        Me.txtRate.TabIndex = 20
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(519, 25)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(50, 24)
        Me.cmbUom.TabIndex = 17
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(892, 18)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 22
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(575, 26)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(55, 22)
        Me.txtQty.TabIndex = 18
        '
        'cmdAddItem
        '
        Me.cmdAddItem.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddItem.Location = New System.Drawing.Point(158, 25)
        Me.cmdAddItem.Name = "cmdAddItem"
        Me.cmdAddItem.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddItem.TabIndex = 39
        Me.cmdAddItem.Text = "+"
        Me.cmdAddItem.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Enabled = False
        Me.txtDescription.Location = New System.Drawing.Point(188, 25)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(247, 22)
        Me.txtDescription.TabIndex = 38
        '
        'txtItemID
        '
        Me.txtItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemID.Location = New System.Drawing.Point(78, 25)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.Size = New System.Drawing.Size(75, 22)
        Me.txtItemID.TabIndex = 15
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.cmbItemType)
        Me.GroupBox1.Controls.Add(Me.lblCustName)
        Me.GroupBox1.Controls.Add(Me.txtCustomerID)
        Me.GroupBox1.Controls.Add(Me.chkIsJobwork)
        Me.GroupBox1.Controls.Add(Me.lblcity)
        Me.GroupBox1.Controls.Add(Me.lbladd2)
        Me.GroupBox1.Controls.Add(Me.lbladd1)
        Me.GroupBox1.Controls.Add(Me.lblVenName)
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.dtDeliveryDate)
        Me.GroupBox1.Controls.Add(Me.Label32)
        Me.GroupBox1.Controls.Add(Me.txtDeliveryNo)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.dtDoDate)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.txtDoNo)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.dtSoDate)
        Me.GroupBox1.Controls.Add(Me.Label27)
        Me.GroupBox1.Controls.Add(Me.txtSoNo)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtVehicleNo)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.dtLrDate)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.txtLrNo)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.dtVendorInvDate)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtVendorInvAmt)
        Me.GroupBox1.Controls.Add(Me.txtVendorInvNo)
        Me.GroupBox1.Controls.Add(Me.txtVendorID)
        Me.GroupBox1.Controls.Add(Me.dtReceiptDate)
        Me.GroupBox1.Controls.Add(Me.txtReceiptID)
        Me.GroupBox1.Location = New System.Drawing.Point(15, 9)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(981, 166)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label36.Location = New System.Drawing.Point(585, 128)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(66, 19)
        Me.Label36.TabIndex = 83
        Me.Label36.Text = "Item Type"
        '
        'cmbItemType
        '
        Me.cmbItemType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbItemType.FormattingEnabled = True
        Me.cmbItemType.Location = New System.Drawing.Point(662, 127)
        Me.cmbItemType.Name = "cmbItemType"
        Me.cmbItemType.Size = New System.Drawing.Size(265, 24)
        Me.cmbItemType.TabIndex = 82
        '
        'lblCustName
        '
        Me.lblCustName.Location = New System.Drawing.Point(237, 136)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(254, 15)
        Me.lblCustName.TabIndex = 81
        '
        'txtCustomerID
        '
        Me.txtCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCustomerID.Location = New System.Drawing.Point(156, 132)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.Size = New System.Drawing.Size(75, 22)
        Me.txtCustomerID.TabIndex = 80
        '
        'chkIsJobwork
        '
        Me.chkIsJobwork.AutoSize = True
        Me.chkIsJobwork.Location = New System.Drawing.Point(66, 134)
        Me.chkIsJobwork.Name = "chkIsJobwork"
        Me.chkIsJobwork.Size = New System.Drawing.Size(82, 20)
        Me.chkIsJobwork.TabIndex = 79
        Me.chkIsJobwork.Text = "Job Work"
        Me.chkIsJobwork.UseVisualStyleBackColor = True
        '
        'lblcity
        '
        Me.lblcity.Location = New System.Drawing.Point(194, 71)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(254, 15)
        Me.lblcity.TabIndex = 76
        '
        'lbladd2
        '
        Me.lbladd2.Location = New System.Drawing.Point(194, 54)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(254, 15)
        Me.lbladd2.TabIndex = 75
        '
        'lbladd1
        '
        Me.lbladd1.Location = New System.Drawing.Point(194, 36)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(254, 15)
        Me.lbladd1.TabIndex = 74
        '
        'lblVenName
        '
        Me.lblVenName.Location = New System.Drawing.Point(194, 20)
        Me.lblVenName.Name = "lblVenName"
        Me.lblVenName.Size = New System.Drawing.Size(254, 15)
        Me.lblVenName.TabIndex = 73
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.Transparent
        Me.Label31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label31.Location = New System.Drawing.Point(764, 99)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(66, 19)
        Me.Label31.TabIndex = 72
        Me.Label31.Text = "Deli. Date"
        '
        'dtDeliveryDate
        '
        Me.dtDeliveryDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtDeliveryDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtDeliveryDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDeliveryDate.Location = New System.Drawing.Point(830, 97)
        Me.dtDeliveryDate.Name = "dtDeliveryDate"
        Me.dtDeliveryDate.Size = New System.Drawing.Size(99, 22)
        Me.dtDeliveryDate.TabIndex = 13
        Me.dtDeliveryDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.Transparent
        Me.Label32.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label32.Location = New System.Drawing.Point(628, 101)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(51, 19)
        Me.Label32.TabIndex = 70
        Me.Label32.Text = "Deli.No."
        '
        'txtDeliveryNo
        '
        Me.txtDeliveryNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDeliveryNo.Location = New System.Drawing.Point(680, 97)
        Me.txtDeliveryNo.Name = "txtDeliveryNo"
        Me.txtDeliveryNo.Size = New System.Drawing.Size(75, 22)
        Me.txtDeliveryNo.TabIndex = 12
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.Transparent
        Me.Label29.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label29.Location = New System.Drawing.Point(452, 99)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(69, 19)
        Me.Label29.TabIndex = 68
        Me.Label29.Text = "DO Date"
        '
        'dtDoDate
        '
        Me.dtDoDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtDoDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtDoDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtDoDate.Location = New System.Drawing.Point(525, 97)
        Me.dtDoDate.Name = "dtDoDate"
        Me.dtDoDate.Size = New System.Drawing.Size(99, 22)
        Me.dtDoDate.TabIndex = 11
        Me.dtDoDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.Transparent
        Me.Label30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label30.Location = New System.Drawing.Point(317, 102)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(53, 19)
        Me.Label30.TabIndex = 66
        Me.Label30.Text = "DO.No."
        '
        'txtDoNo
        '
        Me.txtDoNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDoNo.Location = New System.Drawing.Point(373, 98)
        Me.txtDoNo.Name = "txtDoNo"
        Me.txtDoNo.Size = New System.Drawing.Size(75, 22)
        Me.txtDoNo.TabIndex = 10
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.Transparent
        Me.Label28.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label28.Location = New System.Drawing.Point(145, 101)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(66, 19)
        Me.Label28.TabIndex = 64
        Me.Label28.Text = "SO Date"
        '
        'dtSoDate
        '
        Me.dtSoDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtSoDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtSoDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtSoDate.Location = New System.Drawing.Point(213, 99)
        Me.dtSoDate.Name = "dtSoDate"
        Me.dtSoDate.Size = New System.Drawing.Size(99, 22)
        Me.dtSoDate.TabIndex = 9
        Me.dtSoDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.Transparent
        Me.Label27.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label27.Location = New System.Drawing.Point(13, 103)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(53, 19)
        Me.Label27.TabIndex = 62
        Me.Label27.Text = "SO.No."
        '
        'txtSoNo
        '
        Me.txtSoNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSoNo.Location = New System.Drawing.Point(68, 99)
        Me.txtSoNo.Name = "txtSoNo"
        Me.txtSoNo.Size = New System.Drawing.Size(75, 22)
        Me.txtSoNo.TabIndex = 8
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label25.Location = New System.Drawing.Point(523, 18)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 19)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Vehicle No."
        '
        'txtVehicleNo
        '
        Me.txtVehicleNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVehicleNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVehicleNo.Location = New System.Drawing.Point(602, 15)
        Me.txtVehicleNo.Name = "txtVehicleNo"
        Me.txtVehicleNo.Size = New System.Drawing.Size(75, 22)
        Me.txtVehicleNo.TabIndex = 2
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(533, 69)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(66, 19)
        Me.Label23.TabIndex = 56
        Me.Label23.Text = "L.R. Date"
        '
        'dtLrDate
        '
        Me.dtLrDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtLrDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtLrDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtLrDate.Location = New System.Drawing.Point(603, 67)
        Me.dtLrDate.Name = "dtLrDate"
        Me.dtLrDate.Size = New System.Drawing.Size(99, 22)
        Me.dtLrDate.TabIndex = 5
        Me.dtLrDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(547, 45)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 19)
        Me.Label22.TabIndex = 54
        Me.Label22.Text = "L.R.No."
        '
        'txtLrNo
        '
        Me.txtLrNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLrNo.Location = New System.Drawing.Point(602, 41)
        Me.txtLrNo.Name = "txtLrNo"
        Me.txtLrNo.Size = New System.Drawing.Size(75, 22)
        Me.txtLrNo.TabIndex = 4
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(704, 69)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(116, 19)
        Me.Label21.TabIndex = 52
        Me.Label21.Text = "Supplier Inv. Date"
        '
        'dtVendorInvDate
        '
        Me.dtVendorInvDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtVendorInvDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtVendorInvDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtVendorInvDate.Location = New System.Drawing.Point(828, 70)
        Me.dtVendorInvDate.Name = "dtVendorInvDate"
        Me.dtVendorInvDate.Size = New System.Drawing.Size(99, 22)
        Me.dtVendorInvDate.TabIndex = 7
        Me.dtVendorInvDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(730, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 19)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "Receipt Date"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(36, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 19)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Receipt ID"
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(5, 70)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(106, 19)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "Supplier Inv. No."
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(705, 45)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(116, 19)
        Me.Label9.TabIndex = 47
        Me.Label9.Text = "Supplier Inv. Amt."
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(33, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(72, 19)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Supplier ID"
        '
        'txtVendorInvAmt
        '
        Me.txtVendorInvAmt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorInvAmt.Location = New System.Drawing.Point(828, 43)
        Me.txtVendorInvAmt.Name = "txtVendorInvAmt"
        Me.txtVendorInvAmt.Size = New System.Drawing.Size(75, 22)
        Me.txtVendorInvAmt.TabIndex = 6
        '
        'txtVendorInvNo
        '
        Me.txtVendorInvNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorInvNo.Location = New System.Drawing.Point(114, 71)
        Me.txtVendorInvNo.Name = "txtVendorInvNo"
        Me.txtVendorInvNo.Size = New System.Drawing.Size(75, 22)
        Me.txtVendorInvNo.TabIndex = 6
        '
        'txtVendorID
        '
        Me.txtVendorID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorID.Location = New System.Drawing.Point(114, 45)
        Me.txtVendorID.Name = "txtVendorID"
        Me.txtVendorID.Size = New System.Drawing.Size(75, 22)
        Me.txtVendorID.TabIndex = 3
        '
        'dtReceiptDate
        '
        Me.dtReceiptDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtReceiptDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtReceiptDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtReceiptDate.Location = New System.Drawing.Point(827, 17)
        Me.dtReceiptDate.Name = "dtReceiptDate"
        Me.dtReceiptDate.Size = New System.Drawing.Size(99, 22)
        Me.dtReceiptDate.TabIndex = 3
        Me.dtReceiptDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'txtReceiptID
        '
        Me.txtReceiptID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtReceiptID.Location = New System.Drawing.Point(114, 17)
        Me.txtReceiptID.Name = "txtReceiptID"
        Me.txtReceiptID.Size = New System.Drawing.Size(75, 22)
        Me.txtReceiptID.TabIndex = 1
        '
        'txtQtynos
        '
        Me.txtQtynos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQtynos.Location = New System.Drawing.Point(851, 26)
        Me.txtQtynos.Name = "txtQtynos"
        Me.txtQtynos.Size = New System.Drawing.Size(35, 22)
        Me.txtQtynos.TabIndex = 58
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.Transparent
        Me.Label37.Location = New System.Drawing.Point(835, 7)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(58, 17)
        Me.Label37.TabIndex = 59
        Me.Label37.Text = "Qty Pcs"
        '
        'colQtypcs
        '
        Me.colQtypcs.Text = "Qty in Pcs"
        Me.colQtypcs.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colQtypcs.Width = 80
        '
        'PurchaseReceipt
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(1008, 521)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.grpEntry)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "PurchaseReceipt"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Purchase Receipt(GRN)"
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.grpEntry.ResumeLayout(False)
        Me.grpEntry.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents grpEntry As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents lvwReceipt As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Private WithEvents colRate As System.Windows.Forms.ColumnHeader
    Private WithEvents colValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colIGST As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Friend WithEvents colPONo As System.Windows.Forms.ColumnHeader
    Friend WithEvents ColPOQty As System.Windows.Forms.ColumnHeader
    Friend WithEvents colReceivedQty As System.Windows.Forms.ColumnHeader
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtPono As System.Windows.Forms.TextBox
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents txtRate As System.Windows.Forms.TextBox
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents cmdAddItem As System.Windows.Forms.Button
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents txtItemID As System.Windows.Forms.TextBox
    Private WithEvents txtTotalVal As System.Windows.Forms.TextBox
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents txtRoundOff As System.Windows.Forms.TextBox
    Private WithEvents Label19 As System.Windows.Forms.Label
    Private WithEvents txtIGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents txtSGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents txtCGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents txtTaxable As System.Windows.Forms.TextBox
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents txtNetTotal As System.Windows.Forms.TextBox
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents txtReceiptID As System.Windows.Forms.TextBox
    Private WithEvents txtFrieghtCharges As System.Windows.Forms.TextBox
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents txtOtherCharges As System.Windows.Forms.TextBox
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents txtVendorInvAmt As System.Windows.Forms.TextBox
    Private WithEvents txtVendorInvNo As System.Windows.Forms.TextBox
    Private WithEvents txtVendorID As System.Windows.Forms.TextBox
    Private WithEvents dtReceiptDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label21 As System.Windows.Forms.Label
    Private WithEvents dtVendorInvDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents colHSN As System.Windows.Forms.ColumnHeader
    Private WithEvents Label23 As System.Windows.Forms.Label
    Private WithEvents dtLrDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label22 As System.Windows.Forms.Label
    Private WithEvents txtLrNo As System.Windows.Forms.TextBox
    Private WithEvents Label25 As System.Windows.Forms.Label
    Private WithEvents txtVehicleNo As System.Windows.Forms.TextBox
    Friend WithEvents colDiscount As System.Windows.Forms.ColumnHeader
    Private WithEvents txtBillDiscount As System.Windows.Forms.TextBox
    Private WithEvents Label26 As System.Windows.Forms.Label
    Private WithEvents Label31 As System.Windows.Forms.Label
    Private WithEvents dtDeliveryDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label32 As System.Windows.Forms.Label
    Private WithEvents txtDeliveryNo As System.Windows.Forms.TextBox
    Private WithEvents Label29 As System.Windows.Forms.Label
    Private WithEvents dtDoDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label30 As System.Windows.Forms.Label
    Private WithEvents txtDoNo As System.Windows.Forms.TextBox
    Private WithEvents Label28 As System.Windows.Forms.Label
    Private WithEvents dtSoDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label27 As System.Windows.Forms.Label
    Private WithEvents txtSoNo As System.Windows.Forms.TextBox
    Private WithEvents Label33 As System.Windows.Forms.Label
    Private WithEvents txtDiscount As System.Windows.Forms.TextBox
    Private WithEvents Label24 As System.Windows.Forms.Label
    Private WithEvents txtRemarks As System.Windows.Forms.TextBox
    Private WithEvents lblcity As System.Windows.Forms.Label
    Private WithEvents lbladd2 As System.Windows.Forms.Label
    Private WithEvents lbladd1 As System.Windows.Forms.Label
    Private WithEvents lblVenName As System.Windows.Forms.Label
    Private WithEvents Label34 As System.Windows.Forms.Label
    Private WithEvents txtReceivedQty As System.Windows.Forms.TextBox
    Friend WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents Label35 As System.Windows.Forms.Label
    Private WithEvents txtCoilID As System.Windows.Forms.TextBox
    Friend WithEvents colCoilID As System.Windows.Forms.ColumnHeader
    Friend WithEvents chkIsJobwork As System.Windows.Forms.CheckBox
    Private WithEvents txtCustomerID As System.Windows.Forms.TextBox
    Private WithEvents lblCustName As System.Windows.Forms.Label
    Private WithEvents Label36 As System.Windows.Forms.Label
    Private WithEvents cmbItemType As System.Windows.Forms.ComboBox
    Friend WithEvents colQtypcs As System.Windows.Forms.ColumnHeader
    Private WithEvents Label37 As System.Windows.Forms.Label
    Private WithEvents txtQtynos As System.Windows.Forms.TextBox
End Class
