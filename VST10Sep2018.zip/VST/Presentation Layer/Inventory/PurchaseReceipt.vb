﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production
Public Class PurchaseReceipt
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim i As Integer
    Dim lvw As ListViewItem
    Dim ds1 As DataSet
    Dim ds2 As DataSet
    Dim dblCGSTper As Double
    Dim dblSGSTper As Double
    Dim dblIGSTper As Double
    Dim strHSN As String
    Dim strVenGST As String
    Dim strScode As String
    Dim dblItemValue As Double = 0
    Dim dblTaxable As Double = 0
    Dim dblRoundOff As Double
    Dim dblTotal As Double
    Dim dblcgsttotal As Double
    Dim dblsgsttotal As Double
    Dim dbligsttotal As Double
    Dim dblTotalVal As Double
    Dim dblCGSTValue As Double
    Dim dblSGSTValue As Double
    Dim dblIGSTValue As Double
    Dim trans As OdbcTransaction
    Dim strSQL As String
    Dim csno As Integer = 0
    Dim cpono As Integer = 1
    Dim chsn As Integer = 2
    Dim citem As Integer = 3
    Dim ccoilid As Integer = 5
    Dim cuom As Integer = 6
    Dim obj As Object
    Dim cpoqty As Integer = 7
    Dim cqty As Integer = 8
    Dim cReceivedQty As Integer = 9
    Dim cQtyinPcs As Integer = 10
    Dim crate As Integer = 11
    Dim cValue As Integer = 12
    Dim cDiscount As Integer = 13
    Dim cCGST As Integer = 14
    Dim cSGST As Integer = 15
    Dim cIGST As Integer = 16
    Dim cSlnoKey As Integer = 17
    Dim cUomKey As Integer = 18
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim strDelRecSno As String = ""
    Dim editFlag As Boolean = False
    Dim intCustID As Integer
    Dim intItemId As Integer
    Dim dblRecQty As Double = 0


    Private Sub PurchaseReceipt_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = getUom()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        ds = getItemType()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbItemType.DataSource = ds.Tables(0)
            cmbItemType.DisplayMember = "type_name"
            cmbItemType.ValueMember = "item_type_id"
        End If
        Call initializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)

    End Sub
    Sub InitializeControls()
        Call getSysDateTime()
        dtReceiptDate.Value = gSysDate
        dtVendorInvDate.Value = gSysDate
        dtDeliveryDate.Value = gSysDate
        dtDoDate.Value = gSysDate
        dtLrDate.Value = gSysDate
        dtSoDate.Value = gSysDate
        cmbUom.Text = ""
        txtReceiptID.Text = ""
        txtVendorID.Text = ""
        txtVendorInvNo.Text = ""
        txtVendorInvAmt.Text = ""
        txtVehicleNo.Text = ""
        txtSoNo.Text = ""
        txtDoNo.Text = ""
        txtLrNo.Text = ""
        txtDeliveryNo.Text = ""
        txtPono.Text = ""
        txtItemID.Text = ""
        txtDescription.Text = ""
        txtCoilID.Text = ""
        txtQty.Text = ""
        txtReceivedQty.Text = ""
        txtQtynos.Text = ""
        txtRate.Text = ""
        txtDiscount.Text = ""
        lvwReceipt.Items.Clear()
        txtBillDiscount.Text = ""
        txtRemarks.Text = ""
        txtFrieghtCharges.Text = ""
        txtOtherCharges.Text = ""
        txtTotalVal.Text = ""
        txtTaxable.Text = ""
        txtRoundOff.Text = ""
        txtNetTotal.Text = ""
        txtCGSTTotal.Text = ""
        txtSGSTTotal.Text = ""
        txtIGSTTotal.Text = ""
        lblVenName.Text = ""
        lbladd1.Text = ""
        lbladd2.Text = ""
        lblcity.Text = ""
        chkIsJobwork.Checked = False
        If chkIsJobwork.Checked Then
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = True
        Else
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = False
        End If
        i = 0
        dblCGSTper = 0
        dblSGSTper = 0
        dblIGSTper = 0
        strHSN = ""
        strVenGST = ""
        dblItemValue = 0
        dblTaxable = 0
        dblRoundOff = 0
        dblTotal = 0
        dblcgsttotal = 0
        dblsgsttotal = 0
        dbligsttotal = 0
        dblTotalVal = 0
        dblCGSTValue = 0
        dblSGSTValue = 0
        dblIGSTValue = 0
        thisScreenMode = ScreenMode.Add
    End Sub
    Sub EnableDisable(toggle As Boolean)
        txtReceiptID.Enabled = Not toggle
        dtReceiptDate.Enabled = toggle
        dtVendorInvDate.Enabled = toggle
        dtDeliveryDate.Enabled = toggle
        dtDoDate.Enabled = toggle
        dtLrDate.Enabled = toggle
        dtSoDate.Enabled = toggle
        cmbUom.Enabled = toggle
        txtVendorID.Enabled = toggle
        txtVendorInvNo.Enabled = toggle
        txtVendorInvAmt.Enabled = toggle
        txtVehicleNo.Enabled = toggle
        txtSoNo.Enabled = toggle
        txtDoNo.Enabled = toggle
        txtLrNo.Enabled = toggle
        txtDeliveryNo.Enabled = toggle
        txtPono.Enabled = toggle
        txtItemID.Enabled = toggle
        txtDescription.Enabled = False
        txtCoilID.Enabled = toggle
        txtQty.Enabled = toggle
        txtReceivedQty.Enabled = toggle
        txtQtynos.Enabled = toggle
        txtRate.Enabled = toggle
        txtDiscount.Enabled = toggle
        lvwReceipt.Enabled = toggle
        txtBillDiscount.Enabled = toggle
        txtRemarks.Enabled = toggle
        txtFrieghtCharges.Enabled = toggle
        txtOtherCharges.Enabled = toggle
        grpEntry.Enabled = True
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True

    End Sub

    Public Sub clearItem()
        txtPono.Text = ""
        txtItemID.Text = ""
        txtDescription.Text = ""
        txtCoilID.Text = ""
        txtQty.Text = ""
        txtReceivedQty.Text = ""
        txtRate.Text = ""
        cmbUom.Text = ""
        txtDiscount.Text = ""
        txtQtynos.Text = ""
    End Sub

    Private Sub txtVendorID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtVendorID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getVendor()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtVendorID.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Public Sub populateVenAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblVenName.Text = ds1.Tables(0).Rows(0).Item("ven_name").ToString
            lbladd1.Text = ds1.Tables(0).Rows(0).Item("ven_address1").ToString
            lbladd2.Text = ds1.Tables(0).Rows(0).Item("ven_address2").ToString
            lblcity.Text = ds1.Tables(0).Rows(0).Item("ven_city").ToString
            strVenGST = ds1.Tables(0).Rows(0).Item("ven_gst").ToString
        Else
            MsgBox("Vendor Id Not Found", MsgBoxStyle.Information, gCompanyShortName)
            txtVendorID.Text = ""
            lblVenName.Text = ""
            lbladd1.Text = ""
            lbladd2.Text = ""
            lblcity.Text = ""
            strVenGST = ""
        End If

    End Sub
    Private Sub txtItemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                'ds = getItem()
                ds = getItemList(cmbItemType.SelectedValue)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemID.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemID.Text = "" Then
                ds1 = getItem(CInt(txtItemID.Text))
                Call populateItemDesc(ds1)
            End If
        End If
    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
            strHSN = ds2.Tables(0).Rows(0).Item("hsn").ToString
            dblCGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("cgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("cgst").ToString)))
            dblSGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("sgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("sgst").ToString)))
            dblIGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("igst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("igst").ToString)))
        Else
            dblIGSTper = 0
            dblSGSTper = 0
            dblCGSTper = 0
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If

    End Sub

    Private Sub PurchaseReceipt_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveReceipt()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
        If e.KeyCode = Keys.F2 Then
            Call populateReceiptToEntry()
        End If
    End Sub

    Public Sub saveReceipt()
        Try
            If validateReceipt() Then
                'If validateItem() Then
                Call getSysDateTime()
                    Select Case thisScreenMode
                        Case 1
                            strSQL = "Select nextval('pur_receipt_id_seq') AS pur_receipt_id"
                            obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                            txtReceiptID.Text = obj.ToString
                            'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call insertReceiptHdr()
                            Call insertReceiptTrn()
                            'trans.Commit()
                        Case 2
                            If intDelRecSno > 1 Then
                                strDelRecSno = String.Join(",", arrDelTrn)
                                strDelRecSno = Mid(strDelRecSno, 2)
                            ElseIf intDelRecSno = 1 Then
                                strDelRecSno = arrDelTrn(1).ToString
                            End If
                            Call updateReceiptHdr()
                            Call updateReceiptTrn()

                        Case 3
                            If MsgBox("Are You Sure You want to Delete this GRN ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteReceiptTrn()
                            Call deleteReceiptHdr()
                            'trans.Commit()

                        End If

                    End Select
                    Call InitializeControls()
                End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub insertReceiptHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertReceiptHdr(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text)
            dt = Date.ParseExact(Format(CDate(dtReceiptDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@receiptdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@venid", OdbcType.Int).Value = CInt(txtVendorID.Text.Trim())
            cmd.Parameters.AddWithValue("@veninvamt", OdbcType.Decimal).Value = CDbl(txtVendorInvAmt.Text)
            cmd.Parameters.AddWithValue("@veninvno", OdbcType.NText).Value = txtVendorInvNo.Text
            dt = Date.ParseExact(Format(CDate(dtVendorInvDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@veninvdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@vehicleno", OdbcType.NText).Value = txtVehicleNo.Text
            cmd.Parameters.AddWithValue("@lrno", OdbcType.NText).Value = txtLrNo.Text
            dt = Date.ParseExact(Format(CDate(dtLrDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@lrdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@sono", OdbcType.NText).Value = txtSoNo.Text
            dt = Date.ParseExact(Format(CDate(dtSoDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@sodt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@dono", OdbcType.NText).Value = txtSoNo.Text
            dt = Date.ParseExact(Format(CDate(dtDoDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@dodt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@deliveryno", OdbcType.NText).Value = txtDeliveryNo.Text
            dt = Date.ParseExact(Format(CDate(dtDeliveryDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@deliverydt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@billdiscount", OdbcType.Decimal).Value = Val(txtBillDiscount.Text)
            cmd.Parameters.AddWithValue("@freightcharges", OdbcType.Decimal).Value = Val(txtFrieghtCharges.Text)
            cmd.Parameters.AddWithValue("@othercharges", OdbcType.Decimal).Value = Val(txtOtherCharges.Text)
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = CDbl(txtRoundOff.Text)
            cmd.Parameters.AddWithValue("@remarks", OdbcType.NText).Value = txtRemarks.Text.Trim
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub insertReceiptTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwReceipt.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertReceiptTrn(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text.Trim())
                cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@pono", OdbcType.Int).Value = Val(lvwReceipt.Items(n).SubItems(cpono).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@coilid", OdbcType.Text).Value = lvwReceipt.Items(n).SubItems(ccoilid).Text
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cqty).Text)
                cmd.Parameters.AddWithValue("@recqty", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                cmd.Parameters.AddWithValue("@qtyinnos", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cQtyinPcs).Text)
                cmd.Parameters.AddWithValue("@rate", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(crate).Text)
                cmd.Parameters.AddWithValue("@rdiscount", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cDiscount).Text)
                cmd.Parameters.AddWithValue("@rcgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cCGST).Text)
                cmd.Parameters.AddWithValue("@rsgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cSGST).Text)
                cmd.Parameters.AddWithValue("@rigst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cIGST).Text)

                cmd.ExecuteScalar()
                If Val(lvwReceipt.Items(n).SubItems(cpono).Text) > 0 Then
                    Call updateReceiptInPurchaseOrder(Val(lvwReceipt.Items(n).SubItems(cpono).Text), CInt(lvwReceipt.Items(n).SubItems(citem).Text), Val(lvwReceipt.Items(n).SubItems(cReceivedQty).Text))
                End If
                intCustID = Val(txtCustomerID.Text)
                intItemId = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                dblRecQty = Val(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                Call updateReceiptInStock(intCustID, intItemId, dblRecQty)
            Next
            MsgBox("GRN : " & txtReceiptID.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateReceiptHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateReceiptHdr(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text)
            dt = Date.ParseExact(Format(CDate(dtReceiptDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@receiptdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@venid", OdbcType.Int).Value = CInt(txtVendorID.Text.Trim())
            cmd.Parameters.AddWithValue("@veninvamt", OdbcType.Decimal).Value = CDbl(txtVendorInvAmt.Text)
            cmd.Parameters.AddWithValue("@veninvno", OdbcType.NText).Value = txtVendorInvNo.Text
            dt = Date.ParseExact(Format(CDate(dtVendorInvDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@veninvdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@vehicleno", OdbcType.NText).Value = txtVehicleNo.Text
            cmd.Parameters.AddWithValue("@lrno", OdbcType.NText).Value = txtLrNo.Text
            dt = Date.ParseExact(Format(CDate(dtLrDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@lrdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@sono", OdbcType.NText).Value = txtSoNo.Text
            dt = Date.ParseExact(Format(CDate(dtSoDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@sodt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@dono", OdbcType.NText).Value = txtSoNo.Text
            dt = Date.ParseExact(Format(CDate(dtDoDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@dodt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@deliveryno", OdbcType.NText).Value = txtDeliveryNo.Text
            dt = Date.ParseExact(Format(CDate(dtDeliveryDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@deliverydt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@billdiscount", OdbcType.Decimal).Value = Val(txtBillDiscount.Text)
            cmd.Parameters.AddWithValue("@freightcharges", OdbcType.Decimal).Value = Val(txtFrieghtCharges.Text)
            cmd.Parameters.AddWithValue("@othercharges", OdbcType.Decimal).Value = Val(txtOtherCharges.Text)
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = CDbl(txtRoundOff.Text)
            cmd.Parameters.AddWithValue("@rremarks", OdbcType.NText).Value = txtRemarks.Text.Trim
            cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@modifydt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@modifytm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@modifyby", OdbcType.Int).Value = gUserId
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Sub updateReceiptTrn()
        Dim cmd As New OdbcCommand
        Dim ds1 As DataSet
        Try
            ds1 = getReceiptTrn(CInt(txtReceiptID.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds1.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds1.Tables(0).Rows(n).Item("item_id").ToString)
                    dblRecQty = Val(ds1.Tables(0).Rows(n).Item("received_qty").ToString)
                    Call subtractReceiptInStock(CInt(txtCustomerID.Text), intItemId, dblRecQty)
                Next
            End If
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delReceiptTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text)
                    cmd.Parameters.AddWithValue("@rsno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwReceipt.Items.Count - 1
                If Not lvwReceipt.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateReceiptTrn(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure

                    cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text.Trim())
                    cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@pono", OdbcType.Int).Value = Val(lvwReceipt.Items(n).SubItems(cpono).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@coilid", OdbcType.Text).Value = lvwReceipt.Items(n).SubItems(ccoilid).Text
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@recqty", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                    cmd.Parameters.AddWithValue("@qtyinnnos", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cQtyinPcs).Text)
                    cmd.Parameters.AddWithValue("@rate", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@rcgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@rsgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@rigst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@rdiscount", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cDiscount).Text)
                    cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                    If Val(lvwReceipt.Items(n).SubItems(cpono).Text) > 0 Then
                        Call updateReceiptInPurchaseOrder(Val(lvwReceipt.Items(n).SubItems(cpono).Text), CInt(lvwReceipt.Items(n).SubItems(citem).Text), Val(lvwReceipt.Items(n).SubItems(cqty).Text))
                    End If
                    intCustID = Val(txtCustomerID.Text)
                    intItemId = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                    dblRecQty = Val(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                    Call updateReceiptInStock(intCustID, intItemId, dblRecQty)
                End If
            Next
            For n = 0 To lvwReceipt.Items.Count - 1
                If lvwReceipt.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertReceiptTrn(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text.Trim())
                    cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@pono", OdbcType.Int).Value = Val(lvwReceipt.Items(n).SubItems(cpono).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@coilid", OdbcType.Text).Value = lvwReceipt.Items(n).SubItems(ccoilid).Text
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwReceipt.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@recqty", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                    cmd.Parameters.AddWithValue("@qtyinnos", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(cQtyinPcs).Text)
                    cmd.Parameters.AddWithValue("@rate", OdbcType.Double).Value = CDec(lvwReceipt.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@rcgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@rsgst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@rigst", OdbcType.Double).Value = Val(lvwReceipt.Items(n).SubItems(cIGST).Text)
                    cmd.ExecuteScalar()
                    If Val(lvwReceipt.Items(n).SubItems(cpono).Text) > 0 Then
                        Call updateReceiptInPurchaseOrder(Val(lvwReceipt.Items(n).SubItems(cpono).Text), CInt(lvwReceipt.Items(n).SubItems(citem).Text), Val(lvwReceipt.Items(n).SubItems(cqty).Text))
                    End If
                    intCustID = Val(txtCustomerID.Text)
                    intItemId = CInt(lvwReceipt.Items(n).SubItems(citem).Text)
                    dblRecQty = Val(lvwReceipt.Items(n).SubItems(cReceivedQty).Text)
                    Call updateReceiptInStock(intCustID, intItemId, dblRecQty)
                End If
            Next

            'Call setSerialNumbers
            MsgBox("GRN Number Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteReceiptHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteReceiptHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteReceiptTrn()
        Try
            Dim cmd As New OdbcCommand
            ds1 = getReceiptTrn(CInt(txtReceiptID.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds1.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds1.Tables(0).Rows(n).Item("item_id").ToString)
                    dblRecQty = Val(ds1.Tables(0).Rows(n).Item("received_qty").ToString)
                    Call subtractReceiptInStock(CInt(txtCustomerID.Text), intItemId, dblRecQty)
                Next
            End If
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteReceiptTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtReceiptID.Text)
            cmd.ExecuteScalar()
            MsgBox("GRN : " & txtReceiptID.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Private Function validateReceipt() As Boolean
        If thisScreenMode = ScreenMode.Delete Or thisScreenMode = ScreenMode.Edit Then
            If txtReceiptID.Text = "" Then
                MsgBox("Please Enter Receipt Number", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Else
            If txtVendorID.Text = "" Then
                MsgBox("Supplier ID should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorID.Focus()
                Return False
                Exit Function
            End If
            If txtVendorInvNo.Text = "" Then
                MsgBox("Vendor Invoice Number should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorInvNo.Focus()
                Return False
                Exit Function
            End If
            If txtVendorInvAmt.Text = "" Then
                MsgBox("Vendor Invoice Amount Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorInvAmt.Focus()
                Return False
                Exit Function
            End If
            If lvwReceipt.Items.Count = 0 Then
                MsgBox("Please Add Receipt Item", MsgBoxStyle.Information, gCompanyShortName)
                txtItemID.Focus()
                Return False
                Exit Function
            End If
        End If
        Return True
    End Function
    Private Sub txtVendorID_Leave(sender As Object, e As EventArgs) Handles txtVendorID.Leave
        If Not txtVendorID.Text = "" Then
            ds1 = getVendor(CInt(txtVendorID.Text))
            Call populateVenAddress(ds1)
        End If
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        If editFlag = False Then
            ReceiptAddItem()
        Else
            UpdateReceiptItem()
        End If

    End Sub

    Sub updateReceiptItem()
        ds1 = getItem(CInt(txtItemID.Text))
        Call populateItemDesc(ds1)
        dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
        lvwReceipt.SelectedItems(0).SubItems(cpono).Text = txtPono.Text
        lvwReceipt.SelectedItems(0).SubItems(citem).Text = txtItemID.Text
        lvwReceipt.SelectedItems(0).SubItems(4).Text = txtDescription.Text
        lvwReceipt.SelectedItems(0).SubItems(ccoilid).Text = txtCoilID.Text
        lvwReceipt.SelectedItems(0).SubItems(cuom).Text = cmbUom.Text
        lvwReceipt.SelectedItems(0).SubItems(cqty).Text = txtQty.Text
        lvwReceipt.SelectedItems(0).SubItems(cReceivedQty).Text = txtReceivedQty.Text
        lvwReceipt.SelectedItems(0).SubItems(crate).Text = txtRate.Text
        lvwReceipt.SelectedItems(0).SubItems(cQtyinPcs).Text = txtQtynos.Text
        lvwReceipt.SelectedItems(0).SubItems(cValue).Text = Format(dblItemValue, "#0.00")
        lvwReceipt.SelectedItems(0).SubItems(cDiscount).Text = txtDiscount.Text
        lvwReceipt.SelectedItems(0).SubItems(cqty).Text = Format(Val(txtQty.Text), "#0.000")
        dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
        dblTaxable = dblTaxable - Val(txtDiscount.Text)
        If Mid(strVenGST, 1, 2) = "33" Or strVenGST = "" Then
            dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
            dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
            lvwReceipt.SelectedItems(0).SubItems(cCGST).Text = Format(dblCGSTValue, "#0.00")
            lvwReceipt.SelectedItems(0).SubItems(cSGST).Text = Format(dblSGSTValue, "#0.00")
            lvwReceipt.SelectedItems(0).SubItems(cIGST).Text = ""
        Else
            dblIGSTValue = Math.Round(dblItemValue * dblIGSTper / 100, 2)
            lvwReceipt.SelectedItems(0).SubItems(cCGST).Text = ""
            lvwReceipt.SelectedItems(0).SubItems(cSGST).Text = ""
            lvwReceipt.SelectedItems(0).SubItems(cIGST).Text = Format(dblIGSTValue, "#0.00")
        End If
        lvwReceipt.SelectedItems(0).SubItems(cSlnoKey).Text = ""
        lvwReceipt.SelectedItems(0).SubItems(cUomKey).Text = cmbUom.SelectedValue.ToString
        dblcgsttotal = dblcgsttotal + dblCGSTValue
        dblsgsttotal = dblsgsttotal + dblSGSTValue
        dbligsttotal = dbligsttotal + dblIGSTValue
        dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
        dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
        dblTotal = dblTotalVal - dblRoundOff
        txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
        txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
        txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
        txtTaxable.Text = Format(dblTaxable, "#0.00")
        txtTotalVal.Text = Format(dblTotalVal, "#0.00")
        txtRoundOff.Text = Format(dblRoundOff, "#0.00")
        txtNetTotal.Text = Format(dblTotal, "#0.00")
        Call clearItem()
        editFlag = False
        Call clearItem()
    End Sub

    Sub ReceiptAddItem()
        Try
            If validateItem() Then
                i += 1
                dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
                lvw = lvwReceipt.Items.Add(i.ToString)
                lvw.SubItems.Add(txtPono.Text.ToString)
                lvw.SubItems.Add(strHSN)
                lvw.SubItems.Add(txtItemID.Text.ToString)
                lvw.SubItems.Add(txtDescription.Text.ToString)
                lvw.SubItems.Add(txtCoilID.Text.ToString)
                lvw.SubItems.Add(cmbUom.Text.ToString)
                lvw.SubItems.Add("")
                lvw.SubItems.Add(txtQty.Text.ToString)
                lvw.SubItems.Add(txtReceivedQty.Text.ToString)
                lvw.SubItems.Add(txtQtynos.Text.ToString)
                lvw.SubItems.Add(txtRate.Text.ToString)
                lvw.SubItems.Add(Format(dblItemValue, "#0.00"))
                lvw.SubItems.Add(txtDiscount.Text.ToString)
                dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
                dblTaxable = dblTaxable - Val(txtDiscount.Text)
                If Mid(strVenGST, 1, 2) = "33" Or strVenGST = "" Then
                    dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
                    dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
                    lvw.SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    lvw.SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    lvw.SubItems.Add("")
                Else
                    dblIGSTValue = Math.Round(dblItemValue * dblIGSTper / 100, 2)
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add(Format(dblIGSTValue, "#0.00"))
                End If
                lvw.SubItems.Add("")
                lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
                dblcgsttotal = dblcgsttotal + dblCGSTValue
                dblsgsttotal = dblsgsttotal + dblSGSTValue
                dbligsttotal = dbligsttotal + dblIGSTValue
                dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
                dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                dblTotal = dblTotalVal - dblRoundOff
                txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
                txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
                txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
                txtTaxable.Text = Format(dblTaxable, "#0.00")
                txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                txtNetTotal.Text = Format(dblTotal, "#0.00")
                Call clearItem()
            Else
                Call clearItem()
            End If
            txtItemID.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Function validateItem() As Boolean
        'If lvwReceipt.Items.Count > 0 Then
        '    For n = 0 To lvwReceipt.Items.Count - 1
        '        If Val(lvwReceipt.Items(n).SubItems(cqty).Text.Trim) = 0 Then
        '            MsgBox("Quantity should not be zero in the Receipt Item", MsgBoxStyle.Information, gCompanyShortName)
        '            Return False
        '            Exit Function
        '        End If
        '    Next
        'Else
        If txtItemID.Text.Trim = "" Then
                MsgBox("Please Enter Item Id", MsgBoxStyle.Information, gCompanyShortName)
                txtItemID.Focus()
                Return False
                Exit Function
            End If
            If cmbUom.Text = "" Then
                MsgBox("Please Select UOM", MsgBoxStyle.Information, gCompanyShortName)
                cmbUom.Focus()
                Return False
            End If
            If txtRate.Text = "" Then
                MsgBox("Please Enter Rate", MsgBoxStyle.Information, gCompanyShortName)
                txtRate.Focus()
                Return False
            End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
        End If
        If txtQtynos.Text = "" Then
            MsgBox("Please Enter Quantity in Pcs", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
        End If
        'End If
        Return True
    End Function

    Private Sub cmdAddItem_Click(sender As Object, e As EventArgs) Handles cmdAddItem.Click
        Dim frmItemMaster As New Item
        frmItemMaster.ShowDialog()
    End Sub

    Private Sub txtVendorID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtVendorID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtItemID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtQty.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtReceivedQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtReceivedQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtReceivedQty.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtRate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRate.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtRate.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtDiscount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDiscount.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtDiscount.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtPono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPono.KeyPress

        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtReceiptID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtReceiptID.KeyPress
        If Asc(e.KeyChar) = 13 And txtReceiptID.Text <> "" Then
            ds = getReceiptHdr(CInt(txtReceiptID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateReceiptHdr(CInt(txtReceiptID.Text))
                Call populateReceiptTrn(CInt(txtReceiptID.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This GRN Number", MsgBoxStyle.Information, gCompanyShortName)
                txtPono.Focus()
            End If

        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Sub populateReceiptHdr(intReceiptID As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            dtReceiptDate.Text = ds.Tables(0).Rows(0).Item("pur_receipt_dt").ToString
            txtVendorID.Text = ds.Tables(0).Rows(0).Item("ven_id").ToString
            txtVendorInvAmt.Text = ds.Tables(0).Rows(0).Item("ven_invoice_amt").ToString
            txtVendorInvNo.Text = ds.Tables(0).Rows(0).Item("ven_invoice_no").ToString
            dtVendorInvDate.Text = ds.Tables(0).Rows(0).Item("ven_invoice_dt").ToString
            txtVehicleNo.Text = ds.Tables(0).Rows(0).Item("vehicle_no").ToString
            txtLrNo.Text = ds.Tables(0).Rows(0).Item("lr_no").ToString
            dtLrDate.Text = ds.Tables(0).Rows(0).Item("lr_dt").ToString
            txtSoNo.Text = ds.Tables(0).Rows(0).Item("so_no").ToString
            dtSoDate.Text = ds.Tables(0).Rows(0).Item("so_dt").ToString
            txtDoNo.Text = ds.Tables(0).Rows(0).Item("do_no").ToString
            dtDoDate.Text = ds.Tables(0).Rows(0).Item("do_dt").ToString
            txtDeliveryNo.Text = ds.Tables(0).Rows(0).Item("delivery_no").ToString
            dtDeliveryDate.Text = ds.Tables(0).Rows(0).Item("delivery_dt").ToString
            txtBillDiscount.Text = ds.Tables(0).Rows(0).Item("bill_discount").ToString
            txtFrieghtCharges.Text = ds.Tables(0).Rows(0).Item("freight_charges").ToString
            txtOtherCharges.Text = ds.Tables(0).Rows(0).Item("other_charges").ToString
            txtRoundOff.Text = ds.Tables(0).Rows(0).Item("round_off").ToString
            txtRemarks.Text = ds.Tables(0).Rows(0).Item("remarks").ToString
            ds1 = getVendor(CInt(txtVendorID.Text))
            populateVenAddress(ds1)
        End If
    End Sub


    Sub populateReceiptTrn(intReceiptID As Integer)
        ds = getReceiptTrn(intReceiptID)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                dblCGSTValue = 0
                dblSGSTValue = 0
                dblIGSTValue = 0
                lvw = lvwReceipt.Items.Add(ds.Tables(0).Rows(n).Item("sno").ToString)
                With lvw
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_id").ToString)
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("hsn").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    Else
                        .SubItems.Add("")
                        .SubItems.Add("")
                        .SubItems.Add("")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("coil_id").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    ds2 = getPOTrn(Val(ds.Tables(0).Rows(n).Item("po_id").ToString), CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds2.Tables(0).Rows.Count > 0 Then
                        If Val(ds2.Tables(0).Rows(0).Item("po_qty").ToString) > 0 Then
                            .SubItems.Add(ds2.Tables(0).Rows(0).Item("po_qty").ToString)
                        End If
                    Else
                        .SubItems.Add("0")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("received_qty").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("quantity_innos").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("rate").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("quantity")) Then
                        .SubItems.Add("")
                    Else
                        .SubItems.Add(Format(CDbl(ds.Tables(0).Rows(n).Item("rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("quantity").ToString), "#0.00"))
                    End If
                    If Val(ds.Tables(0).Rows(n).Item("discount").ToString) > 0 Then
                        .SubItems.Add(ds.Tables(0).Rows(n).Item("discount").ToString)
                    Else
                        .SubItems.Add("0")
                    End If
                    dblCGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("cgst")), 0, ds.Tables(0).Rows(n).Item("cgst").ToString))
                    .SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    dblSGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("sgst")), 0, ds.Tables(0).Rows(n).Item("sgst").ToString))
                    .SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    dblIGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("igst")), 0, ds.Tables(0).Rows(n).Item("igst").ToString))
                    .SubItems.Add(Format(dblIGSTValue, "#0.00"))
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("quantity")) Then
                    Else
                        dblTaxable = dblTaxable + CDbl(ds.Tables(0).Rows(n).Item("rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("quantity").ToString)
                        dblcgsttotal = dblcgsttotal + dblCGSTValue
                        dblsgsttotal = dblsgsttotal + dblSGSTValue
                        dbligsttotal = dbligsttotal + dblIGSTValue
                        dblCGSTValue = 0
                        dblSGSTValue = 0
                        dblIGSTValue = 0
                    End If

                End With
                'If Val(ds.Tables(0).Rows(n).Item("po_id").ToString) > 0 Then
                'Call updateReceiptInPurchaseOrder(Val(ds.Tables(0).Rows(n).Item("po_id").ToString), CInt(ds.Tables(0).Rows(n).Item("item_id").ToString), Val(ds.Tables(0).Rows(n).Item("quantity").ToString))
                'End If
                i += 1
            Next
            dblTotalVal = dblTotalVal + dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
            dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
            dblTotal = dblTotalVal - dblRoundOff
            txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
            txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
            txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
            txtTaxable.Text = Format(dblTaxable, "#0.00")
            txtTotalVal.Text = Format(dblTotalVal, "#0.00")
            txtRoundOff.Text = Format(dblRoundOff, "#0.00")
            txtNetTotal.Text = Format(dblTotal, "#0.00")

        End If
    End Sub
    Private Sub txtVendorInvAmt_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtVendorInvAmt.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtVendorInvAmt.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtBillDiscount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBillDiscount.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtBillDiscount.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtFrieghtCharges_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFrieghtCharges.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtFrieghtCharges.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtOtherCharges_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtOtherCharges.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtOtherCharges.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub cmbUom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPono_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPono.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getPO()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtPono.Text = rTagValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Order Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtReceiptID.Focus()
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtReceiptID.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveReceipt()
        'Call MovetoStock(31)
    End Sub

    Private Sub lvwReceipt_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwReceipt.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwReceipt.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        dblItemValue = (CDbl(lvwReceipt.SelectedItems(0).SubItems(crate).Text) * CDbl(lvwReceipt.SelectedItems(0).SubItems(cqty).Text))
                        ds1 = getItem(CInt(lvwReceipt.SelectedItems(0).SubItems(citem).Text.ToString))
                        If ds1.Tables(0).Rows.Count > 0 Then
                            dblCGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("cgst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("cgst").ToString)))
                            dblSGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("sgst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("sgst").ToString)))
                            dblIGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("igst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("igst").ToString)))
                        End If
                        dblTotal = dblTotal - dblItemValue
                        dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
                        dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
                        dblcgsttotal = dblcgsttotal - dblCGSTValue
                        dblsgsttotal = dblsgsttotal - dblSGSTValue
                        dbligsttotal = dbligsttotal - dblIGSTValue
                        dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
                        dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                        dblTotal = dblTotalVal - dblRoundOff
                        txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
                        txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
                        txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
                        txtTaxable.Text = Format(dblTaxable, "#0.00")
                        txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                        txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                        txtNetTotal.Text = Format(dblTotal, "#0.00")
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwReceipt.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwReceipt.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwReceipt.Items.RemoveAt(lvwReceipt.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub setSlno()
        i = 0
        For n = 0 To lvwReceipt.Items.Count - 1
            i += 1
            lvwReceipt.Items(n).Text = i.ToString
        Next
    End Sub

    Private Sub txtFrieghtCharges_TextChanged(sender As Object, e As EventArgs) Handles txtFrieghtCharges.TextChanged
        txtTaxable.Text = dblTaxable.ToString
        txtTaxable.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text)
        If Mid(strVenGST, 1, 2) = "33" Or strVenGST = "" Then
            txtCGSTTotal.Text = Val(txtTaxable.Text) * 0.09
            txtSGSTTotal.Text = Val(txtTaxable.Text) * 0.09
        Else
            txtIGSTTotal.Text = Val(txtTaxable.Text) * 0.18
        End If
        txtNetTotal.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text) + Val(txtCGSTTotal.Text) + Val(txtSGSTTotal.Text) + Val(txtIGSTTotal.Text)
    End Sub

    Private Sub txtOtherCharges_TextChanged(sender As Object, e As EventArgs) Handles txtOtherCharges.TextChanged
        txtTaxable.Text = dblTaxable.ToString
        txtTaxable.Text = Val(txtTaxable.Text) + Val(txtOtherCharges.Text) + Val(txtFrieghtCharges.Text)
        If Mid(strVenGST, 1, 2) = "33" Or strVenGST = "" Then
            txtCGSTTotal.Text = Val(txtTaxable.Text) * 0.09
            txtSGSTTotal.Text = Val(txtTaxable.Text) * 0.09
        Else
            txtIGSTTotal.Text = Val(txtTaxable.Text) * 0.18
        End If
        txtNetTotal.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text) + Val(txtCGSTTotal.Text) + Val(txtSGSTTotal.Text) + Val(txtIGSTTotal.Text)
    End Sub

    Private Sub txtPono_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtPono.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtPono.Text <> "" Then
            If validatePO Then
                populatePOTrn(CInt(txtPono.Text))
            End If
        End If
    End Sub
    Public Function validatePO() As Boolean
        For n = 0 To lvwReceipt.Items.Count - 1
            If txtPono.Text.Trim = lvwReceipt.Items(n).SubItems(cpono).Text.Trim Then
                MsgBox("Purchase Order Number Already Exists", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Next
        Return True
    End Function

    Sub populatePOTrn(ByVal intPoNo As Integer)
        ds = getPOTrn(intPoNo)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                i += 1
                lvw = lvwReceipt.Items.Add(i.ToString)
                With lvw

                    .SubItems.Add(txtPono.Text.Trim)
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("hsn").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    End If
                    .SubItems.Add("")
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_qty").ToString)
                    .SubItems.Add("0.000")
                    .SubItems.Add("0.000")
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_rate").ToString)
                    .SubItems.Add("0.00")
                    .SubItems.Add("0.00")
                    .SubItems.Add("0.00")
                    .SubItems.Add("0.00")
                    .SubItems.Add("0.00")
                    .SubItems.Add("")
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                End With
            Next
        Else
            MsgBox("Purchases Order Number not Found... Press 'F9' to Search", MsgBoxStyle.Information, gCompanyShortName)
        End If
        txtPono.Text = ""
        txtPono.Focus()
    End Sub

    Sub populateReceiptToEntry()
        If Not lvwReceipt.SelectedItems Is Nothing Then
            editFlag = True
            txtPono.Text = lvwReceipt.SelectedItems(0).SubItems(cpono).Text
            txtItemID.Text = lvwReceipt.SelectedItems(0).SubItems(citem).Text
            ds1 = getItem(CInt(txtItemID.Text))
            txtDescription.Text = ds1.Tables(0).Rows(0).Item("item_description").ToString
            txtCoilID.Text = lvwReceipt.SelectedItems(0).SubItems(ccoilid).Text
            cmbUom.Text = lvwReceipt.SelectedItems(0).SubItems(cuom).Text
            txtQty.Text = lvwReceipt.SelectedItems(0).SubItems(cqty).Text
            txtReceivedQty.Text = lvwReceipt.SelectedItems(0).SubItems(cReceivedQty).Text
            txtQtynos.Text = lvwReceipt.SelectedItems(0).SubItems(cQtyinPcs).Text
            txtRate.Text = lvwReceipt.SelectedItems(0).SubItems(crate).Text
            txtDiscount.Text = lvwReceipt.SelectedItems(0).SubItems(cDiscount).Text
        End If
    End Sub

    Private Sub lvwReceipt_DoubleClick(sender As Object, e As EventArgs) Handles lvwReceipt.DoubleClick
        Call populateReceiptToEntry()
    End Sub

    Private Sub txtReceiptID_TextChanged(sender As Object, e As EventArgs) Handles txtReceiptID.TextChanged

    End Sub

    Private Sub txtCustomerID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Customer Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub chkIsJobwork_CheckedChanged(sender As Object, e As EventArgs) Handles chkIsJobwork.CheckedChanged
        If chkIsJobwork.Checked Then
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = True
        Else
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = False
        End If
    End Sub

    Private Sub grpEntry_Enter(sender As Object, e As EventArgs) Handles grpEntry.Enter

    End Sub

    Private Sub txtCustomerID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtCustomerID_Leave(sender As Object, e As EventArgs) Handles txtCustomerID.Leave
        If Not txtCustomerID.Text = "" Then
            ds1 = getCustomer(CInt(txtCustomerID.Text))
            Call populateCustAddress(ds1)
        End If
    End Sub
    Public Sub populateCustAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblCustName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
        Else
            MsgBox("No Customer Id Found", MsgBoxStyle.Information, gCompanyShortName)
            txtCustomerID.Text = ""
            lblCustName.Text = ""
        End If
    End Sub

    Public Sub MovetoStock(intReceiptid As Integer)
        Dim intItemTypeID As Integer
        Dim intItemID As Integer
        ds = getReceiptTrn(intReceiptid)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                intItemID = CInt(ds.Tables(0).Rows(n).Item("Item_id").ToString)
                ds1 = getItem(intItemID)
                If ds1.Tables(0).Rows.Count > 0 Then
                    intItemTypeID = CInt(ds1.Tables(0).Rows(0).Item("type_id"))
                End If
                strScode = generateScode(intItemTypeID)
                MsgBox(strScode)
            Next
        End If

    End Sub
    Public Function generateScode(intItemType As Integer) As String
        Try
            ds2 = getScode(intItemType)
            If ds2.Tables(0).Rows.Count > 0 Then
                generateScode = ds2.Tables(0).Rows(0).Item("StkCode").ToString
                Return generateScode
                Exit Function
            End If
            Return Nothing
        Catch ex As Exception
            MsgBox("Invalid stock code", MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Private Sub cmbItemType_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbItemType.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbItemType.Text
        Dim typedT As String = t.Substring(0, cmbItemType.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbItemType.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub
End Class