﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 09-01-2018
' Time: 10:58
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports VST.Main
Imports VST.Masters
Imports VST.Constants

Public Partial Class VST
	Inherits Form
	
	Dim dsm As New DataSet
	Dim DbCon As New ODBCDataAccsess
	Dim strSQL As String = ""
	
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub


    Sub VSTLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            dsm = GetMainMenu(0)
            If dsm.Tables(0).Rows.Count > 0 Then
                Call PopulateMenu(dsm, 0, Nothing)
            End If
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
        End Try
    End Sub

    Private Sub PopulateMenu(ds As DataSet, parentMenuId As Integer, parentMenuItem As ToolStripMenuItem)
		Try
			For i = 0 To ds.Tables(0).Rows.Count-1
				Dim tsmi As New ToolStripMenuItem() 
				
				With tsmi 
					 .Tag =  ds.Tables(0).Rows(i).Item("MENU_ID").ToString
	 		         .Text = ds.Tables(0).Rows(i).Item("TITLE").ToString.Trim
				End With
		        If parentMenuId = 0 Then
		        	Dim dsChild As DataSet = GetMainMenu(Integer.Parse(tsmi.Tag.ToString))
		        	PopulateMenu(dsChild, Integer.Parse(tsmi.Tag.ToString), tsmi)
		        	mnuMain.Items.Add(tsmi)
		        	AddHandler tsmi.Click, AddressOf Main.tsmi_Click
		        Else
		        	parentMenuItem.DropDownItems.Add(tsmi) 
		        	AddHandler tsmi.Click, AddressOf Main.tsmi_Click
		        End If
			Next
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)		
		End try
	End Sub
	
End Class





