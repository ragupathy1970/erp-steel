﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SlitProduction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpSlitHdr = New System.Windows.Forms.GroupBox()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.chkIsJobwork = New System.Windows.Forms.CheckBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtCoilID = New System.Windows.Forms.TextBox()
        Me.lblCoilName = New System.Windows.Forms.Label()
        Me.lblMachine = New System.Windows.Forms.Label()
        Me.txtMachineID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtScode = New System.Windows.Forms.TextBox()
        Me.grpShift = New System.Windows.Forms.GroupBox()
        Me.rdoShift4 = New System.Windows.Forms.RadioButton()
        Me.rdoShift3 = New System.Windows.Forms.RadioButton()
        Me.rdoShift2 = New System.Windows.Forms.RadioButton()
        Me.rdoShift1 = New System.Windows.Forms.RadioButton()
        Me.label1 = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtSlitId = New System.Windows.Forms.TextBox()
        Me.dtSlit = New System.Windows.Forms.DateTimePicker()
        Me.grpSlitTrn = New System.Windows.Forms.GroupBox()
        Me.lvwSlit = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colWidth = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.grpSlitEntry = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtWidth = New System.Windows.Forms.TextBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtItemId = New System.Windows.Forms.TextBox()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpSlitHdr.SuspendLayout()
        Me.grpShift.SuspendLayout()
        Me.grpSlitTrn.SuspendLayout()
        Me.grpSlitEntry.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpSlitHdr
        '
        Me.grpSlitHdr.Controls.Add(Me.lblCustName)
        Me.grpSlitHdr.Controls.Add(Me.txtCustomerID)
        Me.grpSlitHdr.Controls.Add(Me.chkIsJobwork)
        Me.grpSlitHdr.Controls.Add(Me.Label13)
        Me.grpSlitHdr.Controls.Add(Me.txtCoilID)
        Me.grpSlitHdr.Controls.Add(Me.lblCoilName)
        Me.grpSlitHdr.Controls.Add(Me.lblMachine)
        Me.grpSlitHdr.Controls.Add(Me.txtMachineID)
        Me.grpSlitHdr.Controls.Add(Me.Label12)
        Me.grpSlitHdr.Controls.Add(Me.Label3)
        Me.grpSlitHdr.Controls.Add(Me.txtScode)
        Me.grpSlitHdr.Controls.Add(Me.grpShift)
        Me.grpSlitHdr.Controls.Add(Me.label1)
        Me.grpSlitHdr.Controls.Add(Me.label7)
        Me.grpSlitHdr.Controls.Add(Me.txtSlitId)
        Me.grpSlitHdr.Controls.Add(Me.dtSlit)
        Me.grpSlitHdr.Location = New System.Drawing.Point(15, 31)
        Me.grpSlitHdr.Name = "grpSlitHdr"
        Me.grpSlitHdr.Size = New System.Drawing.Size(744, 119)
        Me.grpSlitHdr.TabIndex = 0
        Me.grpSlitHdr.TabStop = False
        '
        'lblCustName
        '
        Me.lblCustName.Location = New System.Drawing.Point(209, 94)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(254, 15)
        Me.lblCustName.TabIndex = 87
        '
        'txtCustomerID
        '
        Me.txtCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCustomerID.Location = New System.Drawing.Point(128, 90)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.Size = New System.Drawing.Size(75, 22)
        Me.txtCustomerID.TabIndex = 86
        '
        'chkIsJobwork
        '
        Me.chkIsJobwork.AutoSize = True
        Me.chkIsJobwork.Location = New System.Drawing.Point(38, 92)
        Me.chkIsJobwork.Name = "chkIsJobwork"
        Me.chkIsJobwork.Size = New System.Drawing.Size(82, 20)
        Me.chkIsJobwork.TabIndex = 85
        Me.chkIsJobwork.Text = "Job Work"
        Me.chkIsJobwork.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.Transparent
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label13.Location = New System.Drawing.Point(221, 20)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(47, 19)
        Me.Label13.TabIndex = 45
        Me.Label13.Text = "Coil ID"
        '
        'txtCoilID
        '
        Me.txtCoilID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCoilID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCoilID.Location = New System.Drawing.Point(274, 18)
        Me.txtCoilID.Name = "txtCoilID"
        Me.txtCoilID.Size = New System.Drawing.Size(87, 22)
        Me.txtCoilID.TabIndex = 5
        '
        'lblCoilName
        '
        Me.lblCoilName.Location = New System.Drawing.Point(370, 22)
        Me.lblCoilName.Name = "lblCoilName"
        Me.lblCoilName.Size = New System.Drawing.Size(237, 16)
        Me.lblCoilName.TabIndex = 43
        '
        'lblMachine
        '
        Me.lblMachine.Location = New System.Drawing.Point(321, 77)
        Me.lblMachine.Name = "lblMachine"
        Me.lblMachine.Size = New System.Drawing.Size(116, 24)
        Me.lblMachine.TabIndex = 42
        '
        'txtMachineID
        '
        Me.txtMachineID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMachineID.Location = New System.Drawing.Point(273, 72)
        Me.txtMachineID.Name = "txtMachineID"
        Me.txtMachineID.Size = New System.Drawing.Size(42, 22)
        Me.txtMachineID.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(175, 74)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(99, 18)
        Me.Label12.TabIndex = 40
        Me.Label12.Text = "Slit Machine ID"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(224, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(50, 19)
        Me.Label3.TabIndex = 33
        Me.Label3.Text = "SCode"
        '
        'txtScode
        '
        Me.txtScode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtScode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtScode.Location = New System.Drawing.Point(274, 45)
        Me.txtScode.Name = "txtScode"
        Me.txtScode.Size = New System.Drawing.Size(87, 22)
        Me.txtScode.TabIndex = 2
        '
        'grpShift
        '
        Me.grpShift.Controls.Add(Me.rdoShift4)
        Me.grpShift.Controls.Add(Me.rdoShift3)
        Me.grpShift.Controls.Add(Me.rdoShift2)
        Me.grpShift.Controls.Add(Me.rdoShift1)
        Me.grpShift.Location = New System.Drawing.Point(654, 12)
        Me.grpShift.Name = "grpShift"
        Me.grpShift.Size = New System.Drawing.Size(81, 95)
        Me.grpShift.TabIndex = 7
        Me.grpShift.TabStop = False
        Me.grpShift.Text = "Shift"
        '
        'rdoShift4
        '
        Me.rdoShift4.AutoSize = True
        Me.rdoShift4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift4.Location = New System.Drawing.Point(25, 72)
        Me.rdoShift4.Name = "rdoShift4"
        Me.rdoShift4.Size = New System.Drawing.Size(35, 20)
        Me.rdoShift4.TabIndex = 3
        Me.rdoShift4.TabStop = True
        Me.rdoShift4.Text = "G"
        Me.rdoShift4.UseVisualStyleBackColor = True
        '
        'rdoShift3
        '
        Me.rdoShift3.AutoSize = True
        Me.rdoShift3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift3.Location = New System.Drawing.Point(26, 54)
        Me.rdoShift3.Name = "rdoShift3"
        Me.rdoShift3.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift3.TabIndex = 2
        Me.rdoShift3.TabStop = True
        Me.rdoShift3.Text = "C"
        Me.rdoShift3.UseVisualStyleBackColor = True
        '
        'rdoShift2
        '
        Me.rdoShift2.AutoSize = True
        Me.rdoShift2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift2.Location = New System.Drawing.Point(26, 37)
        Me.rdoShift2.Name = "rdoShift2"
        Me.rdoShift2.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift2.TabIndex = 1
        Me.rdoShift2.TabStop = True
        Me.rdoShift2.Text = "B"
        Me.rdoShift2.UseVisualStyleBackColor = True
        '
        'rdoShift1
        '
        Me.rdoShift1.AutoSize = True
        Me.rdoShift1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.rdoShift1.Location = New System.Drawing.Point(26, 20)
        Me.rdoShift1.Name = "rdoShift1"
        Me.rdoShift1.Size = New System.Drawing.Size(34, 20)
        Me.rdoShift1.TabIndex = 7
        Me.rdoShift1.TabStop = True
        Me.rdoShift1.Text = "A"
        Me.rdoShift1.UseVisualStyleBackColor = True
        '
        'label1
        '
        Me.label1.BackColor = System.Drawing.Color.Transparent
        Me.label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.label1.Location = New System.Drawing.Point(30, 22)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(46, 19)
        Me.label1.TabIndex = 28
        Me.label1.Text = "Slit ID"
        '
        'label7
        '
        Me.label7.BackColor = System.Drawing.Color.Transparent
        Me.label7.Location = New System.Drawing.Point(39, 51)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(36, 20)
        Me.label7.TabIndex = 27
        Me.label7.Text = "Date"
        '
        'txtSlitId
        '
        Me.txtSlitId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSlitId.Location = New System.Drawing.Point(80, 18)
        Me.txtSlitId.Name = "txtSlitId"
        Me.txtSlitId.Size = New System.Drawing.Size(87, 22)
        Me.txtSlitId.TabIndex = 1
        '
        'dtSlit
        '
        Me.dtSlit.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtSlit.CustomFormat = "dd-MMM-yyyy"
        Me.dtSlit.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtSlit.Location = New System.Drawing.Point(79, 50)
        Me.dtSlit.Name = "dtSlit"
        Me.dtSlit.Size = New System.Drawing.Size(99, 22)
        Me.dtSlit.TabIndex = 3
        Me.dtSlit.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'grpSlitTrn
        '
        Me.grpSlitTrn.Controls.Add(Me.lvwSlit)
        Me.grpSlitTrn.Location = New System.Drawing.Point(8, 239)
        Me.grpSlitTrn.Name = "grpSlitTrn"
        Me.grpSlitTrn.Size = New System.Drawing.Size(751, 165)
        Me.grpSlitTrn.TabIndex = 1
        Me.grpSlitTrn.TabStop = False
        '
        'lvwSlit
        '
        Me.lvwSlit.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwSlit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwSlit.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colItemid, Me.colDescription, Me.colWidth, Me.colQty, Me.colSlnoKey})
        Me.lvwSlit.FullRowSelect = True
        Me.lvwSlit.GridLines = True
        Me.lvwSlit.Location = New System.Drawing.Point(12, 17)
        Me.lvwSlit.MultiSelect = False
        Me.lvwSlit.Name = "lvwSlit"
        Me.lvwSlit.Size = New System.Drawing.Size(725, 132)
        Me.lvwSlit.TabIndex = 1
        Me.lvwSlit.UseCompatibleStateImageBehavior = False
        Me.lvwSlit.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 59
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 98
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colWidth
        '
        Me.colWidth.Text = "Actual Width"
        Me.colWidth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colWidth.Width = 100
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'grpSlitEntry
        '
        Me.grpSlitEntry.Controls.Add(Me.Label10)
        Me.grpSlitEntry.Controls.Add(Me.txtWidth)
        Me.grpSlitEntry.Controls.Add(Me.cmdAdd)
        Me.grpSlitEntry.Controls.Add(Me.Label9)
        Me.grpSlitEntry.Controls.Add(Me.Label8)
        Me.grpSlitEntry.Controls.Add(Me.txtQty)
        Me.grpSlitEntry.Controls.Add(Me.txtDescription)
        Me.grpSlitEntry.Controls.Add(Me.Label6)
        Me.grpSlitEntry.Controls.Add(Me.txtItemId)
        Me.grpSlitEntry.ForeColor = System.Drawing.SystemColors.ControlText
        Me.grpSlitEntry.Location = New System.Drawing.Point(13, 156)
        Me.grpSlitEntry.Name = "grpSlitEntry"
        Me.grpSlitEntry.Size = New System.Drawing.Size(746, 67)
        Me.grpSlitEntry.TabIndex = 1
        Me.grpSlitEntry.TabStop = False
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(507, 13)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(68, 19)
        Me.Label10.TabIndex = 37
        Me.Label10.Text = "Act.Width"
        '
        'txtWidth
        '
        Me.txtWidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWidth.Location = New System.Drawing.Point(512, 35)
        Me.txtWidth.Name = "txtWidth"
        Me.txtWidth.Size = New System.Drawing.Size(62, 22)
        Me.txtWidth.TabIndex = 10
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(647, 27)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 12
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label9.Location = New System.Drawing.Point(585, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(32, 19)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "Qty"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(169, 16)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "Item Description"
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(580, 35)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(62, 22)
        Me.txtQty.TabIndex = 11
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(166, 35)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(342, 22)
        Me.txtDescription.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(75, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Item ID"
        '
        'txtItemId
        '
        Me.txtItemId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemId.Location = New System.Drawing.Point(72, 36)
        Me.txtItemId.Name = "txtItemId"
        Me.txtItemId.Size = New System.Drawing.Size(87, 22)
        Me.txtItemId.TabIndex = 8
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(481, 413)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 14
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(670, 413)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 16
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(577, 413)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 15
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(385, 412)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 13
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'SlitProduction
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(782, 466)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpSlitEntry)
        Me.Controls.Add(Me.grpSlitTrn)
        Me.Controls.Add(Me.grpSlitHdr)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "SlitProduction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Production Slit"
        Me.grpSlitHdr.ResumeLayout(False)
        Me.grpSlitHdr.PerformLayout()
        Me.grpShift.ResumeLayout(False)
        Me.grpShift.PerformLayout()
        Me.grpSlitTrn.ResumeLayout(False)
        Me.grpSlitEntry.ResumeLayout(False)
        Me.grpSlitEntry.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpSlitHdr As System.Windows.Forms.GroupBox
    Friend WithEvents grpSlitTrn As System.Windows.Forms.GroupBox
    Friend WithEvents grpSlitEntry As System.Windows.Forms.GroupBox
    Private WithEvents dtSlit As System.Windows.Forms.DateTimePicker
    Private WithEvents txtSlitId As System.Windows.Forms.TextBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtScode As System.Windows.Forms.TextBox
    Friend WithEvents grpShift As System.Windows.Forms.GroupBox
    Friend WithEvents rdoShift4 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift1 As System.Windows.Forms.RadioButton
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents txtItemId As System.Windows.Forms.TextBox
    Private WithEvents Label9 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents lvwSlit As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Friend WithEvents colWidth As System.Windows.Forms.ColumnHeader
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents txtWidth As System.Windows.Forms.TextBox
    Private WithEvents txtMachineID As System.Windows.Forms.TextBox
    Private WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblCoilName As System.Windows.Forms.Label
    Friend WithEvents lblMachine As System.Windows.Forms.Label
    Private WithEvents Label13 As System.Windows.Forms.Label
    Private WithEvents txtCoilID As System.Windows.Forms.TextBox
    Private WithEvents lblCustName As System.Windows.Forms.Label
    Private WithEvents txtCustomerID As System.Windows.Forms.TextBox
    Friend WithEvents chkIsJobwork As System.Windows.Forms.CheckBox
End Class
