﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production
Public Class StoppageDetail
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim ds1 As DataSet
    Dim obj As Object
    Dim intStoppageID As Integer
    Dim strSQL As String
    Dim intTotalStoppageTime As Double
    Dim intTimeFrom As Integer
    Dim intTimeTo As Integer
    Dim trans As OdbcTransaction
    Dim dt As Date

    Private Sub StoppageDetail_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveStoppage()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Public Sub InitializeControls()
        Call getSysDateTime()
        dtStoppageDate.Value = gSysDate
        txtStoppageID.Text = ""
        txtMachineID.Text = ""
        txtRemarks.Text = ""
        cmbTimeFromHrs.Text = ""
        cmbTimeFromMnts.Text = ""
        cmbTimeToHrs.Text = ""
        cmbTimeToMnts.Text = ""
        txtTotalDuration.Text = ""

    End Sub

    Public Sub EnableDisable(toggle As Boolean)
        txtStoppageID.Enabled = Not toggle
        dtStoppageDate.Enabled = toggle
        txtMachineID.Enabled = toggle
        txtTotalDuration.Enabled = False
        cmbTimeFromHrs.Enabled = toggle
        cmbTimeFromMnts.Enabled = toggle
        cmbTimeToHrs.Enabled = toggle
        cmbTimeToMnts.Enabled = toggle
        txtRemarks.Enabled = toggle
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveStoppage()
    End Sub

    Private Sub saveStoppage()
        Try
            If validateStoppage() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "SELECT max(stoppage_id) AS stoppage_id FROM public.pro_stoppage"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        If IsDBNull(obj) Then
                            intStoppageID = 1
                        Else
                            intStoppageID = CInt(obj.ToString) + 1
                        End If
                        txtstoppageID.Text = intstoppageid.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertStoppage()
                        trans.Commit
                        MsgBox("Stoppage Id : " & txtStoppageID.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
                    Case 2
                        Call UpdateStoppage()
                        MsgBox("Soppage Modified", MsgBoxStyle.Information, gCompanyShortName)
                    Case 3
                        If MsgBox("Are you sure you want to delete this stoppage detail ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteStoppage()
                            trans.Commit()
                            MsgBox("Stoppage ID : " & txtStoppageID.Text & " Deleted", MsgBoxStyle.Information, gCompanyShortName)
                        End If

                End Select
                Call initializeControls()
                cmdEdit.Enabled = True
                cmdDelete.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call initializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try

    End Sub

    Sub InsertStoppage()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertStoppage(?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@stoppageId", OdbcType.Int).Value = CInt(txtStoppageID.Text)
            dt = Date.ParseExact(Format(CDate(dtStoppageDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@stoppagedt", OdbcType.Int).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@machineid", OdbcType.Int).Value = txtMachineID.Text.Trim
            cmd.Parameters.AddWithValue("@timefrom", OdbcType.Decimal).Value = CInt(cmbTimeFromHrs.Text) + (cmbTimeFromMnts.Text / 100)
            cmd.Parameters.AddWithValue("@timeto", OdbcType.Decimal).Value = CInt(cmbTimeToHrs.Text) + (cmbTimeToMnts.Text / 100)
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.Parameters.AddWithValue("@remarks", OdbcType.NText).Value = txtRemarks.Text
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub


    Sub UpdateStoppage()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.UpdateStoppage(?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@stoppageId", OdbcType.Int).Value = CInt(txtStoppageID.Text)
            dt = Date.ParseExact(Format(CDate(dtStoppageDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@stoppagedt", OdbcType.Int).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@machineid", OdbcType.NText).Value = txtMachineID.Text.Trim
            cmd.Parameters.AddWithValue("@timefrom", OdbcType.Decimal).Value = CInt(cmbTimeFromHrs.Text) + (cmbTimeFromMnts.Text / 100)
            cmd.Parameters.AddWithValue("@timeto", OdbcType.Decimal).Value = CInt(cmbTimeToHrs.Text) + (cmbTimeToMnts.Text / 100)
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.Parameters.AddWithValue("@sremarks", OdbcType.NText).Value = txtRemarks.Text
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteStoppage()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteStoppage(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@Stoppageid", OdbcType.Int).Value = CInt(txtStoppageID.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub populateStoppage()
        ds = getStoppage(Val(txtStoppageID.Text))
        If ds.Tables(0).Rows.Count > 0 Then
            txtStoppageID.Text = ds.Tables(0).Rows(0).Item("stoppage_id").ToString
            txtMachineID.Text = ds.Tables(0).Rows(0).Item("mill_id").ToString
            ds1 = getMill(Val(txtMachineID.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                lblMachine.Text = ds1.Tables(0).Rows(0).Item("mill_name").ToString
            End If
            Select Case ds.Tables(0).Rows(0).Item("pro_shift").ToString
                Case "A"
                    rdoShift1.Checked = True
                Case "B"
                    rdoShift2.Checked = True
                Case "C"
                    rdoShift3.Checked = True
                Case Else
                    rdoShift4.Checked = True
            End Select
            cmbTimeFromHrs.Text = CInt(ds.Tables(0).Rows(0).Item("time_from").ToString)
            cmbTimeFromMnts.Text = (Val(ds.Tables(0).Rows(0).Item("time_from").ToString) - CInt(ds.Tables(0).Rows(0).Item("time_from").ToString)) * 100
            cmbTimeToHrs.Text = CInt(ds.Tables(0).Rows(0).Item("time_to").ToString)
            cmbTimeToMnts.Text = Format((Val(ds.Tables(0).Rows(0).Item("time_to").ToString) - CInt(ds.Tables(0).Rows(0).Item("time_to").ToString)) * 100, "#0")
            txtRemarks.Text = ds.Tables(0).Rows(0).Item("remarks").ToString
        End If
        EnableDisable(True)
    End Sub

    Public Function validateStoppage() As Boolean
        If thisScreenMode = 2 Or thisScreenMode = 3 Then
            If txtStoppageID.Text = "" Then
                MsgBox("Stoppage Id is Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtStoppageID.Focus()
                Return False
                Exit Function
            End If
            Return True
        Else
            If txtMachineID.Text = "" Then
                MsgBox("Machine id should not be empty", MsgBoxStyle.Information, gCompanyShortName)
                txtMachineID.Focus()
                Return False
                Exit Function
            End If
            Return True
        End If
    End Function

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtStoppageID.Focus()
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtStoppageID.Focus()
    End Sub

    Private Sub cmdCalculate_Click(sender As Object, e As EventArgs) Handles cmdCalculate.Click
        intTimeFrom = Val(cmbTimeFromHrs.Text) * 60 + Val(cmbTimeFromMnts.Text)
        intTimeTo = Val(cmbTimeToHrs.Text) * 60 + Val(cmbTimeToMnts.Text)
        If intTimeTo > intTimeFrom Then
            intTotalStoppageTime = (intTimeTo - intTimeFrom) / 60
        Else
            intTimeTo = intTimeTo + 24 * 60
            intTotalStoppageTime = (intTimeTo - intTimeFrom) / 60
        End If
        txtTotalDuration.Text = intTotalStoppageTime

    End Sub

    Private Sub txtMachineID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMachineID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getMill(0)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()
                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtMachineID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is no machine found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtMachineID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMachineID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub StoppageDetail_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        thisScreenMode = ScreenMode.Add
        Call InitializeControls()
        Call EnableDisable(True)
    End Sub

    Private Sub txtMachineID_Leave(sender As Object, e As EventArgs) Handles txtMachineID.Leave
        If Val(txtMachineID.Text) > 0 Then
            ds1 = getMill(txtMachineID.Text)
            If ds1.Tables(0).Rows.Count > 0 Then
                lblMachine.Text = ds1.Tables(0).Rows(0).Item("mill_name").ToString
            Else
                MsgBox("Machine id not found", MsgBoxStyle.Information, gCompanyShortName)
                lblMachine.Text = ""
                txtMachineID.Focus()
            End If
        End If
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        thisScreenMode = ScreenMode.Add
        Call InitializeControls()
        Call EnableDisable(True)
    End Sub

    Private Sub txtStoppageID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtStoppageID.KeyPress
        If Asc(e.KeyChar) = 13 And Val(txtStoppageID.Text) > 0 Then
            Call populateStoppage()
        End If
    End Sub

    Private Sub txtStoppageID_Leave(sender As Object, e As EventArgs) Handles txtStoppageID.Leave
        If Val(txtStoppageID.Text) > 0 Then
            Call populateStoppage()
        End If
    End Sub
End Class