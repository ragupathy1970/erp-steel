﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 18-01-2018
' Time: 10:26
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Option Explicit On
Option Strict Off
Imports System
Imports System.Data
Imports System.IO
Imports VST
Imports VST.Constants

Friend Partial Class Search
	Inherits Windows.Forms.Form
	
	Public searchField As String
	Public retValue As String
	Public retTagValue As String
	Public rsin As New DataSet
	Public srcControl As New System.Windows.Forms.Control
	
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		'
		' TODO : Add constructor code after InitializeComponents
		'
		retValue = ""
		retTagValue = ""
	End Sub

    'Sub TxtSearchTextChanged(sender As Object, e As EventArgs)
    '    Call FilterField(rsin, searchField, txtSearch.Text)
    'End Sub

    Private Sub FilterField(rslist As DataSet, strField As String, strFilter As String)
        Try
            Dim filterCondition As String
            Dim dv As DataView


            If rslist.Tables(0).Columns(strField).DataType.Name.ToString = "Decimal" Then
                If txtSearch.Text.ToString = "" Then strFilter = 0
                filterCondition = " >= " & strFilter
            ElseIf rslist.Tables(0).Columns(strField).DataType.Name.ToString = "DateTime" Then
                'filterCondition = ""
                txtSearch.Text = ""
                Exit Sub
            Else
                filterCondition = " LIKE '%" & strFilter & "%'"
            End If
            dv = New DataView(rslist.Tables(0), strField & filterCondition, strField, DataViewRowState.CurrentRows)
            dgvSearch.DataSource = dv
            dgvSearch.AllowUserToResizeColumns = True
            dgvSearch.Refresh()
        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, gCompanyShortName)
        End Try
    End Sub

    Public Sub FillList(ByRef rslist As DataSet, ByRef sControl As System.Windows.Forms.Control, ByRef rValue As String, ByRef rTagValue As String)

        Try
            searchField = rslist.Tables(0).Columns(0).ColumnName
            rValue = retValue.ToString
            rTagValue = retTagValue.ToString
            sControl = srcControl
            rsin = rslist
            Me.Text = "Find..." & rslist.Tables(0).Columns(0).ColumnName
            dgvSearch.DataSource = rslist.Tables(0)

        Catch ex As Exception
            MsgBox(ex.Message.ToString, MsgBoxStyle.Critical, gCompanyShortName)
        End Try
    End Sub

    Sub SearchKeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
        Try
            If Asc(e.KeyChar) = 27 Then 'Esc Key
                Me.Close()
            End If
            If Asc(e.KeyChar) = 13 Then 'Enter Key
                Call setValue()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
        End Try
    End Sub

    Sub TxtSearchKeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles txtSearch.KeyDown
        If (e.KeyCode = 40 Or e.KeyCode = 38) Or (e.KeyCode = 13 And txtSearch.Text = "") Then ' down arrow or up arrow press
            dgvSearch.Focus()
        Else
            If e.KeyCode = 13 Then
                Call setValue()
            End If
        End If
    End Sub


    Public Sub setValue()
        Try
            If dgvSearch.SelectedRows.Count = 0 Then
                MsgBox("Search Not Found", MsgBoxStyle.Information, gCompanyShortName)
                Exit Sub
            Else
                retTagValue = dgvSearch.SelectedRows(0).Cells(0).Value.ToString
                retValue = dgvSearch.SelectedRows(0).Cells(1).Value.ToString
                srcControl.Text = retValue.ToString
                srcControl.Tag = retTagValue.ToString
            End If
            Me.Close()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
        End Try

    End Sub


    Sub SearchFormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If Not String.IsNullOrEmpty(srcControl.Text) Then
        Else
            srcControl.Text = ""
            srcControl.Tag = ""
        End If
    End Sub

    Sub SearchKeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = 13 Then
            setValue()
        End If
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        srcControl.Text = ""
        srcControl.Tag = ""
        Me.Close()
    End Sub

    Private Sub txtSearch_TextChanged(sender As Object, e As EventArgs) Handles txtSearch.TextChanged
        Call FilterField(rsin, searchField, txtSearch.Text)
    End Sub

    Private Sub dgvSearch_ColumnHeaderMouseClick(sender As Object, e As Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvSearch.ColumnHeaderMouseClick
        searchField = rsin.Tables(0).Columns(e.ColumnIndex).ColumnName.ToString
        txtSearch.Text = ""
        Me.Text = "Find..." & searchField
    End Sub

    Private Sub cmdOk_Click(sender As Object, e As EventArgs) Handles CmdOk.Click
        Call setValue()
    End Sub

    Private Sub dgvSearch_KeyDown(sender As Object, e As Windows.Forms.KeyEventArgs) Handles dgvSearch.KeyDown
        If e.KeyCode = 13 Then
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub dgvSearch_CellDoubleClick(sender As Object, e As Windows.Forms.DataGridViewCellEventArgs) Handles dgvSearch.CellDoubleClick
        Call setValue()
    End Sub
End Class
