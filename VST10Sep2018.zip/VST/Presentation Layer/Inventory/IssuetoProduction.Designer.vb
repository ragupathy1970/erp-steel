﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class IssueProduction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpHdr = New System.Windows.Forms.GroupBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtScode = New System.Windows.Forms.TextBox()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.chkIsJobwork = New System.Windows.Forms.CheckBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbItemType = New System.Windows.Forms.ComboBox()
        Me.txtMachineID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.dtIssueDate = New System.Windows.Forms.DateTimePicker()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtIssueID = New System.Windows.Forms.TextBox()
        Me.grpEntry = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtItemID = New System.Windows.Forms.TextBox()
        Me.grpTrn = New System.Windows.Forms.GroupBox()
        Me.lvwIssue = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colHSN = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colScode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpHdr.SuspendLayout()
        Me.grpEntry.SuspendLayout()
        Me.grpTrn.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpHdr
        '
        Me.grpHdr.Controls.Add(Me.Label5)
        Me.grpHdr.Controls.Add(Me.txtScode)
        Me.grpHdr.Controls.Add(Me.lblCustName)
        Me.grpHdr.Controls.Add(Me.txtCustomerID)
        Me.grpHdr.Controls.Add(Me.chkIsJobwork)
        Me.grpHdr.Controls.Add(Me.Label4)
        Me.grpHdr.Controls.Add(Me.Label3)
        Me.grpHdr.Controls.Add(Me.cmbItemType)
        Me.grpHdr.Controls.Add(Me.txtMachineID)
        Me.grpHdr.Controls.Add(Me.Label12)
        Me.grpHdr.Controls.Add(Me.dtIssueDate)
        Me.grpHdr.Controls.Add(Me.Label11)
        Me.grpHdr.Controls.Add(Me.txtIssueID)
        Me.grpHdr.Location = New System.Drawing.Point(12, 13)
        Me.grpHdr.Name = "grpHdr"
        Me.grpHdr.Size = New System.Drawing.Size(666, 134)
        Me.grpHdr.TabIndex = 0
        Me.grpHdr.TabStop = False
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(503, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 19)
        Me.Label5.TabIndex = 86
        Me.Label5.Text = "SCode"
        '
        'txtScode
        '
        Me.txtScode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtScode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtScode.Location = New System.Drawing.Point(558, 95)
        Me.txtScode.Name = "txtScode"
        Me.txtScode.Size = New System.Drawing.Size(99, 22)
        Me.txtScode.TabIndex = 85
        '
        'lblCustName
        '
        Me.lblCustName.Location = New System.Drawing.Point(261, 89)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(254, 15)
        Me.lblCustName.TabIndex = 84
        '
        'txtCustomerID
        '
        Me.txtCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCustomerID.Location = New System.Drawing.Point(180, 85)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.Size = New System.Drawing.Size(75, 22)
        Me.txtCustomerID.TabIndex = 83
        '
        'chkIsJobwork
        '
        Me.chkIsJobwork.AutoSize = True
        Me.chkIsJobwork.Location = New System.Drawing.Point(90, 87)
        Me.chkIsJobwork.Name = "chkIsJobwork"
        Me.chkIsJobwork.Size = New System.Drawing.Size(82, 20)
        Me.chkIsJobwork.TabIndex = 82
        Me.chkIsJobwork.Text = "Job Work"
        Me.chkIsJobwork.UseVisualStyleBackColor = True
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(315, 61)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 19)
        Me.Label4.TabIndex = 56
        Me.Label4.Text = "Item Type"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(312, 26)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(70, 19)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Issue Date"
        '
        'cmbItemType
        '
        Me.cmbItemType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbItemType.FormattingEnabled = True
        Me.cmbItemType.Location = New System.Drawing.Point(392, 60)
        Me.cmbItemType.Name = "cmbItemType"
        Me.cmbItemType.Size = New System.Drawing.Size(265, 24)
        Me.cmbItemType.TabIndex = 54
        '
        'txtMachineID
        '
        Me.txtMachineID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMachineID.Location = New System.Drawing.Point(89, 52)
        Me.txtMachineID.Name = "txtMachineID"
        Me.txtMachineID.Size = New System.Drawing.Size(75, 22)
        Me.txtMachineID.TabIndex = 53
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(4, 54)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(79, 20)
        Me.Label12.TabIndex = 52
        Me.Label12.Text = "Machine ID"
        '
        'dtIssueDate
        '
        Me.dtIssueDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtIssueDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtIssueDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtIssueDate.Location = New System.Drawing.Point(393, 24)
        Me.dtIssueDate.Name = "dtIssueDate"
        Me.dtIssueDate.Size = New System.Drawing.Size(99, 22)
        Me.dtIssueDate.TabIndex = 51
        Me.dtIssueDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(20, 27)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(63, 19)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "Issue ID"
        '
        'txtIssueID
        '
        Me.txtIssueID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIssueID.Location = New System.Drawing.Point(89, 25)
        Me.txtIssueID.Name = "txtIssueID"
        Me.txtIssueID.Size = New System.Drawing.Size(75, 22)
        Me.txtIssueID.TabIndex = 2
        '
        'grpEntry
        '
        Me.grpEntry.Controls.Add(Me.Label2)
        Me.grpEntry.Controls.Add(Me.Label1)
        Me.grpEntry.Controls.Add(Me.Label8)
        Me.grpEntry.Controls.Add(Me.Label6)
        Me.grpEntry.Controls.Add(Me.cmbUom)
        Me.grpEntry.Controls.Add(Me.cmdAdd)
        Me.grpEntry.Controls.Add(Me.txtQty)
        Me.grpEntry.Controls.Add(Me.txtDescription)
        Me.grpEntry.Controls.Add(Me.txtItemID)
        Me.grpEntry.Location = New System.Drawing.Point(12, 152)
        Me.grpEntry.Name = "grpEntry"
        Me.grpEntry.Size = New System.Drawing.Size(666, 78)
        Me.grpEntry.TabIndex = 1
        Me.grpEntry.TabStop = False
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(504, 12)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 15)
        Me.Label2.TabIndex = 49
        Me.Label2.Text = "Quantity"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(451, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 19)
        Me.Label1.TabIndex = 48
        Me.Label1.Text = "UOM"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(91, 9)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 47
        Me.Label8.Text = "Item Description"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(10, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 46
        Me.Label6.Text = "Item ID"
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(450, 29)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(50, 24)
        Me.cmbUom.TabIndex = 40
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(571, 23)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 42
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(506, 30)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(55, 22)
        Me.txtQty.TabIndex = 41
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Enabled = False
        Me.txtDescription.Location = New System.Drawing.Point(91, 29)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(353, 22)
        Me.txtDescription.TabIndex = 43
        '
        'txtItemID
        '
        Me.txtItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemID.Location = New System.Drawing.Point(8, 29)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.Size = New System.Drawing.Size(75, 22)
        Me.txtItemID.TabIndex = 39
        '
        'grpTrn
        '
        Me.grpTrn.Controls.Add(Me.lvwIssue)
        Me.grpTrn.Location = New System.Drawing.Point(12, 231)
        Me.grpTrn.Name = "grpTrn"
        Me.grpTrn.Size = New System.Drawing.Size(666, 208)
        Me.grpTrn.TabIndex = 2
        Me.grpTrn.TabStop = False
        '
        'lvwIssue
        '
        Me.lvwIssue.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwIssue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwIssue.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colHSN, Me.colScode, Me.colItemid, Me.colDescription, Me.colUom, Me.colQty, Me.colSlnoKey, Me.colUomKey})
        Me.lvwIssue.FullRowSelect = True
        Me.lvwIssue.GridLines = True
        Me.lvwIssue.Location = New System.Drawing.Point(6, 18)
        Me.lvwIssue.MultiSelect = False
        Me.lvwIssue.Name = "lvwIssue"
        Me.lvwIssue.Size = New System.Drawing.Size(651, 184)
        Me.lvwIssue.TabIndex = 2
        Me.lvwIssue.UseCompatibleStateImageBehavior = False
        Me.lvwIssue.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 41
        '
        'colHSN
        '
        Me.colHSN.Text = "HSN"
        Me.colHSN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colScode
        '
        Me.colScode.Text = "SCode"
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 75
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colQty.Width = 48
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 0
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(403, 449)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 38
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(592, 449)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 40
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(499, 449)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 39
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(307, 448)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 37
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'IssueProduction
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(687, 489)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpTrn)
        Me.Controls.Add(Me.grpEntry)
        Me.Controls.Add(Me.grpHdr)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "IssueProduction"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Issues"
        Me.grpHdr.ResumeLayout(False)
        Me.grpHdr.PerformLayout()
        Me.grpEntry.ResumeLayout(False)
        Me.grpEntry.PerformLayout()
        Me.grpTrn.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpHdr As System.Windows.Forms.GroupBox
    Friend WithEvents grpEntry As System.Windows.Forms.GroupBox
    Friend WithEvents grpTrn As System.Windows.Forms.GroupBox
    Private WithEvents txtIssueID As System.Windows.Forms.TextBox
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents dtIssueDate As System.Windows.Forms.DateTimePicker
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents txtItemID As System.Windows.Forms.TextBox
    Private WithEvents lvwIssue As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Friend WithEvents colHSN As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Friend WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents txtMachineID As System.Windows.Forms.TextBox
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents cmbItemType As System.Windows.Forms.ComboBox
    Private WithEvents lblCustName As System.Windows.Forms.Label
    Private WithEvents txtCustomerID As System.Windows.Forms.TextBox
    Friend WithEvents chkIsJobwork As System.Windows.Forms.CheckBox
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents txtScode As System.Windows.Forms.TextBox
    Friend WithEvents colScode As System.Windows.Forms.ColumnHeader
End Class
