﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 07-02-2018
' Time: 10:26
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Data.Odbc
Imports System.IO
Imports System.Data

Public Class Production
	
End Class

Public Class ProductionPlan

End Class

Public Class Order
  	
End Class