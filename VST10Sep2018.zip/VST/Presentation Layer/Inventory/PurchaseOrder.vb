﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production
Public Class PurchaseOrder
    Dim i As Integer
    Dim ds2 As DataSet
    Dim ds1 As DataSet
    Dim ds As DataSet
    Dim lvw As ListViewItem
    Dim thisScreenMode As Integer
    Dim dblItemValue As Double = 0
    Dim dblTaxable As Double = 0
    Dim dblRoundOff As Double
    Dim dblTotal As Double
    Dim dblCGSTper As Double
    Dim dblSGSTper As Double
    Dim dblIGSTper As Double
    Dim dblcgsttotal As Double
    Dim dblsgsttotal As Double
    Dim dbligsttotal As Double
    Dim dblTotalVal As Double
    Dim dblCGSTValue As Double
    Dim dblSGSTValue As Double
    Dim dblIGSTValue As Double
    Dim strHSN As String
    Dim strVenGST As String

    Dim trans As OdbcTransaction
    Dim strSQL As String
    Dim csno As Integer = 0
    Dim chsn As Integer = 1
    Dim citem As Integer = 2
    Dim cuom As Integer = 4
    Dim obj As Object
    Dim cqty As Integer = 5
    Dim crate As Integer = 6
    Dim cValue As Integer = 7
    Dim cCGST As Integer = 8
    Dim cSGST As Integer = 9
    Dim cIGST As Integer = 10
    Dim cSlnoKey As Integer = 11
    Dim cUomKey As Integer = 12
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim strDelRecSno As String = ""
    Dim dblSGST As Double = 0
    Dim dblCGST As Double = 0
    Dim dblIGST As Double = 0

    Private Sub PurchaseOrder_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = getUom()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        ds = getItemType()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbItemType.DataSource = ds.Tables(0)
            cmbItemType.DisplayMember = "type_name"
            cmbItemType.ValueMember = "item_type_id"
        End If
        Call initializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
    End Sub
    Public Sub initializeControls()
        Call getSysDateTime()
        txtPOno.Text = ""
        dtPODate.Value = gSysDate
        txtVendor.Text = ""
        cmbUom.Text = ""
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
        lvwPO.Items.Clear()
        txtNetTotal.Text = ""
        txtSGSTTotal.Text = ""
        txtCGSTTotal.Text = ""
        txtIGSTTotal.Text = ""
        txtTotalVal.Text = ""
        txtTaxable.Text = ""
        txtRoundOff.Text = ""
        lblVenName.Text = ""
        lbladd1.Text = ""
        lbladd2.Text = ""
        lblcity.Text = ""
        i = 0
        intDelRecSno = 0
        dblItemValue = 0
        dblTaxable = 0
        dblRoundOff = 0
        dblTotal = 0
        dblCGSTper = 0
        dblSGSTper = 0
        dblIGSTper = 0
        dblcgsttotal = 0
        dblsgsttotal = 0
        dbligsttotal = 0
        dblTotalVal = 0
        dblCGSTValue = 0
        dblSGSTValue = 0
        dblIGSTValue = 0
        strHSN = ""
        strVenGST = ""
        Call clearItem()

    End Sub

    Public Sub EnableDisable(toggle As Boolean)
        txtPOno.Enabled = Not toggle
        dtPODate.Enabled = toggle
        txtVendor.Enabled = toggle
        txtItemID.Enabled = toggle
        txtDescription.Enabled = False
        txtRate.Enabled = toggle
        txtQty.Enabled = toggle
        cmbUom.Enabled = toggle
        cmdAdd.Enabled = toggle
        cmdAddItem.Enabled = toggle
        lvwPO.Enabled = toggle
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        If validateItem() Then
            Call poAddItem()
        End If
    End Sub
    Sub poAddItem()
        Try
            If validateItem() Then
                i += 1
                dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
                lvw = lvwPO.Items.Add(i.ToString)
                lvw.SubItems.Add(strHSN)
                lvw.SubItems.Add(txtItemID.Text.ToString)
                lvw.SubItems.Add(txtDescription.Text.ToString)
                lvw.SubItems.Add(cmbUom.Text)
                lvw.SubItems.Add(txtQty.Text)
                lvw.SubItems.Add(txtRate.Text)
                lvw.SubItems.Add(Format(dblItemValue, "#0.00"))
                dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
                If Mid(strVenGST, 1, 2) = "33" Then
                    dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
                    dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
                    lvw.SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    lvw.SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    lvw.SubItems.Add("")
                Else
                    dblIGSTValue = Math.Round(dblItemValue * dblIGSTper / 100, 2)
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add(Format(dblIGSTValue, "#0.00"))
                End If
                lvw.SubItems.Add("")
                lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
                dblcgsttotal = dblcgsttotal + dblCGSTValue
                dblsgsttotal = dblsgsttotal + dblSGSTValue
                dbligsttotal = dbligsttotal + dblIGSTValue
                dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
                dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                dblTotal = dblTotalVal - dblRoundOff
                txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
                txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
                txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
                txtTaxable.Text = Format(dblTaxable, "#0.00")
                txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                txtNetTotal.Text = Format(dblTotal, "#0.00")
                Call clearItem()
            Else
                Call clearItem()
            End If
            txtItemID.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub clearItem()
        txtItemID.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtRate.Text = ""
        cmbUom.Text = ""
        dblSGSTValue = 0
        dblCGSTValue = 0
        dblIGSTValue = 0

    End Sub

    Public Function validateItem() As Boolean
        If txtItemID.Text.Trim = "" Then
            MsgBox("Please Enter Item Id", MsgBoxStyle.Information, gCompanyShortName)
            txtItemID.Focus()
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please Select UOM", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus()
            Return False
        End If
        If txtRate.Text = "" Then
            MsgBox("Please Enter Rate", MsgBoxStyle.Information, gCompanyShortName)
            txtRate.Focus()
            Return False
        End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
        End If
        For n = 0 To lvwPO.Items.Count - 1
            If txtItemID.Text.Trim = lvwPO.Items(n).SubItems(citem).Text.Trim Then
                MsgBox("Item Already Exists", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Next
        Return True
    End Function

    Private Sub txtVendor_KeyDown(sender As Object, e As KeyEventArgs) Handles txtVendor.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getVendor()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtVendor.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Public Sub populateVenAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblVenName.Text = ds1.Tables(0).Rows(0).Item("ven_name").ToString
            lbladd1.Text = ds1.Tables(0).Rows(0).Item("ven_address1").ToString
            lbladd2.Text = ds1.Tables(0).Rows(0).Item("ven_address2").ToString
            lblcity.Text = ds1.Tables(0).Rows(0).Item("ven_city").ToString
            strVenGST = ds1.Tables(0).Rows(0).Item("ven_gst").ToString
        Else
            MsgBox("Vendor Id Not Found", MsgBoxStyle.Information, gCompanyShortName)
            txtVendor.Text = ""
        End If

    End Sub

    Private Sub txtItemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                'ds = getItem()
                ds = getItemList(cmbItemType.SelectedValue)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemID.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemID.Text = "" Then
                ds1 = getItem(CInt(txtItemID.Text))
                Call populateItemDesc(ds1)
            End If
        End If
    End Sub
    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
            strHSN = ds2.Tables(0).Rows(0).Item("hsn").ToString
            dblCGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("cgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("cgst").ToString)))
            dblSGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("sgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("sgst").ToString)))
            dblIGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("igst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("igst").ToString)))
        Else
            dblIGSTper = 0
            dblSGSTper = 0
            dblCGSTper = 0
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If

    End Sub

    Private Sub PurchaseOrder_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call savePO()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Private Sub txtVendor_Leave(sender As Object, e As EventArgs) Handles txtVendor.Leave
        If Not txtVendor.Text = "" Then
            ds1 = getVendor(CInt(txtVendor.Text))
            Call populateVenAddress(ds1)
        End If
    End Sub

    Private Sub lvwPO_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwPO.SelectedIndexChanged

    End Sub

    Private Sub cmdAddItem_Click(sender As Object, e As EventArgs) Handles cmdAddItem.Click
        Dim frmItemMaster As New Item
        frmItemMaster.ShowDialog()
    End Sub

    Private Sub txtPOno_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPOno.KeyPress

        If Asc(e.KeyChar) = 13 And txtPOno.Text <> "" Then
            ds = getPOHdr(CInt(txtPOno.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populatePOHdr(CInt(txtPOno.Text))
                Call populatePOTrn(CInt(txtPOno.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtPOno.Focus()
            End If

        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Public Sub populatePOHdr(intPONo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            dtPODate.Text = ds.Tables(0).Rows(0).Item("po_dt").ToString
            txtVendor.Text = ds.Tables(0).Rows(0).Item("ven_id").ToString
            ds1 = getVendor(CInt(txtVendor.Text))
            populateVenAddress(ds1)
        End If
    End Sub

    Public Sub populatePOTrn(intPONo As Integer)
        ds = getPOTrn(intPONo)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                dblCGSTValue = 0
                dblSGSTValue = 0
                dblIGSTValue = 0
                lvw = lvwPO.Items.Add(ds.Tables(0).Rows(n).Item("po_sno").ToString)
                With lvw
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("hsn").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    Else
                        .SubItems.Add("")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_qty").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_rate").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("po_rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("po_qty")) Then
                        .SubItems.Add("")
                    Else
                        .SubItems.Add(Format(CDbl(ds.Tables(0).Rows(n).Item("po_rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("po_qty").ToString), "#0.00"))
                    End If
                    dblCGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("cgst")), 0, ds.Tables(0).Rows(n).Item("cgst").ToString))
                    .SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    dblSGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("sgst")), 0, ds.Tables(0).Rows(n).Item("sgst").ToString))
                    .SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    dblIGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("igst")), 0, ds.Tables(0).Rows(n).Item("igst").ToString))
                    .SubItems.Add(Format(dblIGSTValue, "#0.00"))
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("po_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("po_rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("po_qty")) Then
                    Else
                        dblTaxable = dblTaxable + CDbl(ds.Tables(0).Rows(n).Item("po_rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("po_qty").ToString)
                        dblcgsttotal = dblcgsttotal + dblCGSTValue
                        dblsgsttotal = dblsgsttotal + dblSGSTValue
                        dbligsttotal = dbligsttotal + dblIGSTValue
                        dblCGSTValue = 0
                        dblSGSTValue = 0
                        dblIGSTValue = 0
                    End If

                End With
                i += 1
            Next
            dblTotalVal = dblTotalVal + dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
            dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
            dblTotal = dblTotalVal - dblRoundOff
            txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
            txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
            txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
            txtTaxable.Text = Format(dblTaxable, "#0.00")
            txtTotalVal.Text = Format(dblTotalVal, "#0.00")
            txtRoundOff.Text = Format(dblRoundOff, "#0.00")
            txtNetTotal.Text = Format(dblTotal, "#0.00")
        End If
    End Sub

    Private Sub txtVendor_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtVendor.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtItemID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtQty.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtRate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRate.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtRate.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub cmbUom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtPOno.Focus()
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call initializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub setSlno()
        i = 0
        For n = 0 To lvwPO.Items.Count - 1
            i += 1
            lvwPO.Items(n).Text = i.ToString
        Next
    End Sub

    Private Sub lvwPO_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwPO.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwPO.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        dblTotal = dblTotal - (CDbl(lvwPO.SelectedItems(0).SubItems(crate).Text) * CDbl(lvwPO.SelectedItems(0).SubItems(cqty).Text))
                        txtNetTotal.Text = Format(dblTotal, "#0.00")
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwPO.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwPO.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwPO.Items.RemoveAt(lvwPO.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtPOno.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        savePO()
    End Sub

    Sub savePO()
        Try
            If validatePO() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "Select nextval('pur_ord_id_seq') AS pur_ord_id"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        txtPOno.Text = obj.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call insertPOHdr()
                        Call insertPOtrn()
                        trans.Commit()
                    Case 2
                        If intDelRecSno > 1 Then
                            strDelRecSno = String.Join(",", arrDelTrn)
                            strDelRecSno = Mid(strDelRecSno, 2)
                        ElseIf intDelRecSno = 1 Then
                            strDelRecSno = arrDelTrn(1).ToString
                        End If
                        Call updatePOHdr()
                        Call updatePOTrn()

                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Order ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deletePOTrn()
                            Call deletePOHdr()
                            trans.Commit()

                        End If

                End Select
                Call initializeControls()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        Try
            trans.Rollback()
            Call initializeControls()
        Catch ex1 As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
        End Try
    End Sub

    Sub insertPOHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertPOHdr(?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text)
            dt = Date.ParseExact(Format(CDate(dtPODate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@podt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@venid", OdbcType.Int).Value = CInt(txtVendor.Text.Trim())
            cmd.Parameters.AddWithValue("@postatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = CDbl(txtRoundOff.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub insertPOtrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwPO.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertPOTrn(?,?,?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text.Trim())
                cmd.Parameters.AddWithValue("@posno", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@poqty", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(cqty).Text)
                cmd.Parameters.AddWithValue("@porate", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(crate).Text)
                cmd.Parameters.AddWithValue("@pocgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cCGST).Text)
                cmd.Parameters.AddWithValue("@posgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cSGST).Text)
                cmd.Parameters.AddWithValue("@poigst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cIGST).Text)
                cmd.ExecuteScalar()
            Next
            MsgBox("PO No : " & txtPOno.Text & " Created")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updatePOHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updatePOHdr(?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text)
            dt = Date.ParseExact(Format(CDate(dtPODate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@podt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@venid", OdbcType.Int).Value = CInt(txtVendor.Text.Trim())
            cmd.Parameters.AddWithValue("@postatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = CDbl(txtRoundOff.Text)
            cmd.Parameters.AddWithValue("@modify_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@modify_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@modify_by", OdbcType.Int).Value = gUserId
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Sub updatePOTrn()
        Dim cmd As New OdbcCommand

        Try
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delPOTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text)
                    cmd.Parameters.AddWithValue("@posno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwPO.Items.Count - 1
                If Not lvwPO.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updatePOTrn(?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text.Trim())
                    cmd.Parameters.AddWithValue("@posno", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@poqty", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@porate", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@pocgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@posgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@poigst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                End If
            Next
            For n = 0 To lvwPO.Items.Count - 1
                If lvwPO.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertPOTrn(?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text.Trim())
                    cmd.Parameters.AddWithValue("@posno", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwPO.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@poqty", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@porate", OdbcType.Double).Value = CDec(lvwPO.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@pocgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@posgst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@poigst", OdbcType.Double).Value = Val(lvwPO.Items(n).SubItems(cIGST).Text)
                    cmd.ExecuteScalar()
                End If
            Next

            'Call setSerialNumbers
            MsgBox("PO Number Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deletePOHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeletePOHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deletePOTrn()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deletePOTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@poid", OdbcType.Int).Value = CInt(txtPOno.Text)
            cmd.ExecuteScalar()
            MsgBox("PO No : " & txtPOno.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Private Function validatePO()
        If thisScreenMode = ScreenMode.Delete Or thisScreenMode = ScreenMode.Edit Then
            If txtPOno.Text = "" Then
                MsgBox("Please Enter PO Number", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Else
            If txtVendor.Text = "" Then
                MsgBox("Please Enter Supplier Number", MsgBoxStyle.Information, gCompanyShortName)
                txtVendor.Focus()
                Return False
                Exit Function
            End If
            If lvwPO.Items.Count = 0 Then
                MsgBox("Please Add Item", MsgBoxStyle.Information, gCompanyShortName)
                txtItemID.Focus()
                Return False
                Exit Function
            End If
        End If
        Return True
    End Function
    Private Sub lvwPO_DoubleClick(sender As Object, e As EventArgs) Handles lvwPO.DoubleClick
        If Not lvwPO.SelectedItems Is Nothing Then
            txtItemID.Text = lvwPO.SelectedItems(0).SubItems(citem).Text.ToString
            txtDescription.Text = lvwPO.SelectedItems(0).SubItems(3).Text.ToString
            cmbUom.Text = lvwPO.SelectedItems(0).SubItems(cuom).Text.ToString
            txtRate.Text = lvwPO.SelectedItems(0).SubItems(crate).Text.ToString
            txtQty.Text = lvwPO.SelectedItems(0).SubItems(cqty).Text.ToString
        End If
    End Sub


End Class