﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production
Public Class IssueProduction
    Dim ds As DataSet
    Dim ds1 As DataSet
    Dim ds2 As DataSet
    Dim thisScreenMode As Integer
    Dim strHSN As String
    Dim lvw As ListViewItem
    Dim i As Integer
    Dim strSQL As String
    Dim strDelRecSno As String
    Dim intDelRecSno As Integer
    Dim arrDelTrn() As String
    Dim obj As Object
    Dim trans As OdbcTransaction
    Dim csno As Integer = 0
    Dim chsn As Integer = 1
    Dim cScode As Integer = 2
    Dim citem As Integer = 3
    Dim cuom As Integer = 5
    Dim cqty As Integer = 6
    Dim cSlnoKey As Integer = 7
    Dim cUomKey As Integer = 8
    Dim dblqtynos As Integer
    Dim dblqtytones As Double
    Dim intItemID As Integer

    Private Sub IssueProduction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = getUom()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        ds = getItemType()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbItemType.DataSource = ds.Tables(0)
            cmbItemType.DisplayMember = "type_name"
            cmbItemType.ValueMember = "item_type_id"
        End If
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
    End Sub

    Sub InitializeControls()
        i = 0
        Call getSysDateTime()
        dtIssueDate.Value = gSysDate
        cmbUom.Text = ""
        txtIssueID.Text = ""
        txtItemID.Text = ""
        txtScode.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtMachineID.Text = ""
        chkIsJobwork.Checked = False
        If chkIsJobwork.Checked Then
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = True
        Else
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = False
        End If
        lvwIssue.Items.Clear()
        thisScreenMode = ScreenMode.Add
    End Sub
    Sub EnableDisable(toggle As Boolean)
        txtIssueID.Enabled = Not toggle
        dtIssueDate.Enabled = toggle
        txtMachineID.Enabled = toggle
        chkIsJobwork.Enabled = toggle
        cmbItemType.Enabled = toggle
        cmbUom.Enabled = toggle
        txtItemID.Enabled = toggle
        txtScode.Enabled = toggle
        txtDescription.Enabled = False
        txtQty.Enabled = toggle
        lvwIssue.Enabled = toggle
        grpEntry.Enabled = True
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub
    Private Sub txtItemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemID.KeyDown
        If e.KeyCode = 120 And cmbItemType.SelectedValue > 0 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getItemList(cmbItemType.SelectedValue)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemID.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemID.Text = "" Then
                ds1 = getItem(CInt(txtItemID.Text))
                Call populateItemDesc(ds1)
            End If
        End If
    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
            strHSN = ds2.Tables(0).Rows(0).Item("hsn").ToString
        Else
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If

    End Sub

    Private Sub IssueProduction_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveIssues()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Private Sub txtMachineID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMachineID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getMill(0)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtMachineID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Machine Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmbItemType_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbItemType.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbItemType.Text
        Dim typedT As String = t.Substring(0, cmbItemType.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbItemType.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Call issueAddItem()
    End Sub

    Sub issueAddItem()
        i += 1
        lvw = lvwIssue.Items.Add(i.ToString)
        lvw.SubItems.Add(strHSN)
        lvw.SubItems.Add(txtScode.Text.ToString)
        lvw.SubItems.Add(txtItemID.Text.ToString)
        lvw.SubItems.Add(txtDescription.Text.ToString)
        lvw.SubItems.Add(cmbUom.Text)
        lvw.SubItems.Add(txtQty.Text)
        lvw.SubItems.Add("")
        lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
    End Sub

    Private Sub txtCustomerID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Customer Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtCustomerID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub
    Private Sub txtCustomerID_Leave(sender As Object, e As EventArgs) Handles txtCustomerID.Leave
        If Not txtCustomerID.Text = "" Then
            ds1 = getCustomer(CInt(txtCustomerID.Text))
            Call populateCustAddress(ds1)
        End If
    End Sub
    Public Sub populateCustAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblCustName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
        Else
            MsgBox("No Customer Id Found", MsgBoxStyle.Information, gCompanyShortName)
            txtCustomerID.Text = ""
            lblCustName.Text = ""
        End If
    End Sub

    Private Sub chkIsJobwork_CheckedChanged(sender As Object, e As EventArgs) Handles chkIsJobwork.CheckedChanged
        If chkIsJobwork.Checked Then
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = True
            lblCustName.Text = ""
        Else
            txtCustomerID.Text = ""
            txtCustomerID.Enabled = False
            lblCustName.Text = ""
        End If
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtIssueID.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveIssues()
    End Sub

    Private Sub saveIssues()
        Try
            If validateIssue() Then
                If validateItem() Then
                    Call getSysDateTime()
                    Select Case thisScreenMode
                        Case 1
                            strSQL = "Select nextval('pro_issue_id_seq') AS pro_issue_id"
                            obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                            txtIssueID.Text = obj.ToString
                            'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call insertIssueHdr()
                            Call insertIssueTrn()
                            'trans.Commit()
                        Case 2
                            If intDelRecSno > 1 Then
                                strDelRecSno = String.Join(",", arrDelTrn)
                                strDelRecSno = Mid(strDelRecSno, 2)
                            ElseIf intDelRecSno = 1 Then
                                strDelRecSno = arrDelTrn(1).ToString
                            End If
                            Call updateIssueHdr()
                            Call updateIssueTrn()

                        Case 3
                            If MsgBox("Are You Sure You want to Delete this Issue ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                                'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                                Call deleteIssueTrn()
                                Call deleteIssueHdr()
                                'trans.Commit()

                            End If

                    End Select
                    Call InitializeControls()
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try

    End Sub
    Sub insertIssueHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertIssueHdr(?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text)
            dt = Date.ParseExact(Format(CDate(dtIssueDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@issdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@machineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            cmd.Parameters.AddWithValue("@isjobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            cmd.Parameters.AddWithValue("@customerid", OdbcType.Int).Value = Val(txtCustomerID.Text)
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub insertIssueTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwIssue.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertIssueTrn(?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text.Trim())
                cmd.Parameters.AddWithValue("@isssno", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@scode", OdbcType.Text).Value = lvwIssue.Items(n).SubItems(cScode).Text.ToString
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@issqty", OdbcType.Double).Value = CDec(lvwIssue.Items(n).SubItems(cqty).Text)
                cmd.ExecuteScalar()
                dblqtynos = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                dblqtytones = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                intItemID = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                Call updateIssuesInStock(txtCustomerID.Text, intItemID, dblqtytones)
            Next
            MsgBox("Issue No : " & txtIssueID.Text & " Created")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateIssueHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateIssueHdr(?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text)
            dt = Date.ParseExact(Format(CDate(dtIssueDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@issdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@machineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            cmd.Parameters.AddWithValue("@isjobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            cmd.Parameters.AddWithValue("@customerid", OdbcType.Int).Value = Val(txtCustomerID.Text)
            cmd.Parameters.AddWithValue("@modify_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@modify_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@modify_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Sub updateIssueTrn()
        Dim cmd As New OdbcCommand

        Try
            ds = getIssueTrn(CInt(txtIssueID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds.Tables(0).Rows.Count - 1
                    intItemID = CInt(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    dblqtynos = Val(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    dblqtytones = Val(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    Call subtractIssuesInStock(CInt(txtCustomerID.Text), intItemID, dblqtytones)
                Next
            End If
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delIssueTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text)
                    cmd.Parameters.AddWithValue("@isssno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwIssue.Items.Count - 1
                If Not lvwIssue.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateIssueTrn(?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text.Trim())
                    cmd.Parameters.AddWithValue("@isssno", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@scode", OdbcType.Text).Value = lvwIssue.Items(n).SubItems(cScode).Text.ToString
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@issqty", OdbcType.Double).Value = CDec(lvwIssue.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                    dblqtynos = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                    dblqtytones = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                    intItemID = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                    Call updateIssuesInStock(txtCustomerID.Text, intItemID, dblqtytones)
                End If
            Next
            For n = 0 To lvwIssue.Items.Count - 1
                If lvwIssue.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertIssueTrn(?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text.Trim())
                    cmd.Parameters.AddWithValue("@isssno", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@scode", OdbcType.Text).Value = lvwIssue.Items(n).SubItems(cScode).Text.ToString
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwIssue.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@issqty", OdbcType.Double).Value = CDec(lvwIssue.Items(n).SubItems(cqty).Text)
                    cmd.ExecuteScalar()
                    dblqtynos = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                    dblqtytones = Val(lvwIssue.Items(n).SubItems(cqty).Text)
                    intItemID = CInt(lvwIssue.Items(n).SubItems(citem).Text)
                    Call updateIssuesInStock(txtCustomerID.Text, intItemID, dblqtytones)
                End If
            Next

            'Call setSerialNumbers
            MsgBox("Issue Number Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteIssueHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteIssueHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteIssueTrn()
        Try
            Dim cmd As New OdbcCommand
            ds = getIssueTrn(CInt(txtIssueID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds.Tables(0).Rows.Count - 1
                    intItemID = CInt(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    dblqtynos = Val(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    dblqtytones = Val(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    Call subtractIssuesInStock(CInt(txtCustomerID.Text), intItemID, dblqtytones)
                Next
            End If

            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteIssueTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@issid", OdbcType.Int).Value = CInt(txtIssueID.Text)
            cmd.ExecuteScalar()
            MsgBox("Issue No : " & txtIssueID.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Public Function validateIssue() As Boolean
        Return True
    End Function

    Public Function validateItem() As Boolean
        Return True
    End Function
    Private Sub cmbUom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtIssueID.Focus()
    End Sub

    Private Sub lvwIssue_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwIssue.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwIssue.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwIssue.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwIssue.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwIssue.Items.RemoveAt(lvwIssue.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub setSlno()
        i = 0
        For n = 0 To lvwIssue.Items.Count - 1
            i += 1
            lvwIssue.Items(n).Text = i.ToString
        Next
    End Sub

    Private Sub txtIssueID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtIssueID.KeyPress
        If Asc(e.KeyChar) = 13 And txtIssueID.Text <> "" Then
            ds = getIssueHdr(CInt(txtIssueID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateIssueHdr(CInt(txtIssueID.Text))
                Call populateIssueTrn(CInt(txtIssueID.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Order Number", MsgBoxStyle.Information, gCompanyShortName)
                txtIssueID.Focus()
            End If

        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Public Sub populateIssueHdr(intIssueID As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            dtIssueDate.Text = ds.Tables(0).Rows(0).Item("pro_issue_dt").ToString
            txtMachineID.Text = ds.Tables(0).Rows(0).Item("pro_machine_id").ToString
            If Val(ds.Tables(0).Rows(0).Item("is_jobwork").ToString) = 2 Then
                chkIsJobwork.Checked = True
                txtCustomerID.Text = ds.Tables(0).Rows(0).Item("customer_id").ToString
                ds1 = getCustomer(Val(txtCustomerID.Text))
                populateCustAddress(ds1)
            Else
                chkIsJobwork.Checked = False
            End If
        End If
    End Sub

    Public Sub populateIssueTrn(intIssueID As Integer)
        ds = getIssueTrn(intIssueID)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                lvw = lvwIssue.Items.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                With lvw
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("hsn").ToString)
                        .SubItems.Add(ds.Tables(0).Rows(n).Item("StkCode").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                End With
                i += 1
            Next
        End If
    End Sub
End Class