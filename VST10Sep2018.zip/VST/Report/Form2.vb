﻿Imports System.Net
Imports System.Net.Mail

Public Class testEmail

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Set the caption bar text of the form.   
        Me.Text = "tutorialspoint.com"
    End Sub

    Private Sub cmdSend_Click(sender As Object, e As EventArgs) Handles cmdSend.Click
        Try
            Dim Smtp_Server As New SmtpClient
            Dim e_mail As New MailMessage()
            Smtp_Server.Credentials = New Net.NetworkCredential("ragupathy1970@outlook.com", "ragu12345")
            Smtp_Server.UseDefaultCredentials = False


            Smtp_Server.EnableSsl = True
            Smtp_Server.Host = "smtp-mail.oulook.com"
            Smtp_Server.Port = 587
            Smtp_Server.DeliveryMethod = SmtpDeliveryMethod.Network

            e_mail = New MailMessage()
            e_mail.From = New MailAddress(txtEmailFrom.Text)
            e_mail.To.Add(txtEmailto.Text)
            e_mail.Subject = "Email Sending"
            e_mail.IsBodyHtml = False
            e_mail.Body = txtMessage.Text
            Smtp_Server.Send(e_mail)
            MsgBox("Mail Sent")

        Catch error_t As Exception
            MsgBox(error_t.ToString)
        End Try

    End Sub

End Class