﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StoppageDetail
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpStoppage = New System.Windows.Forms.GroupBox()
        Me.cmdCalculate = New System.Windows.Forms.Button()
        Me.txtTotalDuration = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cmbTimeFromMnts = New System.Windows.Forms.ComboBox()
        Me.cmbTimeFromHrs = New System.Windows.Forms.ComboBox()
        Me.cmbTimeToMnts = New System.Windows.Forms.ComboBox()
        Me.cmbTimeToHrs = New System.Windows.Forms.ComboBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.grpShift = New System.Windows.Forms.GroupBox()
        Me.rdoShift4 = New System.Windows.Forms.RadioButton()
        Me.rdoShift3 = New System.Windows.Forms.RadioButton()
        Me.rdoShift2 = New System.Windows.Forms.RadioButton()
        Me.rdoShift1 = New System.Windows.Forms.RadioButton()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lblMachine = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtMachineID = New System.Windows.Forms.TextBox()
        Me.dtStoppageDate = New System.Windows.Forms.DateTimePicker()
        Me.txtStoppageID = New System.Windows.Forms.TextBox()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpStoppage.SuspendLayout()
        Me.grpShift.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpStoppage
        '
        Me.grpStoppage.Controls.Add(Me.cmdCalculate)
        Me.grpStoppage.Controls.Add(Me.txtTotalDuration)
        Me.grpStoppage.Controls.Add(Me.Label8)
        Me.grpStoppage.Controls.Add(Me.Label6)
        Me.grpStoppage.Controls.Add(Me.Label5)
        Me.grpStoppage.Controls.Add(Me.Label4)
        Me.grpStoppage.Controls.Add(Me.Label3)
        Me.grpStoppage.Controls.Add(Me.cmbTimeFromMnts)
        Me.grpStoppage.Controls.Add(Me.cmbTimeFromHrs)
        Me.grpStoppage.Controls.Add(Me.cmbTimeToMnts)
        Me.grpStoppage.Controls.Add(Me.cmbTimeToHrs)
        Me.grpStoppage.Controls.Add(Me.txtRemarks)
        Me.grpStoppage.Controls.Add(Me.Label24)
        Me.grpStoppage.Controls.Add(Me.Label2)
        Me.grpStoppage.Controls.Add(Me.Label1)
        Me.grpStoppage.Controls.Add(Me.grpShift)
        Me.grpStoppage.Controls.Add(Me.lbladd2)
        Me.grpStoppage.Controls.Add(Me.lblMachine)
        Me.grpStoppage.Controls.Add(Me.Label12)
        Me.grpStoppage.Controls.Add(Me.Label11)
        Me.grpStoppage.Controls.Add(Me.Label7)
        Me.grpStoppage.Controls.Add(Me.txtMachineID)
        Me.grpStoppage.Controls.Add(Me.dtStoppageDate)
        Me.grpStoppage.Controls.Add(Me.txtStoppageID)
        Me.grpStoppage.Location = New System.Drawing.Point(11, 5)
        Me.grpStoppage.Name = "grpStoppage"
        Me.grpStoppage.Size = New System.Drawing.Size(687, 353)
        Me.grpStoppage.TabIndex = 26
        Me.grpStoppage.TabStop = False
        '
        'cmdCalculate
        '
        Me.cmdCalculate.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCalculate.Location = New System.Drawing.Point(519, 164)
        Me.cmdCalculate.Name = "cmdCalculate"
        Me.cmdCalculate.Size = New System.Drawing.Size(75, 23)
        Me.cmdCalculate.TabIndex = 92
        Me.cmdCalculate.Text = "C&alculate"
        Me.cmdCalculate.UseVisualStyleBackColor = True
        '
        'txtTotalDuration
        '
        Me.txtTotalDuration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalDuration.Location = New System.Drawing.Point(112, 207)
        Me.txtTotalDuration.Name = "txtTotalDuration"
        Me.txtTotalDuration.Size = New System.Drawing.Size(75, 22)
        Me.txtTotalDuration.TabIndex = 91
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(18, 207)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(91, 19)
        Me.Label8.TabIndex = 90
        Me.Label8.Text = "Total Duration"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(455, 145)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 19)
        Me.Label6.TabIndex = 89
        Me.Label6.Text = "Minutes"
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(401, 142)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(43, 19)
        Me.Label5.TabIndex = 88
        Me.Label5.Text = "Hours"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(168, 143)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 19)
        Me.Label4.TabIndex = 87
        Me.Label4.Text = "Minutes"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(118, 141)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(43, 19)
        Me.Label3.TabIndex = 86
        Me.Label3.Text = "Hours"
        '
        'cmbTimeFromMnts
        '
        Me.cmbTimeFromMnts.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbTimeFromMnts.FormattingEnabled = True
        Me.cmbTimeFromMnts.Items.AddRange(New Object() {"00", "15", "30", "45"})
        Me.cmbTimeFromMnts.Location = New System.Drawing.Point(170, 164)
        Me.cmbTimeFromMnts.Name = "cmbTimeFromMnts"
        Me.cmbTimeFromMnts.Size = New System.Drawing.Size(50, 24)
        Me.cmbTimeFromMnts.TabIndex = 85
        '
        'cmbTimeFromHrs
        '
        Me.cmbTimeFromHrs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbTimeFromHrs.FormattingEnabled = True
        Me.cmbTimeFromHrs.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"})
        Me.cmbTimeFromHrs.Location = New System.Drawing.Point(112, 163)
        Me.cmbTimeFromHrs.Name = "cmbTimeFromHrs"
        Me.cmbTimeFromHrs.Size = New System.Drawing.Size(50, 24)
        Me.cmbTimeFromHrs.TabIndex = 84
        '
        'cmbTimeToMnts
        '
        Me.cmbTimeToMnts.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbTimeToMnts.FormattingEnabled = True
        Me.cmbTimeToMnts.Items.AddRange(New Object() {"00", "15", "30", "45"})
        Me.cmbTimeToMnts.Location = New System.Drawing.Point(455, 164)
        Me.cmbTimeToMnts.Name = "cmbTimeToMnts"
        Me.cmbTimeToMnts.Size = New System.Drawing.Size(50, 24)
        Me.cmbTimeToMnts.TabIndex = 83
        '
        'cmbTimeToHrs
        '
        Me.cmbTimeToHrs.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbTimeToHrs.FormattingEnabled = True
        Me.cmbTimeToHrs.Items.AddRange(New Object() {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23"})
        Me.cmbTimeToHrs.Location = New System.Drawing.Point(396, 164)
        Me.cmbTimeToHrs.Name = "cmbTimeToHrs"
        Me.cmbTimeToHrs.Size = New System.Drawing.Size(50, 24)
        Me.cmbTimeToHrs.TabIndex = 82
        '
        'txtRemarks
        '
        Me.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRemarks.Location = New System.Drawing.Point(109, 256)
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(529, 79)
        Me.txtRemarks.TabIndex = 80
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(34, 256)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 19)
        Me.Label24.TabIndex = 81
        Me.Label24.Text = "Remarks"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label2.Location = New System.Drawing.Point(335, 167)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(56, 19)
        Me.Label2.TabIndex = 79
        Me.Label2.Text = "Time To"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label1.Location = New System.Drawing.Point(34, 168)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 19)
        Me.Label1.TabIndex = 78
        Me.Label1.Text = "Time From"
        '
        'grpShift
        '
        Me.grpShift.Controls.Add(Me.rdoShift4)
        Me.grpShift.Controls.Add(Me.rdoShift3)
        Me.grpShift.Controls.Add(Me.rdoShift2)
        Me.grpShift.Controls.Add(Me.rdoShift1)
        Me.grpShift.Location = New System.Drawing.Point(577, 48)
        Me.grpShift.Name = "grpShift"
        Me.grpShift.Size = New System.Drawing.Size(81, 95)
        Me.grpShift.TabIndex = 76
        Me.grpShift.TabStop = False
        Me.grpShift.Text = "Shift"
        '
        'rdoShift4
        '
        Me.rdoShift4.AutoSize = True
        Me.rdoShift4.Location = New System.Drawing.Point(25, 72)
        Me.rdoShift4.Name = "rdoShift4"
        Me.rdoShift4.Size = New System.Drawing.Size(36, 20)
        Me.rdoShift4.TabIndex = 3
        Me.rdoShift4.TabStop = True
        Me.rdoShift4.Text = "G"
        Me.rdoShift4.UseVisualStyleBackColor = True
        '
        'rdoShift3
        '
        Me.rdoShift3.AutoSize = True
        Me.rdoShift3.Location = New System.Drawing.Point(26, 54)
        Me.rdoShift3.Name = "rdoShift3"
        Me.rdoShift3.Size = New System.Drawing.Size(35, 20)
        Me.rdoShift3.TabIndex = 2
        Me.rdoShift3.TabStop = True
        Me.rdoShift3.Text = "C"
        Me.rdoShift3.UseVisualStyleBackColor = True
        '
        'rdoShift2
        '
        Me.rdoShift2.AutoSize = True
        Me.rdoShift2.Location = New System.Drawing.Point(26, 37)
        Me.rdoShift2.Name = "rdoShift2"
        Me.rdoShift2.Size = New System.Drawing.Size(35, 20)
        Me.rdoShift2.TabIndex = 1
        Me.rdoShift2.TabStop = True
        Me.rdoShift2.Text = "B"
        Me.rdoShift2.UseVisualStyleBackColor = True
        '
        'rdoShift1
        '
        Me.rdoShift1.AutoSize = True
        Me.rdoShift1.Location = New System.Drawing.Point(26, 20)
        Me.rdoShift1.Name = "rdoShift1"
        Me.rdoShift1.Size = New System.Drawing.Size(35, 20)
        Me.rdoShift1.TabIndex = 7
        Me.rdoShift1.TabStop = True
        Me.rdoShift1.Text = "A"
        Me.rdoShift1.UseVisualStyleBackColor = True
        '
        'lbladd2
        '
        Me.lbladd2.Location = New System.Drawing.Point(194, 49)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(254, 15)
        Me.lbladd2.TabIndex = 75
        '
        'lblMachine
        '
        Me.lblMachine.Location = New System.Drawing.Point(194, 97)
        Me.lblMachine.Name = "lblMachine"
        Me.lblMachine.Size = New System.Drawing.Size(254, 15)
        Me.lblMachine.TabIndex = 74
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(471, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(94, 19)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "Stoppage Date"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(31, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 19)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Stoppage ID"
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(34, 94)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(74, 19)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Machine ID"
        '
        'txtMachineID
        '
        Me.txtMachineID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtMachineID.Location = New System.Drawing.Point(112, 94)
        Me.txtMachineID.Name = "txtMachineID"
        Me.txtMachineID.Size = New System.Drawing.Size(75, 22)
        Me.txtMachineID.TabIndex = 3
        '
        'dtStoppageDate
        '
        Me.dtStoppageDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtStoppageDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtStoppageDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtStoppageDate.Location = New System.Drawing.Point(574, 17)
        Me.dtStoppageDate.Name = "dtStoppageDate"
        Me.dtStoppageDate.Size = New System.Drawing.Size(99, 22)
        Me.dtStoppageDate.TabIndex = 3
        Me.dtStoppageDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'txtStoppageID
        '
        Me.txtStoppageID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtStoppageID.Location = New System.Drawing.Point(112, 20)
        Me.txtStoppageID.Name = "txtStoppageID"
        Me.txtStoppageID.Size = New System.Drawing.Size(75, 22)
        Me.txtStoppageID.TabIndex = 1
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(431, 368)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 28
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(620, 368)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 30
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(527, 368)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 29
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(335, 367)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 27
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'StoppageDetail
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(715, 418)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpStoppage)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "StoppageDetail"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Stoppage Detail"
        Me.grpStoppage.ResumeLayout(False)
        Me.grpStoppage.PerformLayout()
        Me.grpShift.ResumeLayout(False)
        Me.grpShift.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpStoppage As System.Windows.Forms.GroupBox
    Private WithEvents lbladd2 As System.Windows.Forms.Label
    Private WithEvents lblMachine As System.Windows.Forms.Label
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents txtMachineID As System.Windows.Forms.TextBox
    Private WithEvents dtStoppageDate As System.Windows.Forms.DateTimePicker
    Private WithEvents txtStoppageID As System.Windows.Forms.TextBox
    Friend WithEvents grpShift As System.Windows.Forms.GroupBox
    Friend WithEvents rdoShift4 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift3 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift2 As System.Windows.Forms.RadioButton
    Friend WithEvents rdoShift1 As System.Windows.Forms.RadioButton
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents txtRemarks As System.Windows.Forms.TextBox
    Private WithEvents Label24 As System.Windows.Forms.Label
    Private WithEvents cmbTimeFromMnts As System.Windows.Forms.ComboBox
    Private WithEvents cmbTimeFromHrs As System.Windows.Forms.ComboBox
    Private WithEvents cmbTimeToMnts As System.Windows.Forms.ComboBox
    Private WithEvents cmbTimeToHrs As System.Windows.Forms.ComboBox
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtTotalDuration As System.Windows.Forms.TextBox
    Private WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents cmdCalculate As System.Windows.Forms.Button
End Class
