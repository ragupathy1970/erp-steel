﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 16:10
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.constants
Imports VST.Production

Public Partial Class Vendor
	Dim thisScreenMode As Integer
	Dim ds As DataSet
	Dim obj As Object
	Dim intVendorID As Integer
	Dim strSQL As String
	Dim trans As OdbcTransaction	
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Public Sub InitializeControls()
		txtVendorNo.Text = ""
		txtVendorName.Text = ""
		txtVendorAdd1.Text = ""
		txtVendorAdd2.Text = ""
		txtVendorCity.Text = ""
		txtVendorState.Text = ""
		txtVendorPin.Text = ""
		txtVendorGST.Text = ""
		txtContactPerson.Text = ""
		txtEmailId.Text = ""
		txtPhone.Text = ""
		chkIsActive.Checked = False
		EnableDisable(True)
	End Sub
	
	Public Sub EnableDisable(toggle As Boolean)
		txtVendorNo.Enabled = Not toggle
		txtVendorName.Enabled = toggle
		txtVendorAdd1.Enabled = toggle
		txtVendorAdd2.Enabled = toggle
		txtVendorCity.Enabled = toggle
		txtVendorState.Enabled = toggle
		txtVendorPin.Enabled = toggle
		txtVendorGST.Enabled = toggle
		txtContactPerson.Enabled = toggle
		txtEmailId.Enabled = toggle
		txtPhone.Enabled = toggle
		chkIsActive.Checked = toggle
	End Sub

    Sub CmdEditClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtVendorNo.Focus()

    End Sub

    Sub CmdDeleteClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtVendorNo.Focus()
    End Sub

    Sub CmdSaveClick(sender As Object, e As EventArgs)
        Call saveVendor()
    End Sub

    Sub CmdCancelClick(sender As Object, e As EventArgs)
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub VendorLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Call InitializeControls()
        Call EnableDisable(True)
        thisScreenMode = ScreenMode.Add
    End Sub

    Public Sub saveVendor()
        Try
            If validateVendor() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "SELECT max(ven_id) AS vendor_id FROM public.gen_Vendor"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        If IsDBNull(obj) Then
                            intVendorID = 1
                        Else
                            intVendorID = CInt(obj.ToString) + 1
                        End If
                        txtVendorNo.Text = intVendorID.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertVendor()
                        trans.Commit()
                        MsgBox("Vendor Id : " & txtVendorNo.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
                    Case 2
                        Call UpdateVendor()
                        MsgBox("Vendor Modified", MsgBoxStyle.Information, gCompanyShortName)
                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Vendor ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteVendor()
                            trans.Commit()
                            MsgBox("Vendor ID : " & txtVendorNo.Text & " Deleted", MsgBoxStyle.Information, gCompanyShortName)
                        End If

                End Select
                Call InitializeControls()
                cmdEdit.Enabled = True
                cmdDelete.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub InsertVendor()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertVendor(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@vendorId", OdbcType.Int).Value = CInt(txtVendorNo.Text)
            cmd.Parameters.AddWithValue("@vendorName", OdbcType.NText).Value = txtVendorName.Text.Trim
            cmd.Parameters.AddWithValue("@vendorAdd1", OdbcType.NText).Value = txtVendorAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@vendorAdd2", OdbcType.NText).Value = txtVendorAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@vendorCity", OdbcType.NText).Value = txtVendorCity.Text.Trim
            cmd.Parameters.AddWithValue("@vendorState", OdbcType.NText).Value = txtVendorState.Text.Trim
            cmd.Parameters.AddWithValue("@vendorPin", OdbcType.NText).Value = txtVendorPin.Text.Trim
            cmd.Parameters.AddWithValue("@vendorGST", OdbcType.NText).Value = txtVendorGST.Text.Trim
            cmd.Parameters.AddWithValue("@vendorCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@vendorEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@vendorPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub


    Sub UpdateVendor()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.UpdateVendor(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@VendorId", OdbcType.Int).Value = CInt(txtVendorNo.Text)
            cmd.Parameters.AddWithValue("@VendorName", OdbcType.NText).Value = txtVendorName.Text.Trim
            cmd.Parameters.AddWithValue("@VendorAdd1", OdbcType.NText).Value = txtVendorAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@VendorAdd2", OdbcType.NText).Value = txtVendorAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@VendorCity", OdbcType.NText).Value = txtVendorCity.Text.Trim
            cmd.Parameters.AddWithValue("@VendorState", OdbcType.NText).Value = txtVendorState.Text.Trim
            cmd.Parameters.AddWithValue("@VendorPin", OdbcType.NText).Value = txtVendorPin.Text.Trim
            cmd.Parameters.AddWithValue("@VendorGST", OdbcType.NText).Value = txtVendorGST.Text.Trim
            cmd.Parameters.AddWithValue("@VendorCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@VendorEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@VendorPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteVendor()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteVendor(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@Vendorid", OdbcType.Int).Value = CInt(txtVendorNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub populateVendor(intVendorNo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            txtVendorNo.Text = ds.Tables(0).Rows(0).Item("ven_id").ToString
            txtVendorName.Text = ds.Tables(0).Rows(0).Item("ven_name").ToString
            txtVendorAdd1.Text = ds.Tables(0).Rows(0).Item("ven_address1").ToString
            txtVendorAdd2.Text = ds.Tables(0).Rows(0).Item("ven_address2").ToString
            txtVendorCity.Text = ds.Tables(0).Rows(0).Item("ven_city").ToString
            txtVendorState.Text = ds.Tables(0).Rows(0).Item("ven_state").ToString
            txtVendorPin.Text = ds.Tables(0).Rows(0).Item("ven_pin").ToString
            txtVendorGST.Text = ds.Tables(0).Rows(0).Item("ven_gst").ToString
            txtContactPerson.Text = ds.Tables(0).Rows(0).Item("ven_contact_person").ToString
            txtEmailId.Text = ds.Tables(0).Rows(0).Item("ven_emailid").ToString
            txtPhone.Text = ds.Tables(0).Rows(0).Item("ven_phone").ToString
            If ds.Tables(0).Rows(0).Item("is_active").ToString = "1" Then
                chkIsActive.Checked = True
            Else
                chkIsActive.Checked = False
            End If
        End If
    End Sub

    Public Function validateVendor() As Boolean
        If thisScreenMode = 2 Or thisScreenMode = 3 Then
            If txtVendorNo.Text = "" Then
                MsgBox("Vendor Id is Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorNo.Focus()
                Return False
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        Else
            If txtVendorName.Text = "" Then
                MsgBox("Vendor Name Should Not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorName.Focus()
                Return False
                Exit Function
            End If
            If txtVendorAdd1.Text = "" Then
                MsgBox("Vendor Address should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorAdd1.Focus()
                Return False
                Exit Function
            End If
            If txtVendorCity.Text = "" Then
                MsgBox("Vendor City Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorCity.Focus()
                Return False
                Exit Function
            End If
            If txtVendorPin.Text = "" Then
                MsgBox("Vendor Pin Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorPin.Focus()
                Return False
                Exit Function
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        End If
        Return True
    End Function


    Sub VendorKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveVendor()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Sub TxtVendorNoKeyDown(sender As Object, e As KeyEventArgs)
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getVendor()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtVendorNo.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub


    Sub TxtVendorNoPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs)

    End Sub

    Sub TxtVendorNoKeyPress(sender As Object, e As KeyPressEventArgs)

    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtVendorNo.Focus()
    End Sub

    Private Sub txtVendorNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtVendorNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getVendor()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtVendorNo.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("Vendor table is empty", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveVendor()
    End Sub

    Private Sub txtVendorNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtVendorNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtVendorNo.Text <> "" Then
            ds = getVendor(CInt(txtVendorNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateVendor(CInt(txtVendorNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Vendor ID", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorNo.Focus()
            End If
        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub txtVendorNo_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtVendorNo.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtVendorNo.Text <> "" Then
            ds = getVendor(CInt(txtVendorNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateVendor(CInt(txtVendorNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Vendor ID", MsgBoxStyle.Information, gCompanyShortName)
                txtVendorNo.Focus()
            End If
        End If
    End Sub
End Class
