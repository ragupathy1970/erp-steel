﻿
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production

Public Class Rejection
    Dim thisScreenMode As Integer
    Dim i As Integer
    Dim dblThickness As Double
    Dim strSQL As String
    Dim lvw As ListViewItem
    Dim ds As DataSet
    Dim ds1 As DataSet
    Dim ds2 As DataSet
    Dim csno As Integer = 0
    Dim cItem As Integer = 1
    Dim cUom As Integer = 3
    Dim cQty As Integer = 4
    Dim cproqtyinnos As Integer = 5
    Dim cproqtyintones As Integer = 6
    Dim obj As Object
    Dim cSlnoKey As Integer = 7
    Dim cUomKey As Integer = 8
    Dim trans As OdbcTransaction
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim intQtyinnos As Integer = 0
    Dim intQtyintones As Double = 0
    Dim intbundlenos As Integer = 0

    Private Sub Rejection_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call getSysDateTime()
        dtProduction.Value = gSysDate
        ds = getUom()
        If ds.Tables(0).Rows.Count > 0 Then
            With cmbUom
                .DataSource = ds.Tables(0)
                .DisplayMember = "uom_short_desc"
                .ValueMember = "uom_id"
            End With
        End If
        thisScreenMode = ScreenMode.Add
        Call InitializeControls()
        Call EnableDisable(True)
    End Sub

    Sub InitializeControls()
        i = 0
        dblThickness = 0
        Call getSysDateTime()
        txtRejectionId.Text = ""
        dtProduction.Value = gSysDate
        txtMachineID.Text = ""
        lblMachine.Text = ""
        txtItemId.Text = ""
        txtDescription.Text = ""
        cmbUom.Text = ""
        txtQty.Text = ""
        intDelRecSno = 0
        intQtyinnos = 0
        intQtyintones = 0
        lvwRoll.Items.Clear()
        cmdAdd.Enabled = True
        cmdEdit.Enabled = True
        cmdCancel.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub EnableDisable(toggle As Boolean)
        txtRejectionId.Enabled = Not toggle
        dtProduction.Enabled = toggle
        txtMachineID.Enabled = toggle
        txtItemId.Enabled = toggle
        txtDescription.Enabled = False
        txtQty.Enabled = toggle
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Call addItem()
    End Sub

    Sub addItem()
        If validateItem() Then
            i += 1
            lvw = lvwRoll.Items.Add(i.ToString)
            lvw.SubItems.Add(txtItemId.Text)
            lvw.SubItems.Add(txtDescription.Text)
            lvw.SubItems.Add(cmbUom.Text)
            lvw.SubItems.Add(txtQty.Text)
            ds1 = getItem(CInt(txtItemId.Text))
            Select Case cmbUom.Text
                Case "bdl"
                    intbundlenos = Val(ds1.Tables(0).Rows(0).Item("bundle_nos").ToString)
                    intQtyinnos = intbundlenos * Val(txtQty.Text)
                    intQtyintones = Format(Val(ds1.Tables(0).Rows(0).Item("unitweight").ToString) * Val(ds1.Tables(0).Rows(0).Item("item_length").ToString) * intQtyinnos / 1000, "#0.000")
                Case "Nos"
                    intQtyinnos = Val(txtQty.Text)
                    intQtyintones = Format(Val(ds1.Tables(0).Rows(0).Item("unitweight").ToString) * Val(ds1.Tables(0).Rows(0).Item("item_length").ToString) * intQtyinnos / 1000, "#0.000")
            End Select
            lvw.SubItems.Add(intQtyinnos)
            lvw.SubItems.Add(intQtyintones)
            lvw.SubItems.Add("")
            lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
            Call clearItem()
        End If
    End Sub

    Private Function validateItem() As Boolean
        If txtItemId.Text = "" Then
            MsgBox("Please Enter Item ID", MsgBoxStyle.Information, gCompanyShortName)
            txtItemId.Focus()
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please select Uom", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus()
            Return False
            Exit Function
        End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
            Exit Function
        End If
        Return True
    End Function
    Public Sub clearItem()
        txtItemId.Text = ""
        txtDescription.Text = ""
        cmbUom.Text = ""
        txtQty.Text = ""
    End Sub
    Sub CmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub
    Private Sub txtMachineID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMachineID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getMill(0)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()
                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtMachineID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is no machine found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub
    Private Sub txtMachineID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMachineID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtItemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemId.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getPipes()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemId.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub txtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemId.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemId.Text = "" Then
                ds1 = getPipes(CInt(txtItemId.Text))
                Call populateItemDesc(ds1)
            End If
        End If

    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
        Else
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If
    End Sub

    Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtItemId_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemId.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtRejectionid_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRejectionId.KeyPress
        If Asc(e.KeyChar) = 13 And Val(txtRejectionId.Text) > 0 Then
            ds = getRollHdr(CInt(txtRejectionId.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateRollHdr(CInt(txtRejectionId.Text))
                Call populateRollTrn(CInt(txtRejectionId.Text))
                EnableDisable(True)
            Else
                MsgBox("No record found in this production production id", MsgBoxStyle.Information, gCompanyShortName)
                txtRejectionId.Focus()
            End If
        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If

    End Sub
    Sub populateRollHdr(intRejectionID)
        dtProduction.Text = ds.Tables(0).Rows(0).Item("pro_roll_dt").ToString
        txtMachineID.Text = ds.Tables(0).Rows(0).Item("pro_machine_id").ToString
        Select Case ds.Tables(0).Rows(0).Item("pro_shift").ToString
            Case "A"
                rdoShift1.Checked = True
            Case "B"
                rdoShift2.Checked = True
            Case "C"
                rdoShift3.Checked = True
            Case Else
                rdoShift4.Checked = True
        End Select
        ds1 = getMill(txtMachineID.Text)
        If ds1.Tables(0).Rows.Count > 0 Then
            lblMachine.Text = ds1.Tables(0).Rows(0).Item("mill_name").ToString
        End If
    End Sub
    Sub populateRollTrn(intRejectionID)
        ds = getRollTrn(intRejectionID)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                lvw = lvwRoll.Items.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                With lvw
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_innos").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_intones").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                End With
                i += 1
            Next
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtRejectionId.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveRoll()
    End Sub
    Sub saveRoll()
        Try
            If validateRoll() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "Select nextval('pro_rejection_id_seq') AS pro_rejection_id"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        txtRejectionId.Text = obj.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertRollHdr()
                        Call InsertRollTrn()
                        trans.Commit()
                    Case 2

                        Call updateRollHdr()
                        Call updateRollTrn()

                    Case 3
                        If MsgBox("Are You Sure You want to Delete this production roll id ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteRollTrn()
                            Call deleteRollHdr()
                            trans.Commit()

                        End If

                End Select
                Call InitializeControls()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub
    Sub InsertRollHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertRejectionHdr(?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text)
            dt = Date.ParseExact(Format(CDate(dtProduction.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@prorolldt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@promachineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub InsertRollTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwRoll.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertRejectionTrn(?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text.Trim)
                cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(cItem).Text)
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = Val(lvwRoll.Items(n).SubItems(cQty).Text)
                cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cproqtyinnos).Text)
                cmd.Parameters.AddWithValue("@proqtyintones", OdbcType.Double).Value = Val(lvwRoll.Items(n).SubItems(cproqtyintones).Text)
                cmd.ExecuteScalar()
            Next

            MsgBox("Production rolling rejection id : " & txtRejectionId.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateRollHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateRejectionHdr(?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text)
            dt = Date.ParseExact(Format(CDate(dtProduction.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@prorolldt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@promachineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateRollTrn()
        Dim cmd As New OdbcCommand

        Try
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delRejectionTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwRoll.Items.Count - 1
                If Not lvwRoll.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateRejectionTrn(?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text.Trim)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(cItem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = Val(lvwRoll.Items(n).SubItems(cQty).Text)
                    cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cproqtyinnos).Text)
                    cmd.Parameters.AddWithValue("@proqtyintones", OdbcType.Double).Value = Val(lvwRoll.Items(n).SubItems(cproqtyintones).Text)
                    cmd.Parameters.AddWithValue("@slnokey", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                End If
            Next
            For n = 0 To lvwRoll.Items.Count - 1
                If lvwRoll.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertRejectionTrn(?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text.Trim)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwRoll.Items(n).SubItems(cItem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = Val(lvwRoll.Items(n).SubItems(cQty).Text)
                    cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Int).Value = Val(lvwRoll.Items(n).SubItems(cproqtyinnos).Text)
                    cmd.Parameters.AddWithValue("@proqtyintones", OdbcType.Double).Value = Val(lvwRoll.Items(n).SubItems(cproqtyintones).Text)
                    cmd.ExecuteScalar()
                End If
            Next
            Call EnableDisable(True)
            Call InitializeControls()
            MsgBox("Production roll rejection id modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteRollHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteRejectionHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteRollTrn()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteRejectionTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@prorejectionid", OdbcType.Int).Value = CInt(txtRejectionId.Text)
            cmd.ExecuteScalar()
            MsgBox("Production roll rejection id : " & txtRejectionId.Text & " Deleted", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Private Function validateRoll() As Boolean
        If thisScreenMode = ScreenMode.Edit Or thisScreenMode = ScreenMode.Delete Then
            If txtRejectionId.Text = "" Then
                MsgBox("Enter production rolling number", MsgBoxStyle.Information, gCompanyShortName)
                txtRejectionId.Focus()
                Return False
            End If
        Else
            If thisScreenMode = ScreenMode.Add Then

                If txtMachineID.Text = "" Then
                    MsgBox("Please Enter Machine ID", MsgBoxStyle.Information, gCompanyShortName)
                    txtMachineID.Focus()
                    Return False
                End If
                If rdoShift1.Checked = False And rdoShift2.Checked = False And rdoShift3.Checked = False And rdoShift4.Checked = False Then
                    MsgBox("Please Select Shift", MsgBoxStyle.Information, gCompanyShortName)
                    rdoShift4.Focus()
                    Return False
                End If
            End If
            If lvwRoll.Items.Count = 0 Then
                MsgBox("Please Add Item", MsgBoxStyle.Information, gCompanyShortName)
                txtItemId.Focus()
                Return False
                Exit Function
            End If
        End If
        Return True
    End Function

    Private Sub txtMachineID_Leave(sender As Object, e As EventArgs) Handles txtMachineID.Leave
        If Val(txtMachineID.Text) > 0 Then
            ds = getMill(CInt(txtMachineID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                lblMachine.Text = ds.Tables(0).Rows(0).Item("mill_name").ToString
            Else
                MsgBox("Machine id not found", MsgBoxStyle.Information, gCompanyShortName)
                txtMachineID.Text = ""
                lblMachine.Text = ""
                Exit Sub
            End If
        End If
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtRejectionId.Focus()
    End Sub

    Private Sub lvwRoll_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwRoll.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwRoll.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwRoll.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwRoll.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwRoll.Items.RemoveAt(lvwRoll.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub
    Sub setSlno()
        i = 0
        For n = 0 To lvwRoll.Items.Count - 1
            i += 1
            lvwRoll.Items(n).Text = i.ToString
        Next
    End Sub

    Private Sub Rejection_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveRoll()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub
End Class