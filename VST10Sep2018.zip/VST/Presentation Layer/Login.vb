﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 05-01-2018
' Time: 12:25
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.IO
Imports System.Configuration
Imports System.Windows.Forms
Imports VST.constants

Public Class Login 
	
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	Sub FrmLoginKeyPress(sender As Object, e As System.Windows.Forms.KeyPressEventArgs) Handles MyBase.KeyPress
		If  Asc(e.KeyChar) = 27 Then
			Main.Quit
		End If
		If Asc(e.KeyChar) = 13 Then
			If validateUser Then
				Main.checkUserNamePassword
			End If
		End If
	End Sub
	
	Sub LoginLoad(sender As Object, e As EventArgs) Handles MyBase.Load
		Call ClearAll
		txtUserName.Focus()
        AddHandler cmdOk.Click, AddressOf Main.checkUserNamePassword
        AddHandler Me.cmdCancel.Click,AddressOf Main.Quit
        'txtUserName.Text = "RAGUPATHY"
        'txtUserName.SelectionStart=0
        'txtPassword.Text = "ragu"
    End Sub
	
	Private Sub ClearAll()
		txtUserName.Text = ""
		txtPassword.Text = ""
	End Sub
	
	Private Function validateUser() As Boolean
		If txtUserName.Text.ToString.Trim() = "" Then
			'Call MessageBox.Show("Please enter the Username", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information)
			MsgBox("Please Enter User Name", MsgBoxStyle.Information,gCompanyShortName)
			txtUserName.Focus()
			Return False
			Exit Function
		End If
		
		If txtPassword.Text.ToString.Trim() = "" Then
			'Call MessageBox.Show("Please enter the Password", "Login", MessageBoxButtons.OK, MessageBoxIcon.Information)
			MsgBox("Please Enter Password", MsgBoxStyle.Information,gCompanyShortName)
			txtPassword.Focus()
			Return False
			Exit Function
		End If
		gUserName = txtUserName.Text.ToString.Trim
		gPassword = txtPassword.Text.ToString.Trim
		Return True
	End Function

    Private Sub cmdOk_Click(sender As Object, e As EventArgs) Handles cmdOk.Click
        If validateUser() Then
        End If
    End Sub
End Class
