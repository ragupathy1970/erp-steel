﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 03:40
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Item
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.grpItemmaster = New System.Windows.Forms.GroupBox()
        Me.lblStockNos = New System.Windows.Forms.Label()
        Me.lblStockMt = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtBundleNos = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.grpTax = New System.Windows.Forms.GroupBox()
        Me.txtIGST = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtGST = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtSGST = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtCGST = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.grpWeight = New System.Windows.Forms.GroupBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtSlitWidth = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtOD = New System.Windows.Forms.TextBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.txtUnitWeight = New System.Windows.Forms.TextBox()
        Me.label12 = New System.Windows.Forms.Label()
        Me.txtBreadth = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.txtWidth = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtThickness = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.txtHSN = New System.Windows.Forms.TextBox()
        Me.cmdGenItem = New System.Windows.Forms.Button()
        Me.cmbUomLength = New System.Windows.Forms.ComboBox()
        Me.txtLength = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.cmbIsi = New System.Windows.Forms.ComboBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.chkIsActive = New System.Windows.Forms.CheckBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtGrade = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.cmbItemType = New System.Windows.Forms.ComboBox()
        Me.txtItemNo = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.grpItemmaster.SuspendLayout()
        Me.grpTax.SuspendLayout()
        Me.grpWeight.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpItemmaster
        '
        Me.grpItemmaster.Controls.Add(Me.lblStockNos)
        Me.grpItemmaster.Controls.Add(Me.lblStockMt)
        Me.grpItemmaster.Controls.Add(Me.Label24)
        Me.grpItemmaster.Controls.Add(Me.txtBundleNos)
        Me.grpItemmaster.Controls.Add(Me.Label23)
        Me.grpItemmaster.Controls.Add(Me.grpTax)
        Me.grpItemmaster.Controls.Add(Me.Label15)
        Me.grpItemmaster.Controls.Add(Me.grpWeight)
        Me.grpItemmaster.Controls.Add(Me.txtHSN)
        Me.grpItemmaster.Controls.Add(Me.cmdGenItem)
        Me.grpItemmaster.Controls.Add(Me.cmbUomLength)
        Me.grpItemmaster.Controls.Add(Me.txtLength)
        Me.grpItemmaster.Controls.Add(Me.label10)
        Me.grpItemmaster.Controls.Add(Me.label9)
        Me.grpItemmaster.Controls.Add(Me.cmbIsi)
        Me.grpItemmaster.Controls.Add(Me.label8)
        Me.grpItemmaster.Controls.Add(Me.cmbUom)
        Me.grpItemmaster.Controls.Add(Me.chkIsActive)
        Me.grpItemmaster.Controls.Add(Me.txtDescription)
        Me.grpItemmaster.Controls.Add(Me.label7)
        Me.grpItemmaster.Controls.Add(Me.txtGrade)
        Me.grpItemmaster.Controls.Add(Me.label6)
        Me.grpItemmaster.Controls.Add(Me.label2)
        Me.grpItemmaster.Controls.Add(Me.cmbItemType)
        Me.grpItemmaster.Controls.Add(Me.txtItemNo)
        Me.grpItemmaster.Controls.Add(Me.label1)
        Me.grpItemmaster.Location = New System.Drawing.Point(25, 13)
        Me.grpItemmaster.Name = "grpItemmaster"
        Me.grpItemmaster.Size = New System.Drawing.Size(550, 493)
        Me.grpItemmaster.TabIndex = 20
        Me.grpItemmaster.TabStop = False
        '
        'lblStockNos
        '
        Me.lblStockNos.Location = New System.Drawing.Point(99, 437)
        Me.lblStockNos.Name = "lblStockNos"
        Me.lblStockNos.Size = New System.Drawing.Size(63, 19)
        Me.lblStockNos.TabIndex = 61
        '
        'lblStockMt
        '
        Me.lblStockMt.Location = New System.Drawing.Point(97, 413)
        Me.lblStockMt.Name = "lblStockMt"
        Me.lblStockMt.Size = New System.Drawing.Size(66, 19)
        Me.lblStockMt.TabIndex = 60
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(40, 415)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(43, 19)
        Me.Label24.TabIndex = 59
        Me.Label24.Text = "Stock"
        '
        'txtBundleNos
        '
        Me.txtBundleNos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBundleNos.Location = New System.Drawing.Point(101, 183)
        Me.txtBundleNos.Name = "txtBundleNos"
        Me.txtBundleNos.Size = New System.Drawing.Size(87, 22)
        Me.txtBundleNos.TabIndex = 55
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(18, 182)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(76, 41)
        Me.Label23.TabIndex = 57
        Me.Label23.Text = "No. Of Pcs per Bundle"
        '
        'grpTax
        '
        Me.grpTax.Controls.Add(Me.txtIGST)
        Me.grpTax.Controls.Add(Me.Label22)
        Me.grpTax.Controls.Add(Me.txtGST)
        Me.grpTax.Controls.Add(Me.Label21)
        Me.grpTax.Controls.Add(Me.txtSGST)
        Me.grpTax.Controls.Add(Me.Label20)
        Me.grpTax.Controls.Add(Me.txtCGST)
        Me.grpTax.Controls.Add(Me.Label3)
        Me.grpTax.Location = New System.Drawing.Point(302, 338)
        Me.grpTax.Name = "grpTax"
        Me.grpTax.Size = New System.Drawing.Size(184, 146)
        Me.grpTax.TabIndex = 54
        Me.grpTax.TabStop = False
        Me.grpTax.Text = "Tax"
        '
        'txtIGST
        '
        Me.txtIGST.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIGST.Location = New System.Drawing.Point(76, 110)
        Me.txtIGST.Name = "txtIGST"
        Me.txtIGST.Size = New System.Drawing.Size(87, 22)
        Me.txtIGST.TabIndex = 68
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(31, 111)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(45, 19)
        Me.Label22.TabIndex = 69
        Me.Label22.Text = "IGST"
        '
        'txtGST
        '
        Me.txtGST.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGST.Location = New System.Drawing.Point(76, 18)
        Me.txtGST.Name = "txtGST"
        Me.txtGST.Size = New System.Drawing.Size(87, 22)
        Me.txtGST.TabIndex = 66
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(32, 19)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(43, 19)
        Me.Label21.TabIndex = 67
        Me.Label21.Text = "GST"
        '
        'txtSGST
        '
        Me.txtSGST.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSGST.Location = New System.Drawing.Point(76, 81)
        Me.txtSGST.Name = "txtSGST"
        Me.txtSGST.Size = New System.Drawing.Size(87, 22)
        Me.txtSGST.TabIndex = 64
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(24, 50)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(48, 19)
        Me.Label20.TabIndex = 65
        Me.Label20.Text = "CGST"
        '
        'txtCGST
        '
        Me.txtCGST.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCGST.Location = New System.Drawing.Point(76, 51)
        Me.txtCGST.Name = "txtCGST"
        Me.txtCGST.Size = New System.Drawing.Size(87, 22)
        Me.txtCGST.TabIndex = 62
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 19)
        Me.Label3.TabIndex = 63
        Me.Label3.Text = "SGST"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(453, 92)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(30, 16)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "mm"
        '
        'grpWeight
        '
        Me.grpWeight.Controls.Add(Me.Label26)
        Me.grpWeight.Controls.Add(Me.txtSlitWidth)
        Me.grpWeight.Controls.Add(Me.Label25)
        Me.grpWeight.Controls.Add(Me.Label19)
        Me.grpWeight.Controls.Add(Me.Label18)
        Me.grpWeight.Controls.Add(Me.Label17)
        Me.grpWeight.Controls.Add(Me.Label16)
        Me.grpWeight.Controls.Add(Me.txtOD)
        Me.grpWeight.Controls.Add(Me.label11)
        Me.grpWeight.Controls.Add(Me.txtUnitWeight)
        Me.grpWeight.Controls.Add(Me.label12)
        Me.grpWeight.Controls.Add(Me.txtBreadth)
        Me.grpWeight.Controls.Add(Me.label13)
        Me.grpWeight.Controls.Add(Me.txtWidth)
        Me.grpWeight.Controls.Add(Me.label5)
        Me.grpWeight.Controls.Add(Me.txtThickness)
        Me.grpWeight.Controls.Add(Me.label4)
        Me.grpWeight.Location = New System.Drawing.Point(253, 62)
        Me.grpWeight.Name = "grpWeight"
        Me.grpWeight.Size = New System.Drawing.Size(278, 199)
        Me.grpWeight.TabIndex = 38
        Me.grpWeight.TabStop = False
        Me.grpWeight.Text = "Weight Calculation"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(201, 159)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(30, 16)
        Me.Label26.TabIndex = 52
        Me.Label26.Text = "mm"
        '
        'txtSlitWidth
        '
        Me.txtSlitWidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSlitWidth.Location = New System.Drawing.Point(111, 157)
        Me.txtSlitWidth.Name = "txtSlitWidth"
        Me.txtSlitWidth.Size = New System.Drawing.Size(87, 22)
        Me.txtSlitWidth.TabIndex = 51
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(36, 160)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(76, 19)
        Me.Label25.TabIndex = 50
        Me.Label25.Text = "Slit Width"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(230, 131)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(39, 16)
        Me.Label19.TabIndex = 49
        Me.Label19.Text = "Kg/m"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(200, 105)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(30, 16)
        Me.Label18.TabIndex = 48
        Me.Label18.Text = "mm"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(200, 80)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(30, 16)
        Me.Label17.TabIndex = 47
        Me.Label17.Text = "mm"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(200, 55)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(30, 16)
        Me.Label16.TabIndex = 46
        Me.Label16.Text = "mm"
        '
        'txtOD
        '
        Me.txtOD.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOD.Location = New System.Drawing.Point(110, 103)
        Me.txtOD.Name = "txtOD"
        Me.txtOD.Size = New System.Drawing.Size(87, 22)
        Me.txtOD.TabIndex = 7
        '
        'label11
        '
        Me.label11.Location = New System.Drawing.Point(10, 104)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(99, 19)
        Me.label11.TabIndex = 44
        Me.label11.Text = "Outer Diameter"
        '
        'txtUnitWeight
        '
        Me.txtUnitWeight.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUnitWeight.Enabled = False
        Me.txtUnitWeight.Location = New System.Drawing.Point(110, 129)
        Me.txtUnitWeight.Name = "txtUnitWeight"
        Me.txtUnitWeight.Size = New System.Drawing.Size(119, 22)
        Me.txtUnitWeight.TabIndex = 42
        '
        'label12
        '
        Me.label12.Location = New System.Drawing.Point(30, 132)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(83, 19)
        Me.label12.TabIndex = 41
        Me.label12.Text = "Unit Weight"
        '
        'txtBreadth
        '
        Me.txtBreadth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBreadth.Location = New System.Drawing.Point(111, 77)
        Me.txtBreadth.Name = "txtBreadth"
        Me.txtBreadth.Size = New System.Drawing.Size(87, 22)
        Me.txtBreadth.TabIndex = 6
        '
        'label13
        '
        Me.label13.Location = New System.Drawing.Point(53, 79)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(66, 19)
        Me.label13.TabIndex = 40
        Me.label13.Text = "Breadth"
        '
        'txtWidth
        '
        Me.txtWidth.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtWidth.Location = New System.Drawing.Point(110, 51)
        Me.txtWidth.Name = "txtWidth"
        Me.txtWidth.Size = New System.Drawing.Size(87, 22)
        Me.txtWidth.TabIndex = 5
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(62, 54)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(51, 19)
        Me.label5.TabIndex = 38
        Me.label5.Text = "Width"
        '
        'txtThickness
        '
        Me.txtThickness.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtThickness.Location = New System.Drawing.Point(110, 25)
        Me.txtThickness.Name = "txtThickness"
        Me.txtThickness.Size = New System.Drawing.Size(87, 22)
        Me.txtThickness.TabIndex = 4
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(42, 25)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(71, 19)
        Me.label4.TabIndex = 14
        Me.label4.Text = "Thickness"
        '
        'txtHSN
        '
        Me.txtHSN.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtHSN.Location = New System.Drawing.Point(103, 332)
        Me.txtHSN.Name = "txtHSN"
        Me.txtHSN.Size = New System.Drawing.Size(87, 22)
        Me.txtHSN.TabIndex = 13
        '
        'cmdGenItem
        '
        Me.cmdGenItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdGenItem.Location = New System.Drawing.Point(362, 299)
        Me.cmdGenItem.Name = "cmdGenItem"
        Me.cmdGenItem.Size = New System.Drawing.Size(125, 35)
        Me.cmdGenItem.TabIndex = 15
        Me.cmdGenItem.Text = "Generate Item"
        Me.cmdGenItem.UseVisualStyleBackColor = True
        '
        'cmbUomLength
        '
        Me.cmbUomLength.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmbUomLength.FormattingEnabled = True
        Me.cmbUomLength.Location = New System.Drawing.Point(196, 144)
        Me.cmbUomLength.Name = "cmbUomLength"
        Me.cmbUomLength.Size = New System.Drawing.Size(47, 24)
        Me.cmbUomLength.TabIndex = 9
        '
        'txtLength
        '
        Me.txtLength.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLength.Location = New System.Drawing.Point(103, 145)
        Me.txtLength.Name = "txtLength"
        Me.txtLength.Size = New System.Drawing.Size(87, 22)
        Me.txtLength.TabIndex = 8
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(48, 146)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(50, 19)
        Me.label10.TabIndex = 28
        Me.label10.Text = "Length"
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(13, 77)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(79, 19)
        Me.label9.TabIndex = 27
        Me.label9.Text = "ISI Standard"
        '
        'cmbIsi
        '
        Me.cmbIsi.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmbIsi.FormattingEnabled = True
        Me.cmbIsi.Location = New System.Drawing.Point(106, 72)
        Me.cmbIsi.Name = "cmbIsi"
        Me.cmbIsi.Size = New System.Drawing.Size(84, 24)
        Me.cmbIsi.TabIndex = 3
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(57, 304)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(40, 17)
        Me.label8.TabIndex = 25
        Me.label8.Text = "UOM"
        '
        'cmbUom
        '
        Me.cmbUom.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(103, 299)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(60, 24)
        Me.cmbUom.TabIndex = 12
        '
        'chkIsActive
        '
        Me.chkIsActive.Location = New System.Drawing.Point(102, 363)
        Me.chkIsActive.Name = "chkIsActive"
        Me.chkIsActive.Size = New System.Drawing.Size(88, 21)
        Me.chkIsActive.TabIndex = 14
        Me.chkIsActive.Text = "Is Active"
        Me.chkIsActive.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(103, 267)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(384, 22)
        Me.txtDescription.TabIndex = 11
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(23, 268)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(74, 19)
        Me.label7.TabIndex = 21
        Me.label7.Text = "Item Name"
        '
        'txtGrade
        '
        Me.txtGrade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtGrade.Location = New System.Drawing.Point(103, 109)
        Me.txtGrade.Name = "txtGrade"
        Me.txtGrade.Size = New System.Drawing.Size(87, 22)
        Me.txtGrade.TabIndex = 10
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(54, 110)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(51, 19)
        Me.label6.TabIndex = 18
        Me.label6.Text = "Grade"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(258, 35)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(66, 19)
        Me.label2.TabIndex = 8
        Me.label2.Text = "Item Type"
        '
        'cmbItemType
        '
        Me.cmbItemType.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmbItemType.FormattingEnabled = True
        Me.cmbItemType.Location = New System.Drawing.Point(329, 32)
        Me.cmbItemType.Name = "cmbItemType"
        Me.cmbItemType.Size = New System.Drawing.Size(202, 24)
        Me.cmbItemType.TabIndex = 2
        '
        'txtItemNo
        '
        Me.txtItemNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemNo.Location = New System.Drawing.Point(103, 32)
        Me.txtItemNo.Name = "txtItemNo"
        Me.txtItemNo.Size = New System.Drawing.Size(87, 22)
        Me.txtItemNo.TabIndex = 1
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(40, 33)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(54, 19)
        Me.label1.TabIndex = 1
        Me.label1.Text = "Item ID"
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(299, 512)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 16
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(486, 512)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 18
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(393, 512)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 17
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(83, 345)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(40, 19)
        Me.Label14.TabIndex = 26
        Me.Label14.Text = "HSN"
        '
        'Item
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(597, 562)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.grpItemmaster)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "Item"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Item Master"
        Me.grpItemmaster.ResumeLayout(False)
        Me.grpItemmaster.PerformLayout()
        Me.grpTax.ResumeLayout(False)
        Me.grpTax.PerformLayout()
        Me.grpWeight.ResumeLayout(False)
        Me.grpWeight.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents txtItemNo As System.Windows.Forms.TextBox
    Private WithEvents cmbItemType As System.Windows.Forms.ComboBox
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents txtGrade As System.Windows.Forms.TextBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents chkIsActive As System.Windows.Forms.CheckBox
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents cmbIsi As System.Windows.Forms.ComboBox
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents txtLength As System.Windows.Forms.TextBox
    Private WithEvents cmbUomLength As System.Windows.Forms.ComboBox
    Private WithEvents cmdGenItem As System.Windows.Forms.Button
    Private WithEvents grpItemmaster As System.Windows.Forms.GroupBox
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents txtHSN As System.Windows.Forms.TextBox
    Private WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents grpWeight As System.Windows.Forms.GroupBox
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents txtThickness As System.Windows.Forms.TextBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents txtWidth As System.Windows.Forms.TextBox
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents txtBreadth As System.Windows.Forms.TextBox
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents txtUnitWeight As System.Windows.Forms.TextBox
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents txtOD As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents grpTax As System.Windows.Forms.GroupBox
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtCGST As System.Windows.Forms.TextBox
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents txtSGST As System.Windows.Forms.TextBox
    Private WithEvents Label21 As System.Windows.Forms.Label
    Private WithEvents txtGST As System.Windows.Forms.TextBox
    Private WithEvents Label22 As System.Windows.Forms.Label
    Private WithEvents txtIGST As System.Windows.Forms.TextBox
    Private WithEvents txtBundleNos As System.Windows.Forms.TextBox
    Private WithEvents Label23 As System.Windows.Forms.Label
    Private WithEvents lblStockNos As System.Windows.Forms.Label
    Private WithEvents lblStockMt As System.Windows.Forms.Label
    Private WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Private WithEvents txtSlitWidth As System.Windows.Forms.TextBox
    Private WithEvents Label25 As System.Windows.Forms.Label
End Class
