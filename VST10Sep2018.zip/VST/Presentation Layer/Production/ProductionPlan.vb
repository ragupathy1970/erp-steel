﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 07-02-2018
' Time: 10:35
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Data
Imports System.IO
Imports System.Collections
Imports VST.Constants
Imports System.Configuration
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.Production

Partial Public Class ProductionPlan
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim ds1 As DataSet
    Dim i As Integer = 0
    Dim dblTotal As Double
    Dim lvw As ListViewItem
    Dim intDelRecSno As Integer = 0
    Dim strDelRecSno As String = ""
    Dim csno As Integer = 0
    Dim corderno As Integer = 1
    Dim citem As Integer = 2
    Dim obj As Object
    Dim cuom As Integer = 4
    Dim corderqty As Integer = 5
    Dim cprodqty As Integer = 6
    Dim cplanqty As Integer = 7
    Dim cSlnoKey As Integer = 8
    Dim cUomKey As Integer = 9
    Dim arrDelTrn() As String
    Dim strSQL As String
    Dim trans As OdbcTransaction
    Dim intOrderID As Integer
    Dim editFlag As Boolean = False
    Dim loadFlag As Boolean = False
    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
    End Sub


    Sub CmdCancelClick(sender As Object, e As EventArgs)
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True

    End Sub


    Sub ProductionPlanLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        loadFlag = True
        Dim MyArrayList As New ArrayList
        MyArrayList.Add(New cListItem("January", 1))
        MyArrayList.Add(New cListItem("Februray", 2))
        MyArrayList.Add(New cListItem("March", 3))
        MyArrayList.Add(New cListItem("April", 4))
        MyArrayList.Add(New cListItem("May", 5))
        MyArrayList.Add(New cListItem("June", 6))
        MyArrayList.Add(New cListItem("July", 7))
        MyArrayList.Add(New cListItem("Auguest", 8))
        MyArrayList.Add(New cListItem("September", 9))
        MyArrayList.Add(New cListItem("October", 10))
        MyArrayList.Add(New cListItem("November", 11))
        MyArrayList.Add(New cListItem("December", 12))
        cmbMonth.DataSource = MyArrayList
        cmbMonth.DisplayMember = "Text"
        cmbMonth.ValueMember = "Value"
        ds = getUom()

        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        EnableDisable(True)
        loadFlag = False
    End Sub

    Public Sub InitializeControls()
        Call getSysDateTime()
        cmbMonth.SelectedIndex = -1
        cmbUom.SelectedIndex = -1
        DtPlan.Value = gSysDate
        txtPlanNo.Text = ""
        txtDescription.Text = ""
        txtItemId.Text = ""
        txtOrderNo.Text = ""
        txtQty.Text = ""
        i = 0
        lvwProductionPlan.Items.Clear()
        dblTotal = 0
        intDelRecSno = 0
        txtTotalPlanQty.Text = ""
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True
    End Sub

    Sub EnableDisable(toggle As Boolean)
        txtPlanNo.Enabled = Not toggle
        DtPlan.Enabled = toggle
        cmbMonth.Enabled = toggle
        txtItemId.Enabled = toggle
        txtOrderNo.Enabled = toggle
        txtDescription.Enabled = False
        txtQty.Enabled = toggle
        lvwProductionPlan.Enabled = toggle
        cmbUom.Enabled = toggle
        cmdAdd.Enabled = toggle
        cmdAddItem.Enabled = toggle
        txtTotalPlanQty.Enabled = toggle
    End Sub


    Sub CmdEditClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Edit
        EnableDisable(False)
        cmdEdit.Enabled = False
        cmdAdd.Enabled = False
        cmdDelete.Enabled = False
        txtPlanNo.Focus()
    End Sub


    Sub addItem()
        Try
            If validateItem() Then
                i += 1
                lvw = lvwProductionPlan.Items.Add(i.ToString)
                lvw.SubItems.Add(txtOrderNo.Text)
                lvw.SubItems.Add(txtItemId.Text.ToString)
                lvw.SubItems.Add(txtDescription.Text.ToString)
                lvw.SubItems.Add(cmbUom.Text)
                lvw.SubItems.Add("") ' order qty
                lvw.SubItems.Add("") ' produced qty
                lvw.SubItems.Add(Format(CDbl(txtQty.Text), "#0.000"))
                lvw.SubItems.Add("") ' colslnoKey
                lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
                dblTotal = dblTotal + CDbl(txtQty.Text)
                txtTotalPlanQty.Text = Format(dblTotal, "#0.000")
                Call clearItem()
            Else
                Call clearItem()
            End If
            txtOrderNo.Focus()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateItem()
        dblTotal = dblTotal - Val(lvwProductionPlan.SelectedItems(0).SubItems(cplanqty).Text)
        lvwProductionPlan.SelectedItems(0).SubItems(cplanqty).Text = Format(Val(txtQty.Text), "#0.000")
        dblTotal = dblTotal + Val(txtQty.Text)
        txtTotalPlanQty.Text = Format(dblTotal, "#0.000")
        editFlag = False
        Call clearItem()
    End Sub

    Public Function validateItem() As Boolean
        If txtOrderNo.Text = "" Then
            MsgBox("Please Enter Order No", MsgBoxStyle.Information, gCompanyShortName)
            txtOrderNo.Focus()
            Return False
            Exit Function
        End If
        If txtItemId.Text.Trim = "" Then
            MsgBox("Please Enter Item Id", MsgBoxStyle.Information, gCompanyShortName)
            txtItemId.Focus()
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please Select UOM", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus()
            Return False
            Exit Function
        End If

        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
            Exit Function
        End If
        For n = 0 To lvwProductionPlan.Items.Count - 1
            If txtOrderNo.Text.Trim = lvwProductionPlan.Items(n).SubItems(corderno).Text.Trim And txtItemId.Text.Trim = lvwProductionPlan.Items(n).SubItems(citem).Text.Trim Then
                MsgBox("Item Already Exists in this Order Number", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Next
        Return True
    End Function

    Sub setSlno()
        i = 0
        For n = 0 To lvwProductionPlan.Items.Count - 1
            i += 1
            lvwProductionPlan.Items(n).Text = i.ToString
        Next
    End Sub



    Public Sub clearItem()
        txtItemId.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        cmbUom.Text = ""
        txtOrderNo.Text = ""
    End Sub

    Sub CmdDeleteClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Delete
        Call InitializeControls()
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdAdd.Enabled = False
        cmdDelete.Enabled = False
        txtPlanNo.Focus()
    End Sub



    Sub TxtItemIDPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs)
        If e.KeyCode = Keys.Tab Then
            If Not txtItemId.Text = "" Then
                ds1 = getItem(CInt(txtItemId.Text))
                Call populateItemDesc(ds1)
            End If
        End If

    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
        Else
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If

    End Sub

    Sub ProductionPlanKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call savePlan()
        End If
        If e.KeyCode = Keys.F2 Then
            Call populatePlanToEntry()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Sub savePlan()
        If ValidatePlan() Then
            Call getSysDateTime()
            Select Case thisScreenMode
                Case 1
                    strSQL = "SELECT nextval('plan_id_seq') AS plan_id"
                    obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                    txtPlanNo.Text = obj.ToString
                    trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                    Call InsertPlanHdr()
                    Call InsertPlanTrn()
                    trans.Commit()
                Case 2
                    If intDelRecSno > 1 Then
                        strDelRecSno = String.Join(",", arrDelTrn)
                        strDelRecSno = Mid(strDelRecSno, 2)
                    ElseIf intDelRecSno = 1 Then
                        strDelRecSno = arrDelTrn(1).ToString
                    End If
                    Call updatePlanHdr()
                    Call updatePlanTrn()

                Case 3
                    If MsgBox("Are You Sure You want to Delete this Production Plan ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call deletePlanTrn()
                        Call deletePlanHdr()
                        trans.Commit()
                    End If

            End Select
        End If

    End Sub

    Public Function ValidatePlan() As Boolean
        If cmbMonth.Text = "" Then
            MsgBox("Please Select Month", MsgBoxStyle.Information, gCompanyShortName)
            cmbMonth.Focus()
            Return False
        End If
        If lvwProductionPlan.Items.Count = 0 Then
            MsgBox("Please Enter the Plan", MsgBoxStyle.Information, gCompanyShortName)
            txtOrderNo.Focus()
            Return False
        End If
        Return True
    End Function

    Sub InsertPlanHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertPlanHdr(?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text)
            dt = Date.ParseExact(Format(CDate(DtPlan.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@PlanDt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@PlanMonth", OdbcType.Int).Value = cmbMonth.SelectedValue
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub InsertPlanTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwProductionPlan.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertPlanTrn(?,?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text.Trim())
                cmd.Parameters.AddWithValue("@plansno", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@proordid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(corderno).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(corderqty).Text)
                cmd.Parameters.AddWithValue("@planqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(cplanqty).Text)
                cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
                cmd.ExecuteScalar()
            Next
            MsgBox("Plan ID : " & txtPlanNo.Text & " Created")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updatePlanHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updatePlanHdr(?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text)
            dt = Date.ParseExact(Format(CDate(DtPlan.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@plandt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@planmonth", OdbcType.Int).Value = cmbMonth.SelectedValue
            cmd.Parameters.AddWithValue("@modify_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@modify_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@modify_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updatePlanTrn()
        Dim cmd As New OdbcCommand
        Try
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delPlanTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text)
                    cmd.Parameters.AddWithValue("@plansno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            i = 0
            For n = 0 To lvwProductionPlan.Items.Count - 1
                If Not lvwProductionPlan.Items(n).SubItems(cSlnoKey).Text = "" Then
                    If Val(lvwProductionPlan.Items(n).SubItems(cplanqty).Text) > 0 Then
                        i += 1
                        cmd = ODBCDataAccsess.DbCon.CreateCommand()
                        cmd.CommandText = "SELECT public.updatePlanTrn(?,?,?,?,?,?,?,?,?)"
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text.Trim())
                        cmd.Parameters.AddWithValue("@plansno", OdbcType.Int).Value = CInt(i.ToString) 'CInt(lvwProductionPlan.Items(n).SubItems(csno).Text)
                        cmd.Parameters.AddWithValue("@proordid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(corderno).Text)
                        cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(citem).Text)
                        cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(cUomKey).Text)
                        cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(corderqty).Text)
                        cmd.Parameters.AddWithValue("@planqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(cplanqty).Text)
                        cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
                        cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(cSlnoKey).Text)
                        cmd.ExecuteScalar()
                    End If
                End If
            Next
            For n = 0 To lvwProductionPlan.Items.Count - 1
                If lvwProductionPlan.Items(n).SubItems(cSlnoKey).Text = "" Then
                    If Val(lvwProductionPlan.Items(n).SubItems(cplanqty).Text) > 0 Then
                        i += 1
                        cmd = ODBCDataAccsess.DbCon.CreateCommand()
                        cmd.CommandText = "SELECT public.InsertPlanTrn(?,?,?,?,?,?,?,?)"
                        cmd.CommandType = CommandType.StoredProcedure
                        cmd.Transaction = trans
                        cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text.Trim())
                        cmd.Parameters.AddWithValue("@plansno", OdbcType.Int).Value = CInt(i.ToString) 'CInt(lvwProductionPlan.Items(n).SubItems(csno).Text)
                        cmd.Parameters.AddWithValue("@proordid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(corderno).Text)
                        cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(citem).Text)
                        cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwProductionPlan.Items(n).SubItems(cUomKey).Text)
                        cmd.Parameters.AddWithValue("@proqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(corderqty).Text)
                        cmd.Parameters.AddWithValue("@planqty", OdbcType.Decimal).Value = CDec(lvwProductionPlan.Items(n).SubItems(cplanqty).Text)
                        cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
                        cmd.ExecuteScalar()
                    End If
                End If
            Next

            MsgBox("Plan Number Modified", MsgBoxStyle.Information, gCompanyShortName)
            Call InitializeControls()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deletePlanHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeletePlanHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@planid", OdbcType.Int).Value = CInt(txtPlanNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deletePlanTrn()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deletePlanTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@Planid", OdbcType.Int).Value = CInt(txtPlanNo.Text)
            cmd.ExecuteScalar()
            MsgBox("Production Plan No : " & txtPlanNo.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try

    End Sub





    Sub TxtOrderNoPreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs)
        If e.KeyCode = Keys.Tab And txtOrderNo.Text <> "" Then
            If CInt(txtOrderNo.Text) = 9999 Then
            Else
                If validateOrder() Then
                    populateOrderTrn(CInt(txtOrderNo.Text))
                End If
            End If
        End If
    End Sub

    Public Function validateOrder() As Boolean
        For n = 0 To lvwProductionPlan.Items.Count - 1
            If txtOrderNo.Text.Trim = lvwProductionPlan.Items(n).SubItems(corderno).Text.Trim Then
                MsgBox("Order Number Already Exists", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Next
        Return True

    End Function

    Sub populateOrderTrn(ByVal intOrderId As Integer)
        ds = getOrderTrn(intOrderId)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                i += 1
                lvw = lvwProductionPlan.Items.Add(i.ToString)
                With lvw
                    .SubItems.Add(txtOrderNo.Text.Trim)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    Else
                        .SubItems.Add("")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("pro_produced_qty")) Then
                        .SubItems.Add("0.000")
                    Else
                        .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_produced_qty").ToString)
                    End If
                    .SubItems.Add("0.000")
                    .SubItems.Add("")
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                End With
            Next
        Else
            MsgBox("Order Number not Found... Press 'F9' to Search", MsgBoxStyle.Information, gCompanyShortName)
        End If
        txtOrderNo.Text = ""
        txtOrderNo.Focus()
    End Sub


    Sub CmdSaveClick(sender As Object, e As EventArgs)
        Call savePlan()
    End Sub



    Sub populatePlanHdr(intPlanid As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            DtPlan.Text = ds.Tables(0).Rows(0).Item("plan_dt").ToString
            cmbMonth.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("plan_month").ToString)
        End If

    End Sub
    Sub populatePlanTrn(intPlanid As Integer)
        ds = getPlanTrn(intPlanid)
        If ds.Tables(0).Rows.Count > 0 Then
            intOrderID = 0
            i = 0
            intOrderID = CInt(ds.Tables(0).Rows(0).Item("pro_ord_id").ToString)
            For n = 0 To ds.Tables(0).Rows.Count - 1
                i += 1
                If intOrderID <> CInt(ds.Tables(0).Rows(n).Item("pro_ord_id").ToString) Then
                    Call populatePendingOrder(intOrderID)
                    intOrderID = CInt(ds.Tables(0).Rows(n).Item("pro_ord_id").ToString)
                End If
                lvw = lvwProductionPlan.Items.Add(i.ToString)
                With lvw
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_ord_id").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    Else
                        .SubItems.Add("")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("pro_produced_qty")) Then
                        .SubItems.Add("0")
                    Else
                        .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_produced_qty").ToString)
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("plan_qty").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("plan_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                    dblTotal = dblTotal + CDbl(ds.Tables(0).Rows(n).Item("plan_qty").ToString)
                End With

            Next
            txtTotalPlanQty.Text = Format(dblTotal, "#0.000")
        End If
    End Sub

    Sub populatePendingOrder(intOrderID As Integer)
        Dim ds2 As DataSet
        ds1 = getPendingOrder(intOrderID, CInt(txtPlanNo.Text))
        For n = 0 To ds1.Tables(0).Rows.Count - 1
            lvw = lvwProductionPlan.Items.Add(i.ToString)
            With lvw
                .SubItems.Add(intOrderID.ToString)
                .SubItems.Add(ds1.Tables(0).Rows(n).Item("item_id").ToString)
                ds2 = getItem(CInt(ds1.Tables(0).Rows(n).Item("item_id").ToString))
                If ds2.Tables(0).Rows.Count > 0 Then
                    .SubItems.Add(ds2.Tables(0).Rows(0).Item("item_description").ToString)
                Else
                    .SubItems.Add("")
                End If
                .SubItems.Add(ds1.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                .SubItems.Add(ds1.Tables(0).Rows(n).Item("pro_qty").ToString)
                If IsDBNull(ds1.Tables(0).Rows(n).Item("pro_produced_qty")) Then
                    .SubItems.Add("0.000")
                Else
                    .SubItems.Add(ds1.Tables(0).Rows(n).Item("pro_produced_qty").ToString)
                End If
                .SubItems.Add("0.000")
                .SubItems.Add("")
                .SubItems.Add(ds1.Tables(0).Rows(n).Item("uom_id").ToString)
            End With
            i += 1
        Next
    End Sub


    Sub LvwProductionPlanDoubleClick(sender As Object, e As EventArgs)
        Call populatePlanToEntry()
    End Sub

    Sub populatePlanToEntry()
        If Not lvwProductionPlan.SelectedItems Is Nothing Then
            editFlag = True
            txtOrderNo.Text = lvwProductionPlan.SelectedItems(0).SubItems(corderno).Text
            txtItemId.Text = lvwProductionPlan.SelectedItems(0).SubItems(citem).Text
            ds1 = getItem(CInt(txtItemId.Text))
            txtDescription.Text = ds1.Tables(0).Rows(0).Item("item_description").ToString
            cmbUom.Text = lvwProductionPlan.SelectedItems(0).SubItems(cuom).Text
            txtQty.Text = lvwProductionPlan.SelectedItems(0).SubItems(cplanqty).Text
        End If
    End Sub




    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        If editFlag = False Then
            addItem()
        Else
            updateItem()
        End If

    End Sub



    Private Sub cmbMonth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbMonth.SelectedIndexChanged
        Dim intYear As Integer
        If thisScreenMode = ScreenMode.Add Then
            If loadFlag = False Then
                intYear = Year(DtPlan.Value)
                ds1 = chkPlanHdr(intYear, CInt(cmbMonth.SelectedValue.ToString))
                If ds1.Tables(0).Rows.Count > 0 Then
                    MsgBox("Already Planned for Month " & cmbMonth.Text & " " & intYear.ToString & "  plan Id = " & ds1.Tables(0).Rows(0).Item("plan_id").ToString, MsgBoxStyle.Information, gCompanyShortName)
                    'txtPlanNo.Text = ds1.Tables(0).Rows(0).Item("plan_id").ToString
                    'thisScreenMode = ScreenMode.Edit
                    'EnableDisable(False)
                    'cmdEdit.Enabled = False
                    'cmdDelete.Enabled = False
                    txtPlanNo.Focus()
                    'SendKeys.Send("{ENTER}")
                End If
            End If
        End If
    End Sub

    Private Sub lvwProductionPlan_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwProductionPlan.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwProductionPlan.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want to Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        dblTotal = dblTotal - (CDbl(lvwProductionPlan.SelectedItems(0).SubItems(cplanqty).Text))
                        txtTotalPlanQty.Text = Format(dblTotal, "#0.000")
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwProductionPlan.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwProductionPlan.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwProductionPlan.Items.RemoveAt(lvwProductionPlan.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtItemId_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemId.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getItem()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemId.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtOrderNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtOrderNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getOrder()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtOrderNo.Text = rTagValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Order Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If

    End Sub

    Private Sub txtPlanNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPlanNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtPlanNo.Text <> "" Then
            ds = getPlanHdr(CInt(txtPlanNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populatePlanHdr(CInt(txtPlanNo.Text))
                Call populatePlanTrn(CInt(txtPlanNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Plan Number", MsgBoxStyle.Information, gCompanyShortName)
                txtPlanNo.Focus()
            End If

        End If

    End Sub

End Class
