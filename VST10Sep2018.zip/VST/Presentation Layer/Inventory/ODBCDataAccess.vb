﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:26
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Option Explicit On
Option Strict Off

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports VST
Imports VST.configuration
Imports VST.Constants

Public Class ODBCDataAccsess
	Public shared DbCon As New OdbcConnection
	Public shared strConString As String
	
	Public shared Sub DbConnection(byVal strConString As String)
		Try
            'strConString = "Driver={PostgreSQL ANSI};Server=192.168.136.1;Port=5432;Database=postgres;Uid=postgres;Pwd=ragu1234;"
            strConString = "Driver={PostgreSQL ANSI};Server=192.168.8.201;Port=5432;Database=postgres;Uid=postgres;Pwd=ragu1234;"
            'MsgBox(strConString, MsgBoxStyle.Information, gCompanyShortName)
            DbCon.ConnectionString = strConString
			DbCon.Open()
		Catch ex As Exception
			MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
			Exit Sub
		End Try
	End Sub
	
	Public shared Function GetDataSet(ByVal queryString As String, dbCon As OdbcConnection) As DataSet
		Dim cmd As New OdbcCommand
		Dim adapter As OdbcDataAdapter
		Dim ds As New DataSet
		Try  
        	adapter = New OdbcDataAdapter(queryString,DbCon)
        	adapter.Fill(ds)
        	Return ds
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
        End Try
    	Return ds
	End Function	
	
	Public shared Function GetDataTable(ByVal queryString As String,dbCon As OdbcConnection) As DataTable
		Dim cmd As New OdbcCommand
		Dim adapter As OdbcDataAdapter
		Dim ds As New DataSet
		Dim dt As New DataTable
		Try 
			adapter = New OdbcDataAdapter(queryString,DbCon)
			adapter.Fill(ds)
			dt = ds.Tables(0)
			Return dt
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
        End Try
	    Return dt
	End Function
	
	Public shared function getExecuteScalar(queryString As String, dbcon As OdbcConnection) As Object
		Try
			Dim cmd As New OdbcCommand(queryString, dbcon)
            Dim obj As New Object
            obj = cmd.ExecuteScalar()
            Return obj
        Catch ex As Exception
			MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try
	End Function

    Public Shared Function getExecuteQuery(queryString As String, dbcon As OdbcConnection) As Boolean
        Try
            Dim cmd As New OdbcCommand(queryString, dbcon)
            cmd.CommandText = queryString
            cmd.CommandType = CommandType.Text
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

End Class
