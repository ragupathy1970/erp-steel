﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 16:11
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.constants
Imports VST.Production

Public Partial Class Shipment
	Dim thisScreenMode As Integer
	Dim ds As DataSet
	Dim obj As Object
	Dim intShipmentID As Integer
	Dim intCustoerID As Integer
	Dim strSQL As String
	Dim trans As OdbcTransaction	
	Public Sub New()
		' The Me.InitializeComponent call is required for Windows Forms designer support.
		Me.InitializeComponent()
		
		'
		' TODO : Add constructor code after InitializeComponents
		'
	End Sub
	
	
	Public Sub InitializeControls()
		txtshipmentNo.Text = ""
		txtCustomerNo.Text = ""
		txtCustomerName.Text = ""
		lblCustName.Text = ""
		txtshipmentAdd1.Text = ""
		txtshipmentAdd2.Text = ""
		txtshipmentCity.Text = ""
		txtshipmentState.Text = ""
		txtShipmentPin.Text = ""
		txtContactPerson.Text = ""
		txtEmailId.Text = ""
		txtPhone.Text = ""
		chkIsActive.Checked = False
		EnableDisable(True)
	End Sub
	
	Public Sub EnableDisable(toggle As Boolean)
		txtShipmentNo.Enabled = Not toggle
		txtCustomerNo.Enabled = toggle
		txtCustomerName.Enabled = toggle
		txtshipmentAdd1.Enabled = toggle
		txtShipmentAdd2.Enabled = toggle
		txtShipmentCity.Enabled = toggle
		txtShipmentState.Enabled = toggle
		txtShipmentPin.Enabled = toggle
		txtContactPerson.Enabled = toggle
		txtEmailId.Enabled = toggle
		txtPhone.Enabled = toggle
		chkIsActive.Checked = toggle
	End Sub

    Sub CmdEditClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtShipmentNo.Focus()

    End Sub

    Sub CmdDeleteClick(sender As Object, e As EventArgs)
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtShipmentNo.Focus()
    End Sub

    Sub CmdSaveClick(sender As Object, e As EventArgs)
        Call saveShipment()
    End Sub

    Sub CmdCancelClick(sender As Object, e As EventArgs)
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub ShipmentLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Call InitializeControls()
        Call EnableDisable(True)
        thisScreenMode = ScreenMode.Add
    End Sub

    Public Sub saveShipment()
        Try
            If validateShipment() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "SELECT max(ship_id) AS ship_id FROM public.gen_Shipping"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        If IsDBNull(obj) Then
                            intShipmentID = 1
                        Else
                            intShipmentID = CInt(obj.ToString) + 1
                        End If
                        txtShipmentNo.Text = intShipmentID.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertShipment()
                        trans.Commit()
                        MsgBox("Shipment Id : " & txtShipmentNo.Text & " Created")
                    Case 2
                        Call UpdateShipment()
                        MsgBox("Shipment Modified", MsgBoxStyle.Information, gCompanyShortName)
                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Shipping Detail ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteShipment()
                            trans.Commit()
                            MsgBox("Shipment ID : " & txtShipmentNo.Text & " Deleted")
                        End If

                End Select
                Call InitializeControls()
                cmdEdit.Enabled = True
                cmdDelete.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub InsertShipment()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertShipping(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@ShipId", OdbcType.Int).Value = CInt(txtShipmentNo.Text)
            cmd.Parameters.AddWithValue("@custID", OdbcType.NText).Value = txtCustomerNo.Text.Trim
            cmd.Parameters.AddWithValue("@custName", OdbcType.NText).Value = txtCustomerName.Text.Trim
            cmd.Parameters.AddWithValue("@shipAdd1", OdbcType.NText).Value = txtShipmentAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@shipAdd2", OdbcType.NText).Value = txtShipmentAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@shipCity", OdbcType.NText).Value = txtShipmentCity.Text.Trim
            cmd.Parameters.AddWithValue("@shipState", OdbcType.NText).Value = txtShipmentState.Text.Trim
            cmd.Parameters.AddWithValue("@shipPin", OdbcType.NText).Value = txtShipmentPin.Text.Trim
            cmd.Parameters.AddWithValue("@shipCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@shipEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@shipPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub


    Sub UpdateShipment()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.UpdateShipping(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@shipId", OdbcType.Int).Value = CInt(txtShipmentNo.Text)
            cmd.Parameters.AddWithValue("@custId", OdbcType.Int).Value = CInt(txtCustomerNo.Text)
            cmd.Parameters.AddWithValue("@custName", OdbcType.NText).Value = txtCustomerName.Text.Trim
            cmd.Parameters.AddWithValue("@shipAdd1", OdbcType.NText).Value = txtShipmentAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@shipAdd2", OdbcType.NText).Value = txtShipmentAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@shipCity", OdbcType.NText).Value = txtShipmentCity.Text.Trim
            cmd.Parameters.AddWithValue("@shipState", OdbcType.NText).Value = txtShipmentState.Text.Trim
            cmd.Parameters.AddWithValue("@shipPin", OdbcType.NText).Value = txtShipmentPin.Text.Trim
            cmd.Parameters.AddWithValue("@shipCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@shipEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@shipPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteShipment()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteShipping(?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@shipid", OdbcType.Int).Value = CInt(txtShipmentNo.Text)
            cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = CInt(txtCustomerNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub populateShipment(intShipmentNo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            txtShipmentNo.Text = ds.Tables(0).Rows(0).Item("ship_id").ToString
            txtCustomerNo.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
            txtCustomerName.Text = ds.Tables(0).Rows(0).Item("cust_name").ToString
            txtShipmentAdd1.Text = ds.Tables(0).Rows(0).Item("ship_address1").ToString
            txtShipmentAdd2.Text = ds.Tables(0).Rows(0).Item("ship_address2").ToString
            txtShipmentCity.Text = ds.Tables(0).Rows(0).Item("ship_city").ToString
            txtShipmentState.Text = ds.Tables(0).Rows(0).Item("ship_state").ToString
            txtShipmentPin.Text = ds.Tables(0).Rows(0).Item("ship_pin").ToString
            txtContactPerson.Text = ds.Tables(0).Rows(0).Item("ship_contact_person").ToString
            txtEmailId.Text = ds.Tables(0).Rows(0).Item("ship_emailid").ToString
            txtPhone.Text = ds.Tables(0).Rows(0).Item("ship_phone").ToString
            If ds.Tables(0).Rows(0).Item("is_active").ToString = "1" Then
                chkIsActive.Checked = True
            Else
                chkIsActive.Checked = False
            End If
        End If
    End Sub

    Public Function validateShipment() As Boolean
        If thisScreenMode = 2 Or thisScreenMode = 3 Then
            If txtShipmentNo.Text = "" Then
                MsgBox("shipment Id is Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtShipmentNo.Focus()
                Return False
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        Else
            If txtCustomerNo.Text = "" Then
                MsgBox("Customer Id should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerNo.Focus()
                Return False
                Exit Function
            End If

            If txtCustomerName.Text = "" Then
                MsgBox("shipment Name Should Not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerName.Focus()
                Return False
                Exit Function
            End If
            If txtShipmentAdd1.Text = "" Then
                MsgBox("shipment Address should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If txtShipmentCity.Text = "" Then
                MsgBox("Shipment City Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If txtShipmentPin.Text = "" Then
                MsgBox("Shipment Pin Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        End If
        Return True
    End Function



    Sub ShipmentKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveShipment()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Sub TxtCustomerNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtCustomerNo.Text <> "" Then
            ds = getCustomer(CInt(txtCustomerNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateCustomer(CInt(txtCustomerNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Customer ID", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerNo.Focus()
            End If
        End If
    End Sub



    Public Sub populateCustomer(intCustomerNo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            txtCustomerNo.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
            txtCustomerName.Text = ds.Tables(0).Rows(0).Item("cust_name").ToString
            lblCustName.Text = ds.Tables(0).Rows(0).Item("cust_name").ToString
        End If
    End Sub


    Sub TxtCustomerNo_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtCustomerNo.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtCustomerNo.Text <> "" Then
            ds = getCustomer(CInt(txtCustomerNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateCustomer(CInt(txtCustomerNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Customer ID", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerNo.Focus()
            End If
        End If
    End Sub


    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtShipmentNo.Focus()
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtShipmentNo.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveShipment()
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub txtShipmentNo_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtShipmentNo.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtShipmentNo.Text <> "" Then
            ds = getShipment(CInt(txtShipmentNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateShipment(CInt(txtShipmentNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Shipment ID", MsgBoxStyle.Information, gCompanyShortName)
                txtShipmentNo.Focus()
            End If
        End If

    End Sub

    Private Sub txtShipmentNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtShipmentNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtShipmentNo.Text <> "" Then
            ds = getShipment(CInt(txtShipmentNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateShipment(CInt(txtShipmentNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Shipment ID", MsgBoxStyle.Information, gCompanyShortName)
                txtShipmentNo.Focus()
            End If
        End If
    End Sub

    Private Sub txtShipmentNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtShipmentNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getShipment()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtShipmentNo.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtCustomerNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerNo.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub
End Class
