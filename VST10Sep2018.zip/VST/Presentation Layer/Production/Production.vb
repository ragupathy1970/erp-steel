﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:17
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.Constants
Imports System.IO
Imports CrystalDecisions.Data
Imports CrystalDecisions.CrystalReports.Design
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Windows
Imports CrystalDecisions.Shared



Partial Public Class Production
    Inherits System.Windows.Forms.Form
    Dim rValue As String
    Dim rTagValue As String

    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
        Me.IsMdiContainer = False

    End Sub




    'Sub CmdPdfClick(sender As Object, e As EventArgs)
    '    'Call GenPDF()
    '    'System.Diagnostics.Process.Start("c:\printouts\test.pdf")
    '    Dim frmTestReport As New testReport
    '    frmTestReport.ShowDialog()


    'End Sub

    Private Sub cmdExcel_Click(sender As Object, e As EventArgs)

        Dim frmTestReport As New testReport
        frmTestReport.ShowDialog()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim frmTestReport As New testReport
        Dim frmTestEmail As New testEmail
        frmTestEmail.ShowDialog()
    End Sub

    Private Sub cmdOk_Click(sender As Object, e As EventArgs) Handles cmdOk.Click
        Dim frmSearch As New Search
        Dim sControl As New Windows.Forms.Control
        Dim ds As New DataSet
        Try
            rValue = ""
            rTagValue = ""
            ds = GetMainMenu(0)
            If ds.Tables(0).Rows.Count > 0 Then
                sControl.Text = ""
                sControl.Tag = ""
                Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                frmSearch.ShowDialog()

                If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                    rValue = sControl.Text
                    rTagValue = sControl.Tag.ToString
                    MsgBox(rTagValue.ToString + "," + rValue.ToString)
                End If
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
        End Try
    End Sub

    Private Sub cmdText_Click(sender As Object, e As EventArgs) Handles cmdText.Click
        MsgBox(NumberToWords(Val(txtAmount.Text)))
    End Sub

    Private Sub cmdPdf_Click(sender As Object, e As EventArgs) Handles cmdPdf.Click
        Call GenPDF()
        System.Diagnostics.Process.Start("c:\printouts\test.pdf")
        Dim frmTestReport As New testReport
        frmTestReport.ShowDialog()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) 

    End Sub
End Class
