﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:29
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Option Explicit On
Option Strict On

Imports System
Imports System.Configuration
Imports System.Data
Imports System.IO
Imports System.Text
Imports System.Math
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports iTextSharp.text
Imports iTextSharp.text.pdf
Imports VST.Constants
Imports Microsoft
Imports Microsoft.Office.Interop

Public Class Common
	
	'Public Shared f_cb As BaseFont = BaseFont.CreateFont(Directory.GetCurrentDirectory() + "\fonts\trebucbd.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED)
	Public shared f_cb As BaseFont = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED)
	'Public Shared f_cn As BaseFont = BaseFont.CreateFont(Directory.GetCurrentDirectory() + "\plantillas\fonts\trebuc.ttf", BaseFont.CP1252, BaseFont.NOT_EMBEDDED)
	Public Shared f_cn As BaseFont = BaseFont.CreateFont(BaseFont.HELVETICA, BaseFont.CP1252, BaseFont.NOT_EMBEDDED)


    'Public Sub New()

    'End Sub

    Public Shared Sub GenPDF()
        Try

            'Using fs As System.IO.FileStream = New FileStream("C:\Printouts\test.pdf", FileMode.Create)
            Dim sr As StreamReader
            Dim fs As FileStream
            fs = New FileStream("c:\printouts\test.pdf", FileMode.Create)
            Dim document As New Document(PageSize.A4, 25, 25, 30, 1)
            Dim writer As PdfWriter = PdfWriter.GetInstance(document, fs)
            document.AddTitle("test")
            document.Open()
            Dim cb As PdfContentByte = writer.DirectContent
            'Dim png As iTextSharp.text.Image = iTextSharp.text.Image.GetInstance(Directory.GetCurrentDirectory()+("Images/logo.jpg"))
            'png.ScaleAbsolute(75, 52)
            'png.SetAbsolutePosition(40, 770)
            'cb.AddImage(png)
            cb.BeginText()
            sr = New StreamReader("c:\printouts\test.txt")
            Dim ln As String
            Dim left_margin As Integer = 40
            Dim top_margin As Integer = 750
            Dim i As Integer
            'write(cb, "Vel Steel Tubes and Engineering Private Limited", left_margin, top_margin, f_cb, 10)
            'write(cb, "Pakkam Village and Post", left_margin, top_margin - 12, f_cn, 8)
            'write(cb, "Thiruninravur - Periyapalayam Road", left_margin, top_margin - 24, f_cn, 8)
            'write(cb, "Chennai - 602024", left_margin, top_margin - 36, f_cn, 10)
            'write(cb, "Tamilnadu", left_margin, top_margin - 48, f_cn, 10)
            'write(cb, Environment.NewLine, left_margin, top_margin - 60, f_cn, 10)
            write(cb, gCompanyName, left_margin, top_margin, f_cb, 10)
            write(cb, gCompanyAdd1, left_margin, top_margin - 12, f_cn, 8)
            write(cb, gcompanyAdd2, left_margin, top_margin - 24, f_cn, 8)
            write(cb, gcompanyCity, left_margin, top_margin - 36, f_cn, 10)
            write(cb, "Tamilnadu", left_margin, top_margin - 48, f_cn, 10)
            write(cb, Environment.NewLine, left_margin, top_margin - 60, f_cn, 10)
            Do While sr.Peek >= 0
                i = i + 12
                ln = sr.ReadLine()
                write(cb, ln, left_margin, top_margin - (60 + i), f_cn, 8)
            Loop
            cb.EndText()
            document.Close()
            sr.Close()
            writer.Close()
            fs.Close()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub
	
		Public Shared Sub write(ByVal cb As PdfContentByte, ByVal Text As String, ByVal X As Integer, ByVal Y As Integer, ByVal font As BaseFont, ByVal Size As Integer)
	        cb.SetFontAndSize(font, Size)
	        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, Text, X, Y, 0)
		End Sub
		
		Public Shared Function NumberToWords(number As Long) As String
        Try
            If number = 0 Then
                Return "zero"
            End If
            If number < 0 Then
                Return "minus " & NumberToWords(Math.Abs(number))
            End If
            Dim words As String = ""
            If (number \ 10000000) > 0 Then
                words += NumberToWords(number \ 10000000) & " Crore "
                number = number Mod 10000000
            End If
            If (number \ 100000) > 0 Then
                words += NumberToWords(number \ 100000) & " lakh "
                number = number Mod 100000
            End If
            If (number \ 1000) > 0 Then
                words += NumberToWords(number \ 1000) & " thousand "
                number = number Mod 1000
            End If
            If (number \ 100) > 0 Then
                words += NumberToWords(number \ 100) & " hundred "
                number = number Mod 100
            End If
            If number > 0 Then
                If words <> "" Then
                    words += "and "
                End If
                Dim unitsMap = New String() {"zero", "one", "two", "three", "four", "five",
                    "six", "seven", "eight", "nine", "ten", "eleven",
                    "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen",
                    "eighteen", "nineteen"}
                Dim tensMap = New String() {"zero", "ten", "twenty", "thirty", "forty", "fifty",
                    "sixty", "seventy", "eighty", "ninety"}
                If number < 20 Then
                    words += unitsMap(CInt(number))
                Else
                    words += tensMap(CInt(number) \ 10)
                    If (number Mod 10) > 0 Then
                        words += "-" & unitsMap(CInt(number) Mod 10)
                    End If
                End If
            End If
            Return words
        Catch ex As Exception
            MsgBox(ex.message, MsgBoxStyle.Critical,gCompanyShortName)
			Return ""
		End Try
	End Function

    Public Shared Function isNumber(number As Integer) As Boolean
        Try
            If Not (number >= 48 And number <= 57) And Not (number = 8) Then
                Return False
                Exit Function
            End If
            Return True
        Catch ex As exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Sub AllowInteger(ByVal strContet As String, ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Not System.Text.RegularExpressions.Regex.IsMatch(e.KeyChar, "[(0-9)(.)(\b)]") Then
            e.KeyChar = CChar("".ToString)
        End If
    End Sub

    Public Shared Function isAlpha(number As Integer) As Boolean
		Try
			If Not ((number >= 65 And number <= 90) Or (number>=97 And number<=122)) And Not (number = 8 Or number=32) Then
                Return False
                Exit Function
            End If
			Return True
		Catch ex As exception
			MsgBox(ex.Message, MsgBoxStyle.Information,gCompanyShortName)
			Return False
		End Try
	End Function

    Public Shared Function ExportToExcel(ByVal strFilename As String, ByVal dsDataSet As DataSet, ByVal strFileTitle As String, ByRef strErrorMessage As String) As Boolean
        strErrorMessage = String.Empty
        Dim bRetVal As Boolean = False
        Dim ds As DataSet = Nothing
        Try
            ds = dsDataSet

            Dim xlObject As Excel.Application = Nothing
            Dim xlWB As Excel.Workbook = Nothing
            Dim xlSh As Excel.Worksheet = Nothing
            Dim rg As Excel.Range = Nothing
            Try
                xlObject = New Excel.Application()
                xlObject.AlertBeforeOverwriting = False
                xlObject.DisplayAlerts = False

                ''This Adds a new woorkbook, you could open the workbook from file also
                xlWB = xlObject.Workbooks.Add(strFileTitle)
                xlWB.SaveAs(strFilename, 56, strFileTitle, strFileTitle, strFileTitle, strFileTitle,
                Excel.XlSaveAsAccessMode.xlNoChange, strFileTitle, strFileTitle, strFileTitle, strFileTitle)
                xlSh = DirectCast(xlObject.ActiveWorkbook.ActiveSheet, Excel.Worksheet)

                'Dim sUpperRange As String = "A1"
                'Dim sLastCol As String = "AQ"
                'Dim sLowerRange As String = sLastCol + (dsDataSet.Tables(0).Rows.Count + 1).ToString()

                For j = 0 To dsDataSet.Tables(0).Columns.Count - 1

                    xlSh.Cells(1, j + 1) = dsDataSet.Tables(0).Columns(j).ToString()

                Next

                For i = 1 To dsDataSet.Tables(0).Rows.Count
                    For j = 0 To dsDataSet.Tables(0).Columns.Count - 1
                        xlSh.Cells(i + 1, j + 1) = dsDataSet.Tables(0).Rows(i - 1)(j).ToString()
                    Next
                Next
                xlSh.Columns.AutoFit()


                If String.IsNullOrEmpty(strFileTitle) Then
                    xlObject.Caption = "untitled"
                Else
                    xlObject.Caption = strFileTitle
                End If

                xlWB.Save()
                bRetVal = True
            Catch ex As System.Runtime.InteropServices.COMException
                If ex.ErrorCode = -2147221164 Then
                    strErrorMessage = "Error in export: Please install Microsoft Office (Excel) to use the Export to Excel feature."
                ElseIf ex.ErrorCode = -2146827284 Then
                    strErrorMessage = "Error in export: Excel allows only 65,536 maximum rows in a sheet."
                Else
                    strErrorMessage = (("Error in export: " & ex.Message) + vbCrLf & " Error: " & ex.ErrorCode)
                End If
            Catch ex As Exception
                strErrorMessage = "Error in export: " & ex.Message
            Finally
                xlSh = Nothing
                xlWB = Nothing
                xlObject = Nothing
                ' force final cleanup!
                GC.Collect()
                GC.WaitForPendingFinalizers()
            End Try
        Catch ex As Exception
            strErrorMessage = "Error in export: " & ex.Message
        End Try

        Return bRetVal
    End Function

End Class

Class cListItem
	Private m_Text As String
	Private m_Value As Integer

	Public Sub New(ByVal Text As String, ByVal Value As Integer)
		Me.m_Text = Text
		Me.m_Value = Value
	End Sub

	Public Property Text() As String
		Get
			Return m_Text
		End Get
		Set(ByVal value As String)
			m_Text = value
		End Set
	End Property

	Public Property Value() As Integer
		Get
			Return m_Value
		End Get
		Set(ByVal value As Integer)
			m_Value = value
		End Set
	End Property
	
	

End Class

