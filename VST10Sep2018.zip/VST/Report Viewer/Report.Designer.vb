﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 26-02-2018
' Time: 14:01
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Report
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
		Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Report))
		Me.dlgPrintPriview = New System.Windows.Forms.PrintPreviewDialog()
		Me.CtrlPrintPreview = New System.Windows.Forms.PrintPreviewControl()
		Me.dlgPageSetup = New System.Windows.Forms.PageSetupDialog()
		Me.dlgPrint = New System.Windows.Forms.PrintDialog()
		Me.docPrint = New System.Drawing.Printing.PrintDocument()
		Me.cmdPrintPreview = New System.Windows.Forms.Button()
		Me.SuspendLayout
		'
		'dlgPrintPriview
		'
		Me.dlgPrintPriview.AutoScrollMargin = New System.Drawing.Size(0, 0)
		Me.dlgPrintPriview.AutoScrollMinSize = New System.Drawing.Size(0, 0)
		Me.dlgPrintPriview.ClientSize = New System.Drawing.Size(400, 300)
		Me.dlgPrintPriview.Enabled = true
		Me.dlgPrintPriview.Icon = CType(resources.GetObject("dlgPrintPriview.Icon"),System.Drawing.Icon)
		Me.dlgPrintPriview.Name = "dlgPrintPriview"
		Me.dlgPrintPriview.Visible = false
		'
		'CtrlPrintPreview
		'
		Me.CtrlPrintPreview.BackColor = System.Drawing.SystemColors.ButtonHighlight
		Me.CtrlPrintPreview.Document = Me.docPrint
		Me.CtrlPrintPreview.ForeColor = System.Drawing.Color.Transparent
		Me.CtrlPrintPreview.Location = New System.Drawing.Point(32, 26)
		Me.CtrlPrintPreview.Name = "CtrlPrintPreview"
		Me.CtrlPrintPreview.Size = New System.Drawing.Size(757, 418)
		Me.CtrlPrintPreview.TabIndex = 0
		Me.CtrlPrintPreview.Zoom = 0.37727272727272726R
		AddHandler Me.CtrlPrintPreview.Click, AddressOf Me.CtrlPrintPreviewClick
		'
		'dlgPrint
		'
		Me.dlgPrint.UseEXDialog = true
		'
		'cmdPrintPreview
		'
		Me.cmdPrintPreview.Location = New System.Drawing.Point(152, 443)
		Me.cmdPrintPreview.Name = "cmdPrintPreview"
		Me.cmdPrintPreview.Size = New System.Drawing.Size(92, 26)
		Me.cmdPrintPreview.TabIndex = 1
		Me.cmdPrintPreview.Text = "PrintPriview"
		Me.cmdPrintPreview.UseVisualStyleBackColor = true
		AddHandler Me.cmdPrintPreview.Click, AddressOf Me.Button1Click
		'
		'Report
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6!, 13!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(801, 465)
		Me.Controls.Add(Me.cmdPrintPreview)
		Me.Controls.Add(Me.CtrlPrintPreview)
		Me.Name = "Report"
		Me.Text = "Report"
		Me.ResumeLayout(false)
	End Sub
	Private cmdPrintPreview As System.Windows.Forms.Button
	Private docPrint As System.Drawing.Printing.PrintDocument
	Private dlgPrint As System.Windows.Forms.PrintDialog
	Private dlgPageSetup As System.Windows.Forms.PageSetupDialog
	Private CtrlPrintPreview As System.Windows.Forms.PrintPreviewControl
	Private dlgPrintPriview As System.Windows.Forms.PrintPreviewDialog
End Class
