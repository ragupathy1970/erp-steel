﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:31
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.IO
Imports VST.constants

Public Class Configuration
	Public strDbServer As  String
	Public strDbPort As String
	Public strDbName As String
	Public strDbUserId As String
	Public strDbPassWord As String
	Public strDbConString As String
	
	Public Function connectionString() As String
        Try
            strDbServer = ConfigurationManager.AppSettings.Get("DbServer")
            strDbPort = ConfigurationManager.AppSettings.Get("DbPort")
            strDbName = ConfigurationManager.AppSettings.Get("DbName")
            strDbUserId = ConfigurationManager.AppSettings.Get("UserId")
            strDbPassWord = ConfigurationManager.AppSettings.Get("Password")
            strDbConString = "Driver={PostgreSQL ANSI};Server=" + strDbServer + ";Port=" + strDbPort + ";Database=" + strDbName + ";Uid=" + strDbUserId + ";Pwd=" + strDbPassWord + ";"
            connectionString = strDbConString
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
			Return ""
		End Try
	End Function
	
	
End Class
