﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 16:10
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Vendor
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.grpVendor = New System.Windows.Forms.GroupBox()
        Me.txtVendorNo = New System.Windows.Forms.TextBox()
        Me.chkIsActive = New System.Windows.Forms.CheckBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.txtEmailId = New System.Windows.Forms.TextBox()
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtContactPerson = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.txtVendorGST = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtVendorPin = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.txtVendorState = New System.Windows.Forms.TextBox()
        Me.label4 = New System.Windows.Forms.Label()
        Me.txtVendorCity = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.txtVendorAdd2 = New System.Windows.Forms.TextBox()
        Me.txtVendorAdd1 = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.txtVendorName = New System.Windows.Forms.TextBox()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpVendor.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpVendor
        '
        Me.grpVendor.Controls.Add(Me.txtVendorNo)
        Me.grpVendor.Controls.Add(Me.chkIsActive)
        Me.grpVendor.Controls.Add(Me.txtPhone)
        Me.grpVendor.Controls.Add(Me.label10)
        Me.grpVendor.Controls.Add(Me.txtEmailId)
        Me.grpVendor.Controls.Add(Me.label9)
        Me.grpVendor.Controls.Add(Me.txtContactPerson)
        Me.grpVendor.Controls.Add(Me.label8)
        Me.grpVendor.Controls.Add(Me.txtVendorGST)
        Me.grpVendor.Controls.Add(Me.label7)
        Me.grpVendor.Controls.Add(Me.txtVendorPin)
        Me.grpVendor.Controls.Add(Me.label6)
        Me.grpVendor.Controls.Add(Me.txtVendorState)
        Me.grpVendor.Controls.Add(Me.label4)
        Me.grpVendor.Controls.Add(Me.txtVendorCity)
        Me.grpVendor.Controls.Add(Me.label5)
        Me.grpVendor.Controls.Add(Me.txtVendorAdd2)
        Me.grpVendor.Controls.Add(Me.txtVendorAdd1)
        Me.grpVendor.Controls.Add(Me.label3)
        Me.grpVendor.Controls.Add(Me.txtVendorName)
        Me.grpVendor.Controls.Add(Me.label2)
        Me.grpVendor.Controls.Add(Me.label1)
        Me.grpVendor.Location = New System.Drawing.Point(22, 21)
        Me.grpVendor.Margin = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.grpVendor.Name = "grpVendor"
        Me.grpVendor.Padding = New System.Windows.Forms.Padding(3, 5, 3, 5)
        Me.grpVendor.Size = New System.Drawing.Size(506, 396)
        Me.grpVendor.TabIndex = 17
        Me.grpVendor.TabStop = False
        '
        'txtVendorNo
        '
        Me.txtVendorNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorNo.Location = New System.Drawing.Point(106, 22)
        Me.txtVendorNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorNo.Name = "txtVendorNo"
        Me.txtVendorNo.Size = New System.Drawing.Size(87, 22)
        Me.txtVendorNo.TabIndex = 26
        '
        'chkIsActive
        '
        Me.chkIsActive.Location = New System.Drawing.Point(105, 366)
        Me.chkIsActive.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.chkIsActive.Name = "chkIsActive"
        Me.chkIsActive.Size = New System.Drawing.Size(87, 21)
        Me.chkIsActive.TabIndex = 12
        Me.chkIsActive.Text = "Is Active"
        Me.chkIsActive.UseVisualStyleBackColor = True
        '
        'txtPhone
        '
        Me.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPhone.Location = New System.Drawing.Point(105, 337)
        Me.txtPhone.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(219, 22)
        Me.txtPhone.TabIndex = 11
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(48, 339)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(51, 23)
        Me.label10.TabIndex = 25
        Me.label10.Text = "Phone"
        '
        'txtEmailId
        '
        Me.txtEmailId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmailId.Location = New System.Drawing.Point(105, 305)
        Me.txtEmailId.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmailId.Name = "txtEmailId"
        Me.txtEmailId.Size = New System.Drawing.Size(219, 22)
        Me.txtEmailId.TabIndex = 10
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(38, 307)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(63, 23)
        Me.label9.TabIndex = 23
        Me.label9.Text = "Email ID"
        '
        'txtContactPerson
        '
        Me.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContactPerson.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactPerson.Location = New System.Drawing.Point(105, 274)
        Me.txtContactPerson.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtContactPerson.Name = "txtContactPerson"
        Me.txtContactPerson.Size = New System.Drawing.Size(219, 22)
        Me.txtContactPerson.TabIndex = 9
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(3, 276)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(100, 20)
        Me.label8.TabIndex = 21
        Me.label8.Text = "Contact Person"
        '
        'txtVendorGST
        '
        Me.txtVendorGST.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorGST.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorGST.Location = New System.Drawing.Point(105, 242)
        Me.txtVendorGST.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorGST.MaxLength = 15
        Me.txtVendorGST.Name = "txtVendorGST"
        Me.txtVendorGST.Size = New System.Drawing.Size(128, 22)
        Me.txtVendorGST.TabIndex = 8
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(64, 246)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(45, 23)
        Me.label7.TabIndex = 19
        Me.label7.Text = "GST"
        '
        'txtVendorPin
        '
        Me.txtVendorPin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorPin.Location = New System.Drawing.Point(105, 210)
        Me.txtVendorPin.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorPin.MaxLength = 15
        Me.txtVendorPin.Name = "txtVendorPin"
        Me.txtVendorPin.Size = New System.Drawing.Size(128, 22)
        Me.txtVendorPin.TabIndex = 7
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(70, 214)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(34, 23)
        Me.label6.TabIndex = 17
        Me.label6.Text = "Pin"
        '
        'txtVendorState
        '
        Me.txtVendorState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorState.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorState.Location = New System.Drawing.Point(105, 178)
        Me.txtVendorState.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorState.Name = "txtVendorState"
        Me.txtVendorState.Size = New System.Drawing.Size(219, 22)
        Me.txtVendorState.TabIndex = 6
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(60, 182)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(48, 23)
        Me.label4.TabIndex = 15
        Me.label4.Text = "State"
        '
        'txtVendorCity
        '
        Me.txtVendorCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorCity.Location = New System.Drawing.Point(105, 146)
        Me.txtVendorCity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorCity.Name = "txtVendorCity"
        Me.txtVendorCity.Size = New System.Drawing.Size(219, 22)
        Me.txtVendorCity.TabIndex = 5
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(65, 150)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(36, 23)
        Me.label5.TabIndex = 13
        Me.label5.Text = "City"
        '
        'txtVendorAdd2
        '
        Me.txtVendorAdd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorAdd2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorAdd2.Location = New System.Drawing.Point(105, 114)
        Me.txtVendorAdd2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorAdd2.Name = "txtVendorAdd2"
        Me.txtVendorAdd2.Size = New System.Drawing.Size(370, 22)
        Me.txtVendorAdd2.TabIndex = 4
        '
        'txtVendorAdd1
        '
        Me.txtVendorAdd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorAdd1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorAdd1.Location = New System.Drawing.Point(105, 83)
        Me.txtVendorAdd1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorAdd1.Name = "txtVendorAdd1"
        Me.txtVendorAdd1.Size = New System.Drawing.Size(370, 22)
        Me.txtVendorAdd1.TabIndex = 3
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(42, 80)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(68, 23)
        Me.label3.TabIndex = 9
        Me.label3.Text = "Address"
        '
        'txtVendorName
        '
        Me.txtVendorName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendorName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVendorName.Location = New System.Drawing.Point(105, 51)
        Me.txtVendorName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtVendorName.Name = "txtVendorName"
        Me.txtVendorName.Size = New System.Drawing.Size(370, 22)
        Me.txtVendorName.TabIndex = 2
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(54, 51)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(52, 23)
        Me.label2.TabIndex = 7
        Me.label2.Text = "Name" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(34, 23)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(68, 23)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Vendor ID"
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(249, 427)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 23
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(438, 427)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 25
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(345, 427)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 24
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(153, 426)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 22
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'Vendor
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(544, 470)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpVendor)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Vendor"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Vendor"
        Me.grpVendor.ResumeLayout(False)
        Me.grpVendor.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private grpVendor As System.Windows.Forms.GroupBox
	Private txtVendorGST As System.Windows.Forms.TextBox
	Private txtVendorPin As System.Windows.Forms.TextBox
	Private txtVendorState As System.Windows.Forms.TextBox
	Private txtVendorCity As System.Windows.Forms.TextBox
	Private txtVendorAdd2 As System.Windows.Forms.TextBox
	Private txtVendorAdd1 As System.Windows.Forms.TextBox
	Private txtVendorName As System.Windows.Forms.TextBox
    Private label1 As System.Windows.Forms.Label
    Private label2 As System.Windows.Forms.Label
    Private label3 As System.Windows.Forms.Label
    Private label5 As System.Windows.Forms.Label
    Private label4 As System.Windows.Forms.Label
    Private label6 As System.Windows.Forms.Label
    Private label7 As System.Windows.Forms.Label
    Private label8 As System.Windows.Forms.Label
    Private txtContactPerson As System.Windows.Forms.TextBox
    Private label9 As System.Windows.Forms.Label
    Private txtEmailId As System.Windows.Forms.TextBox
    Private label10 As System.Windows.Forms.Label
    Private txtPhone As System.Windows.Forms.TextBox
    Private chkIsActive As System.Windows.Forms.CheckBox
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents txtVendorNo As System.Windows.Forms.TextBox
End Class
