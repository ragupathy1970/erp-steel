﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 07-02-2018
' Time: 15:31
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Order
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.grpEntry = New System.Windows.Forms.GroupBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.cmdAddItem = New System.Windows.Forms.Button()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtItemID = New System.Windows.Forms.TextBox()
        Me.grpLvwOrder = New System.Windows.Forms.GroupBox()
        Me.txtTotalVal = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtRoundOff = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtIGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtSGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtCGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTaxable = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtNetTotal = New System.Windows.Forms.TextBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.lvwOrder = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colRate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMtns = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNos = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMtrs = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colIGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.grpHeader = New System.Windows.Forms.GroupBox()
        Me.txtOrderNo = New System.Windows.Forms.TextBox()
        Me.lbldcity = New System.Windows.Forms.Label()
        Me.lbldadd2 = New System.Windows.Forms.Label()
        Me.lbldadd1 = New System.Windows.Forms.Label()
        Me.lbldName = New System.Windows.Forms.Label()
        Me.lblcity = New System.Windows.Forms.Label()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lbladd1 = New System.Windows.Forms.Label()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.chkDeliverySame = New System.Windows.Forms.CheckBox()
        Me.chkIsJobwork = New System.Windows.Forms.CheckBox()
        Me.label12 = New System.Windows.Forms.Label()
        Me.cmbisi = New System.Windows.Forms.ComboBox()
        Me.txtDeliveryId = New System.Windows.Forms.TextBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.DeliveryDt = New System.Windows.Forms.DateTimePicker()
        Me.label7 = New System.Windows.Forms.Label()
        Me.label10 = New System.Windows.Forms.Label()
        Me.txtCustomerId = New System.Windows.Forms.TextBox()
        Me.CustomerOrderDt = New System.Windows.Forms.DateTimePicker()
        Me.label9 = New System.Windows.Forms.Label()
        Me.txtCustomerOrderNo = New System.Windows.Forms.TextBox()
        Me.label3 = New System.Windows.Forms.Label()
        Me.OrderDt = New System.Windows.Forms.DateTimePicker()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.grpEntry.SuspendLayout()
        Me.grpLvwOrder.SuspendLayout()
        Me.grpHeader.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(542, 505)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 20
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(731, 505)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 19
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(638, 505)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 18
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(446, 504)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 17
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'grpEntry
        '
        Me.grpEntry.Controls.Add(Me.label13)
        Me.grpEntry.Controls.Add(Me.txtRate)
        Me.grpEntry.Controls.Add(Me.cmbUom)
        Me.grpEntry.Controls.Add(Me.label8)
        Me.grpEntry.Controls.Add(Me.label6)
        Me.grpEntry.Controls.Add(Me.label5)
        Me.grpEntry.Controls.Add(Me.label4)
        Me.grpEntry.Controls.Add(Me.cmdAdd)
        Me.grpEntry.Controls.Add(Me.txtQty)
        Me.grpEntry.Controls.Add(Me.cmdAddItem)
        Me.grpEntry.Controls.Add(Me.txtDescription)
        Me.grpEntry.Controls.Add(Me.txtItemID)
        Me.grpEntry.Location = New System.Drawing.Point(33, 186)
        Me.grpEntry.Name = "grpEntry"
        Me.grpEntry.Size = New System.Drawing.Size(783, 52)
        Me.grpEntry.TabIndex = 23
        Me.grpEntry.TabStop = False
        '
        'label13
        '
        Me.label13.BackColor = System.Drawing.Color.Transparent
        Me.label13.Location = New System.Drawing.Point(602, 7)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(55, 15)
        Me.label13.TabIndex = 15
        Me.label13.Text = "Rate"
        '
        'txtRate
        '
        Me.txtRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRate.Location = New System.Drawing.Point(604, 23)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(74, 22)
        Me.txtRate.TabIndex = 13
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Items.AddRange(New Object() {"January", "February", "March", "Apirl", "May", "Jun", "July", "Auguest", "September", "October", "November", "December"})
        Me.cmbUom.Location = New System.Drawing.Point(479, 21)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(59, 24)
        Me.cmbUom.TabIndex = 11
        '
        'label8
        '
        Me.label8.BackColor = System.Drawing.Color.Transparent
        Me.label8.Location = New System.Drawing.Point(476, 6)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(42, 15)
        Me.label8.TabIndex = 12
        Me.label8.Text = "UOM"
        '
        'label6
        '
        Me.label6.BackColor = System.Drawing.Color.Transparent
        Me.label6.Location = New System.Drawing.Point(539, 7)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(59, 15)
        Me.label6.TabIndex = 8
        Me.label6.Text = "Quantity"
        '
        'label5
        '
        Me.label5.BackColor = System.Drawing.Color.Transparent
        Me.label5.Location = New System.Drawing.Point(120, 5)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(77, 15)
        Me.label5.TabIndex = 7
        Me.label5.Text = "Description"
        '
        'label4
        '
        Me.label4.BackColor = System.Drawing.Color.Transparent
        Me.label4.Location = New System.Drawing.Point(14, 3)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(72, 15)
        Me.label4.TabIndex = 6
        Me.label4.Text = "Item"
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(687, 15)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 14
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(543, 22)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(55, 22)
        Me.txtQty.TabIndex = 12
        '
        'cmdAddItem
        '
        Me.cmdAddItem.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddItem.Location = New System.Drawing.Point(93, 21)
        Me.cmdAddItem.Name = "cmdAddItem"
        Me.cmdAddItem.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddItem.TabIndex = 2
        Me.cmdAddItem.Text = "+"
        Me.cmdAddItem.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(123, 21)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(350, 22)
        Me.txtDescription.TabIndex = 1
        '
        'txtItemID
        '
        Me.txtItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemID.Location = New System.Drawing.Point(15, 21)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.Size = New System.Drawing.Size(75, 22)
        Me.txtItemID.TabIndex = 10
        '
        'grpLvwOrder
        '
        Me.grpLvwOrder.Controls.Add(Me.txtTotalVal)
        Me.grpLvwOrder.Controls.Add(Me.Label20)
        Me.grpLvwOrder.Controls.Add(Me.txtRoundOff)
        Me.grpLvwOrder.Controls.Add(Me.Label19)
        Me.grpLvwOrder.Controls.Add(Me.txtIGSTTotal)
        Me.grpLvwOrder.Controls.Add(Me.Label18)
        Me.grpLvwOrder.Controls.Add(Me.txtSGSTTotal)
        Me.grpLvwOrder.Controls.Add(Me.Label17)
        Me.grpLvwOrder.Controls.Add(Me.txtCGSTTotal)
        Me.grpLvwOrder.Controls.Add(Me.Label16)
        Me.grpLvwOrder.Controls.Add(Me.txtTaxable)
        Me.grpLvwOrder.Controls.Add(Me.Label15)
        Me.grpLvwOrder.Controls.Add(Me.txtNetTotal)
        Me.grpLvwOrder.Controls.Add(Me.label14)
        Me.grpLvwOrder.Controls.Add(Me.lvwOrder)
        Me.grpLvwOrder.Location = New System.Drawing.Point(33, 233)
        Me.grpLvwOrder.Name = "grpLvwOrder"
        Me.grpLvwOrder.Size = New System.Drawing.Size(783, 256)
        Me.grpLvwOrder.TabIndex = 21
        Me.grpLvwOrder.TabStop = False
        '
        'txtTotalVal
        '
        Me.txtTotalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalVal.Enabled = False
        Me.txtTotalVal.Location = New System.Drawing.Point(481, 191)
        Me.txtTotalVal.Name = "txtTotalVal"
        Me.txtTotalVal.Size = New System.Drawing.Size(87, 22)
        Me.txtTotalVal.TabIndex = 17
        Me.txtTotalVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(418, 187)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(69, 33)
        Me.Label20.TabIndex = 16
        Me.Label20.Text = "Total Value"
        '
        'txtRoundOff
        '
        Me.txtRoundOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoundOff.Enabled = False
        Me.txtRoundOff.ForeColor = System.Drawing.Color.Red
        Me.txtRoundOff.Location = New System.Drawing.Point(657, 191)
        Me.txtRoundOff.Name = "txtRoundOff"
        Me.txtRoundOff.Size = New System.Drawing.Size(87, 22)
        Me.txtRoundOff.TabIndex = 15
        Me.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(590, 191)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 19)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Round Off"
        '
        'txtIGSTTotal
        '
        Me.txtIGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIGSTTotal.Enabled = False
        Me.txtIGSTTotal.Location = New System.Drawing.Point(324, 219)
        Me.txtIGSTTotal.Name = "txtIGSTTotal"
        Me.txtIGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtIGSTTotal.TabIndex = 13
        Me.txtIGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(256, 220)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 19)
        Me.Label18.TabIndex = 12
        Me.Label18.Text = "IGST Total"
        '
        'txtSGSTTotal
        '
        Me.txtSGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSGSTTotal.Enabled = False
        Me.txtSGSTTotal.Location = New System.Drawing.Point(325, 190)
        Me.txtSGSTTotal.Name = "txtSGSTTotal"
        Me.txtSGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtSGSTTotal.TabIndex = 11
        Me.txtSGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(250, 189)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(81, 19)
        Me.Label17.TabIndex = 10
        Me.Label17.Text = "SGST Total"
        '
        'txtCGSTTotal
        '
        Me.txtCGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCGSTTotal.Enabled = False
        Me.txtCGSTTotal.Location = New System.Drawing.Point(325, 161)
        Me.txtCGSTTotal.Name = "txtCGSTTotal"
        Me.txtCGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtCGSTTotal.TabIndex = 9
        Me.txtCGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(248, 162)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 19)
        Me.Label16.TabIndex = 8
        Me.Label16.Text = "CGST Total"
        '
        'txtTaxable
        '
        Me.txtTaxable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTaxable.Enabled = False
        Me.txtTaxable.Location = New System.Drawing.Point(658, 162)
        Me.txtTaxable.Name = "txtTaxable"
        Me.txtTaxable.Size = New System.Drawing.Size(87, 22)
        Me.txtTaxable.TabIndex = 7
        Me.txtTaxable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(600, 163)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(69, 19)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Taxable "
        '
        'txtNetTotal
        '
        Me.txtNetTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNetTotal.Enabled = False
        Me.txtNetTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNetTotal.Location = New System.Drawing.Point(657, 221)
        Me.txtNetTotal.Name = "txtNetTotal"
        Me.txtNetTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtNetTotal.TabIndex = 5
        Me.txtNetTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(593, 221)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(77, 19)
        Me.label14.TabIndex = 4
        Me.label14.Text = "Net Total"
        '
        'lvwOrder
        '
        Me.lvwOrder.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwOrder.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwOrder.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colItemid, Me.colDescription, Me.colUom, Me.colQty, Me.colRate, Me.colValue, Me.colMtns, Me.colNos, Me.colMtrs, Me.colCGST, Me.colSGST, Me.colIGST, Me.colSlnoKey, Me.colUomKey})
        Me.lvwOrder.FullRowSelect = True
        Me.lvwOrder.GridLines = True
        Me.lvwOrder.Location = New System.Drawing.Point(19, 20)
        Me.lvwOrder.MultiSelect = False
        Me.lvwOrder.Name = "lvwOrder"
        Me.lvwOrder.Size = New System.Drawing.Size(743, 132)
        Me.lvwOrder.TabIndex = 0
        Me.lvwOrder.UseCompatibleStateImageBehavior = False
        Me.lvwOrder.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 41
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 75
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colRate
        '
        Me.colRate.Text = "Rate"
        Me.colRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colRate.Width = 70
        '
        'colValue
        '
        Me.colValue.Text = "Value"
        Me.colValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colValue.Width = 100
        '
        'colMtns
        '
        Me.colMtns.Text = "MT"
        Me.colMtns.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colMtns.Width = 50
        '
        'colNos
        '
        Me.colNos.Text = "Nos"
        Me.colNos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colMtrs
        '
        Me.colMtrs.Text = "Mtrs"
        '
        'colCGST
        '
        Me.colCGST.DisplayIndex = 12
        Me.colCGST.Text = "CGST"
        Me.colCGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSGST
        '
        Me.colSGST.DisplayIndex = 13
        Me.colSGST.Text = "SGST"
        Me.colSGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colIGST
        '
        Me.colIGST.DisplayIndex = 14
        Me.colIGST.Text = "IGST"
        Me.colIGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSlnoKey
        '
        Me.colSlnoKey.DisplayIndex = 10
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.DisplayIndex = 11
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 0
        '
        'grpHeader
        '
        Me.grpHeader.Controls.Add(Me.txtOrderNo)
        Me.grpHeader.Controls.Add(Me.lbldcity)
        Me.grpHeader.Controls.Add(Me.lbldadd2)
        Me.grpHeader.Controls.Add(Me.lbldadd1)
        Me.grpHeader.Controls.Add(Me.lbldName)
        Me.grpHeader.Controls.Add(Me.lblcity)
        Me.grpHeader.Controls.Add(Me.lbladd2)
        Me.grpHeader.Controls.Add(Me.lbladd1)
        Me.grpHeader.Controls.Add(Me.lblCustName)
        Me.grpHeader.Controls.Add(Me.chkDeliverySame)
        Me.grpHeader.Controls.Add(Me.chkIsJobwork)
        Me.grpHeader.Controls.Add(Me.label12)
        Me.grpHeader.Controls.Add(Me.cmbisi)
        Me.grpHeader.Controls.Add(Me.txtDeliveryId)
        Me.grpHeader.Controls.Add(Me.label11)
        Me.grpHeader.Controls.Add(Me.DeliveryDt)
        Me.grpHeader.Controls.Add(Me.label7)
        Me.grpHeader.Controls.Add(Me.label10)
        Me.grpHeader.Controls.Add(Me.txtCustomerId)
        Me.grpHeader.Controls.Add(Me.CustomerOrderDt)
        Me.grpHeader.Controls.Add(Me.label9)
        Me.grpHeader.Controls.Add(Me.txtCustomerOrderNo)
        Me.grpHeader.Controls.Add(Me.label3)
        Me.grpHeader.Controls.Add(Me.OrderDt)
        Me.grpHeader.Controls.Add(Me.label2)
        Me.grpHeader.Controls.Add(Me.label1)
        Me.grpHeader.Location = New System.Drawing.Point(33, 15)
        Me.grpHeader.Name = "grpHeader"
        Me.grpHeader.Size = New System.Drawing.Size(783, 164)
        Me.grpHeader.TabIndex = 22
        Me.grpHeader.TabStop = False
        '
        'txtOrderNo
        '
        Me.txtOrderNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOrderNo.Location = New System.Drawing.Point(80, 27)
        Me.txtOrderNo.Name = "txtOrderNo"
        Me.txtOrderNo.Size = New System.Drawing.Size(87, 22)
        Me.txtOrderNo.TabIndex = 25
        '
        'lbldcity
        '
        Me.lbldcity.Location = New System.Drawing.Point(541, 141)
        Me.lbldcity.Name = "lbldcity"
        Me.lbldcity.Size = New System.Drawing.Size(227, 15)
        Me.lbldcity.TabIndex = 24
        '
        'lbldadd2
        '
        Me.lbldadd2.Location = New System.Drawing.Point(541, 124)
        Me.lbldadd2.Name = "lbldadd2"
        Me.lbldadd2.Size = New System.Drawing.Size(227, 15)
        Me.lbldadd2.TabIndex = 23
        '
        'lbldadd1
        '
        Me.lbldadd1.Location = New System.Drawing.Point(541, 106)
        Me.lbldadd1.Name = "lbldadd1"
        Me.lbldadd1.Size = New System.Drawing.Size(227, 15)
        Me.lbldadd1.TabIndex = 22
        '
        'lbldName
        '
        Me.lbldName.Location = New System.Drawing.Point(541, 90)
        Me.lbldName.Name = "lbldName"
        Me.lbldName.Size = New System.Drawing.Size(227, 15)
        Me.lbldName.TabIndex = 21
        '
        'lblcity
        '
        Me.lblcity.Location = New System.Drawing.Point(541, 69)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(227, 15)
        Me.lblcity.TabIndex = 20
        '
        'lbladd2
        '
        Me.lbladd2.Location = New System.Drawing.Point(541, 52)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(227, 15)
        Me.lbladd2.TabIndex = 19
        '
        'lbladd1
        '
        Me.lbladd1.Location = New System.Drawing.Point(541, 34)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(227, 15)
        Me.lbladd1.TabIndex = 18
        '
        'lblCustName
        '
        Me.lblCustName.Location = New System.Drawing.Point(541, 18)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(227, 15)
        Me.lblCustName.TabIndex = 17
        '
        'chkDeliverySame
        '
        Me.chkDeliverySame.BackColor = System.Drawing.Color.Transparent
        Me.chkDeliverySame.Location = New System.Drawing.Point(208, 117)
        Me.chkDeliverySame.Name = "chkDeliverySame"
        Me.chkDeliverySame.Size = New System.Drawing.Size(203, 28)
        Me.chkDeliverySame.TabIndex = 8
        Me.chkDeliverySame.Text = "Shipping at different Address"
        Me.chkDeliverySame.UseVisualStyleBackColor = False
        '
        'chkIsJobwork
        '
        Me.chkIsJobwork.Location = New System.Drawing.Point(208, 94)
        Me.chkIsJobwork.Name = "chkIsJobwork"
        Me.chkIsJobwork.Size = New System.Drawing.Size(74, 20)
        Me.chkIsJobwork.TabIndex = 7
        Me.chkIsJobwork.Text = "Jobwork"
        Me.chkIsJobwork.UseVisualStyleBackColor = True
        '
        'label12
        '
        Me.label12.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.Location = New System.Drawing.Point(16, 94)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(62, 20)
        Me.label12.TabIndex = 16
        Me.label12.Text = "ISI Type"
        '
        'cmbisi
        '
        Me.cmbisi.FormattingEnabled = True
        Me.cmbisi.Location = New System.Drawing.Point(79, 93)
        Me.cmbisi.Name = "cmbisi"
        Me.cmbisi.Size = New System.Drawing.Size(84, 24)
        Me.cmbisi.TabIndex = 6
        '
        'txtDeliveryId
        '
        Me.txtDeliveryId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDeliveryId.Location = New System.Drawing.Point(446, 97)
        Me.txtDeliveryId.Name = "txtDeliveryId"
        Me.txtDeliveryId.Size = New System.Drawing.Size(67, 22)
        Me.txtDeliveryId.TabIndex = 9
        '
        'label11
        '
        Me.label11.Location = New System.Drawing.Point(370, 99)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(78, 22)
        Me.label11.TabIndex = 13
        Me.label11.Text = "Shipping ID"
        '
        'DeliveryDt
        '
        Me.DeliveryDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.DeliveryDt.CustomFormat = "dd-MMM-yyyy"
        Me.DeliveryDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.DeliveryDt.Location = New System.Drawing.Point(441, 55)
        Me.DeliveryDt.Name = "DeliveryDt"
        Me.DeliveryDt.Size = New System.Drawing.Size(99, 22)
        Me.DeliveryDt.TabIndex = 5
        Me.DeliveryDt.Value = New Date(2018, 2, 8, 0, 0, 0, 0)
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(373, 49)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(69, 32)
        Me.label7.TabIndex = 11
        Me.label7.Text = "Delivery Date"
        '
        'label10
        '
        Me.label10.BackColor = System.Drawing.Color.Transparent
        Me.label10.Location = New System.Drawing.Point(366, 21)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(82, 22)
        Me.label10.TabIndex = 10
        Me.label10.Text = "Customer ID"
        '
        'txtCustomerId
        '
        Me.txtCustomerId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerId.Location = New System.Drawing.Point(446, 21)
        Me.txtCustomerId.Name = "txtCustomerId"
        Me.txtCustomerId.Size = New System.Drawing.Size(67, 22)
        Me.txtCustomerId.TabIndex = 2
        '
        'CustomerOrderDt
        '
        Me.CustomerOrderDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.CustomerOrderDt.CustomFormat = "dd-MMM-yyyy"
        Me.CustomerOrderDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.CustomerOrderDt.Location = New System.Drawing.Point(265, 56)
        Me.CustomerOrderDt.Name = "CustomerOrderDt"
        Me.CustomerOrderDt.Size = New System.Drawing.Size(99, 22)
        Me.CustomerOrderDt.TabIndex = 4
        Me.CustomerOrderDt.Value = New Date(2018, 2, 8, 0, 0, 0, 0)
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(193, 50)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(71, 36)
        Me.label9.TabIndex = 7
        Me.label9.Text = "Customer Order Date"
        '
        'txtCustomerOrderNo
        '
        Me.txtCustomerOrderNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerOrderNo.Location = New System.Drawing.Point(80, 56)
        Me.txtCustomerOrderNo.Name = "txtCustomerOrderNo"
        Me.txtCustomerOrderNo.Size = New System.Drawing.Size(87, 22)
        Me.txtCustomerOrderNo.TabIndex = 3
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(17, 50)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(69, 34)
        Me.label3.TabIndex = 5
        Me.label3.Text = "Customer Order No"
        '
        'OrderDt
        '
        Me.OrderDt.Cursor = System.Windows.Forms.Cursors.Default
        Me.OrderDt.CustomFormat = "dd-MMM-yyyy"
        Me.OrderDt.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.OrderDt.Location = New System.Drawing.Point(265, 22)
        Me.OrderDt.Name = "OrderDt"
        Me.OrderDt.Size = New System.Drawing.Size(99, 22)
        Me.OrderDt.TabIndex = 1
        Me.OrderDt.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(187, 25)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(77, 19)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Order Date"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(24, 29)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(69, 19)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Order ID"
        '
        'Order
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(848, 540)
        Me.Controls.Add(Me.grpEntry)
        Me.Controls.Add(Me.grpLvwOrder)
        Me.Controls.Add(Me.grpHeader)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Order"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Entry"
        Me.grpEntry.ResumeLayout(False)
        Me.grpEntry.PerformLayout()
        Me.grpLvwOrder.ResumeLayout(False)
        Me.grpLvwOrder.PerformLayout()
        Me.grpHeader.ResumeLayout(False)
        Me.grpHeader.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents label1 As System.Windows.Forms.Label
    Private WithEvents label2 As System.Windows.Forms.Label
    Private WithEvents OrderDt As System.Windows.Forms.DateTimePicker
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents txtCustomerOrderNo As System.Windows.Forms.TextBox
    Private WithEvents label9 As System.Windows.Forms.Label
    Private WithEvents CustomerOrderDt As System.Windows.Forms.DateTimePicker
    Private WithEvents txtCustomerId As System.Windows.Forms.TextBox
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents DeliveryDt As System.Windows.Forms.DateTimePicker
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents txtDeliveryId As System.Windows.Forms.TextBox
    Private WithEvents cmbisi As System.Windows.Forms.ComboBox
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents chkIsJobwork As System.Windows.Forms.CheckBox
    Private WithEvents chkDeliverySame As System.Windows.Forms.CheckBox
    Private WithEvents lblCustName As System.Windows.Forms.Label
    Private WithEvents lbladd1 As System.Windows.Forms.Label
    Private WithEvents lbladd2 As System.Windows.Forms.Label
    Private WithEvents lblcity As System.Windows.Forms.Label
    Private WithEvents lbldName As System.Windows.Forms.Label
    Private WithEvents lbldadd1 As System.Windows.Forms.Label
    Private WithEvents lbldadd2 As System.Windows.Forms.Label
    Private WithEvents lbldcity As System.Windows.Forms.Label
    Private WithEvents txtOrderNo As System.Windows.Forms.TextBox
    Private WithEvents grpHeader As System.Windows.Forms.GroupBox
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colValue As System.Windows.Forms.ColumnHeader
    Private WithEvents colRate As System.Windows.Forms.ColumnHeader
    Private WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents lvwOrder As System.Windows.Forms.ListView
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents txtNetTotal As System.Windows.Forms.TextBox
    Private WithEvents grpLvwOrder As System.Windows.Forms.GroupBox
    Private WithEvents txtItemID As System.Windows.Forms.TextBox
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents cmdAddItem As System.Windows.Forms.Button
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents label4 As System.Windows.Forms.Label
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents txtRate As System.Windows.Forms.TextBox
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents grpEntry As System.Windows.Forms.GroupBox
    Friend WithEvents colMtns As System.Windows.Forms.ColumnHeader
    Friend WithEvents colNos As System.Windows.Forms.ColumnHeader
    Friend WithEvents colMtrs As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colIGST As System.Windows.Forms.ColumnHeader
    Private WithEvents txtRoundOff As System.Windows.Forms.TextBox
    Private WithEvents Label19 As System.Windows.Forms.Label
    Private WithEvents txtIGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents txtSGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents txtCGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents txtTaxable As System.Windows.Forms.TextBox
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents txtTotalVal As System.Windows.Forms.TextBox
    Private WithEvents Label20 As System.Windows.Forms.Label
End Class
