﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 03:40
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System.Data
Imports System.Data.Odbc
Imports System.Windows.Forms
Imports VST.Common
Imports VST.Constants
Imports VST.Masters

Partial Public Class Item
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim strDescription As String
    Dim loadFlag As Boolean = False
    Dim strSQL As String
    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
    End Sub


    Sub ItemLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            LoadFlag = True

            ds = getItemType
            If ds.Tables(0).Rows.Count > 0 Then
                cmbItemType.DataSource = ds.Tables(0)
                cmbItemType.DisplayMember = "type_short_name"
                cmbItemType.ValueMember = "item_type_id"
            End If
            ds = getUom()
            If ds.Tables(0).Rows.Count > 0 Then
                cmbUomLength.DataSource = ds.Tables(0)
                cmbUomLength.DisplayMember = "uom_short_desc"
                cmbUomLength.ValueMember = "uom_id"
            End If
            ds = getUom
            If ds.Tables(0).Rows.Count > 0 Then
                cmbUom.DataSource = ds.Tables(0)
                cmbUom.DisplayMember = "uom_short_desc"
                cmbUom.ValueMember = "uom_id"
            End If

            ds = getISI
            If ds.Tables(0).Rows.Count > 0 Then
                cmbisi.DataSource = ds.Tables(0)
                cmbisi.DisplayMember = "isi_std_short_desc"
                cmbisi.ValueMember = "isi_std_id"
            End If
            initializeControls()
            thisScreenMode = ScreenMode.Add
            Call EnableDisable(False)
            loadFlag = False
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub initializeControls()
        txtItemNo.Text = ""
        txtThickness.Text = ""
        txtGrade.Text = ""
        txtDescription.Text = ""
        txtWidth.Text = ""
        txtLength.Text = ""
        txtBreadth.Text = ""
        txtOD.Text = ""
        txtHSN.Text = ""
        txtGST.Text = ""
        txtCGST.Text = ""
        txtIGST.Text = ""
        txtSGST.Text = ""
        txtBundleNos.Text = ""
        txtSlitWidth.Text = ""
        cmbItemType.SelectedIndex = -1
        cmbIsi.SelectedIndex = -1
        cmbUom.SelectedIndex = -1
        cmbUomLength.SelectedIndex = -1

    End Sub

    Public Sub EnableDisable(toggle As Boolean)
        txtItemNo.Enabled = False
        txtThickness.Enabled = toggle
        txtWidth.Enabled = toggle
        txtDescription.Enabled = toggle
        txtGrade.Enabled = toggle
        txtLength.Enabled = toggle
        txtBreadth.Enabled = toggle
        txtOD.Enabled = toggle
        txtHSN.Enabled = toggle
        txtGST.Enabled = toggle
        txtSGST.Enabled = toggle
        txtCGST.Enabled = toggle
        txtIGST.Enabled = toggle
        cmbUom.Enabled = toggle
        cmbUomLength.Enabled = toggle
        cmbItemType.Enabled = Not toggle
        cmbIsi.Enabled = toggle
        txtBundleNos.Enabled = toggle
        txtSlitWidth.Enabled = False
    End Sub

    Public Sub genDescription()
        If Mid(cmbItemType.Text, 1, 4) = "SLIT" Or cmbItemType.Text = "HR" Or cmbItemType.Text = "GP" Or cmbItemType.Text = "CR" Then
            strDescription = txtThickness.Text.Trim + " " + "mm" + " X " + txtWidth.Text.Trim + " " + "mm"
            If txtGrade.Text <> "" Then
                strDescription = strDescription + " X " + txtGrade.Text.Trim
            End If
            If cmbIsi.Text.Trim <> "" Then
                strDescription = strDescription + " X " + cmbIsi.Text.Trim
            End If
            strDescription = strDescription + " - " + cmbItemType.Text
        Else
            If Mid(cmbItemType.Text, 3) = "CHS" Then
                strDescription = txtOD.Text + " mm X " + txtThickness.Text.Trim + " mm X " + txtLength.Text + " " + cmbUomLength.Text
            Else
                strDescription = txtWidth.Text + " mm X " + txtBreadth.Text + " mm X " + txtThickness.Text.Trim + " mm X " + txtLength.Text + " " + cmbUomLength.Text
            End If
            If txtGrade.Text <> "" Then
                strDescription = strDescription + " X " + txtGrade.Text.Trim
            End If
            If cmbIsi.Text.Trim <> "" Then
                strDescription = strDescription + " X " + cmbIsi.Text.Trim
            End If
            strDescription = strDescription + " - " + cmbItemType.Text
        End If
    End Sub


    Public Sub calculateWeight()
        Dim dblThickness As Double
        Dim dblBreadth As Double
        Dim dblWidth As Double
        Dim dblunitWeight As Double
        Dim dblslitwidth As Double
        If Mid(cmbItemType.Text.Trim, 1, 3) = "CHS" Then
            dblThickness = Val(txtThickness.Text.Trim)
            txtUnitWeight.Text = ((Val(txtOD.Text.Trim) - Val(txtThickness.Text.Trim)) * Val(txtThickness.Text) * 0.0246615).ToString
            dblslitwidth = (Val(txtOD.Text.Trim) * 3.1416) - 1.6 - dblThickness
            txtSlitWidth.Text = dblslitwidth.ToString
        End If
        If Mid(cmbItemType.Text.Trim, 1, 3) = "RHS" Or Mid(cmbItemType.Text.Trim, 1, 3) = "SHS" Then
            dblThickness = Val(txtThickness.Text.Trim)
            dblBreadth = Val(txtBreadth.Text.Trim)
            dblWidth = Val(txtWidth.Text.Trim)
            dblunitWeight = ((2 * dblThickness * ((dblBreadth - (4 * dblThickness) + dblWidth - (4 * dblThickness)) + (3 / 2 * 3.142 * dblThickness))) * 0.785) / 100
            txtUnitWeight.Text = dblunitWeight.ToString
            dblslitwidth = (2 * dblThickness * ((dblBreadth - (4 * dblThickness) + dblWidth - (4 * dblThickness)) + (3 / 2 * 3.142 * dblThickness))) / dblThickness + (3 / 2 * 3.142 * dblThickness)
            txtSlitWidth.Text = dblslitwidth.ToString
        End If
    End Sub


    Private Function validateItem() As Boolean
        If cmbItemType.Text = "" Then
            MsgBox("Please Select Item Type", MsgBoxStyle.Information, gCompanyShortName)
            Return False
            Exit Function
        End If
        If Mid(cmbItemType.Text, 1, 4) = "SLIT" Or cmbItemType.Text = "HR" Or cmbItemType.Text = "GP" Or cmbItemType.Text = "CR" Then
            If txtThickness.Text = "" Then
                MsgBox("Please Enter Thickness", MsgBoxStyle.Information, gCompanyShortName)
                txtThickness.Focus()
                Return False
                Exit Function
            End If
            If txtWidth.Text = "" Then
                MsgBox("Please Enter Width", MsgBoxStyle.Information, gCompanyShortName)
                txtWidth.Focus()
                Return False
                Exit Function
            End If
            'If txtGrade.Text = "" Then
            '    MsgBox("Please Enter Grade", MsgBoxStyle.Information, gCompanyShortName)
            '    txtGrade.Focus()
            '    Return False
            '    Exit Function
            'End If
        Else
            If Mid(cmbItemType.Text, 1, 3) = "RHS" Or Mid(cmbItemType.Text, 1, 3) = "SHS" Then
                If txtBreadth.Text = "" Then
                    MsgBox("Please Enter the Breadth", MsgBoxStyle.Information, gCompanyShortName)
                    txtBreadth.Focus()
                    Return False
                    Exit Function
                End If
                If txtBundleNos.Text = "" Then
                    MsgBox("Please enter number Of bundles", MsgBoxStyle.Information, gCompanyShortName)
                    txtBundleNos.Focus()
                    Return False
                    Exit Function
                End If
            End If
            If Mid(cmbItemType.Text, 1, 3) = "CHS" Then
                If txtOD.Text = "" Then
                    MsgBox("Please Enter the Outer Diameter", MsgBoxStyle.Information, gCompanyShortName)
                    txtOD.Focus()
                    Return False
                    Exit Function
                End If
            End If

            If txtThickness.Text = "" Then
                MsgBox("Please Enter Thickness", MsgBoxStyle.Information, gCompanyShortName)
                txtThickness.Focus
                Return False
                Exit Function
            End If
            If txtLength.Text = "" Then
                MsgBox("Please Enter Length", MsgBoxStyle.Information, gCompanyShortName)
                txtLength.Focus()
                Return False
                Exit Function
            End If
            If cmbUomLength.Text = "" Then
                MsgBox("Please Select Length UOM", MsgBoxStyle.Information, gCompanyShortName)
                cmbUomLength.Focus
                Return False
                Exit Function
            End If
            If txtBundleNos.Text = "" Then
                MsgBox("Please enter number Of bundles", MsgBoxStyle.Information, gCompanyShortName)
                txtBundleNos.Focus()
                Return False
                Exit Function
            End If
        End If
        If txtDescription.Text = "" Then
            MsgBox("Please Click Generate Item to generate Item description", MsgBoxStyle.Information, gCompanyShortName)
            cmdGenItem.Focus
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please Select UOM of the Item", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus
            Return False
            Exit Function
        End If
        If txtGST.Text = "" Then
            MsgBox("Please Enter GST", MsgBoxStyle.Information, gCompanyShortName)
            txtGST.Focus()
            Return False
            Exit Function
        End If
        If txtSGST.Text = "" Then
            MsgBox("Please Enter SGST", MsgBoxStyle.Information, gCompanyShortName)
            txtSGST.Focus()
            Return False
            Exit Function
        End If
        If txtCGST.Text = "" Then
            MsgBox("Please Enter CGST", MsgBoxStyle.Information, gCompanyShortName)
            txtCGST.Focus()
            Return False
            Exit Function
        End If
        If txtIGST.Text = "" Then
            MsgBox("Please Enter IGST", MsgBoxStyle.Information, gCompanyShortName)
            txtIGST.Focus()
            Return False
            Exit Function
        End If
        Return True
    End Function

    Sub CmdSaveClick(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveItem()

    End Sub

    Sub saveItem()
        Try
            If validateItem() Then
                If thisScreenMode = ScreenMode.Add Then
                    Call insertItem()
                End If
                If thisScreenMode = ScreenMode.Edit Then
                    Call updateItem()
                End If
                Call initializeControls()
                Call EnableDisable(False)
                cmdEdit.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub insertItem()
        Call getSysDateTime()
        Dim cmd As New OdbcCommand
        Dim intItemId As Integer
        Dim obj As Object
        Try
            strSQL = "SELECT max(item_id) AS item_id FROM public.stk_Item_Master"
            obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
            If IsDBNull(obj) Then

                intItemId = 1
            Else
                intItemId = CInt(obj.ToString) + 1
            End If
            txtItemNo.Text = intItemId.ToString
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT insertItem(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@itemId", OdbcType.Int).Value = Val(txtItemNo.Text)
            cmd.Parameters.AddWithValue("@typeid", OdbcType.Int).Value = Val(cmbItemType.SelectedValue.ToString)
            If cmbIsi.SelectedIndex > 0 Then
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = Val(cmbIsi.SelectedValue.ToString)
            Else
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = 0
            End If
            cmd.Parameters.AddWithValue("@itemdescription", OdbcType.NText).Value = txtDescription.Text.Trim()
            cmd.Parameters.AddWithValue("@itemgrade", OdbcType.NText).Value = txtGrade.Text.Trim()
            cmd.Parameters.AddWithValue("@uomId", OdbcType.Int).Value = Val(cmbUom.SelectedValue.ToString)
            If Not txtThickness.Text = "" Then
                cmd.Parameters.AddWithValue("@itemthickness", OdbcType.NText).Value = txtThickness.Text
            Else
                cmd.Parameters.AddWithValue("@itemthickness", OdbcType.NText).Value = ""
            End If

            If Not txtWidth.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@itemWidth", OdbcType.NText).Value = txtWidth.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@itemWidth", OdbcType.NText).Value = ""
            End If
            If Not txtLength.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@itemLength", OdbcType.NText).Value = txtLength.Text.Trim
                cmd.Parameters.AddWithValue("@lengthUomId", OdbcType.Int).Value = Val(cmbUomLength.SelectedValue.ToString)
            Else
                cmd.Parameters.AddWithValue("@itemLength", OdbcType.NText).Value = ""
                cmd.Parameters.AddWithValue("@lengthUomId", OdbcType.Int).Value = 0
            End If
            If Not txtBreadth.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@breadth", OdbcType.NText).Value = txtBreadth.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@breadth", OdbcType.NText).Value = ""
            End If
            If Not txtOD.Text = "" Then
                cmd.Parameters.AddWithValue("@od", OdbcType.NText).Value = txtOD.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@od", OdbcType.NText).Value = ""
            End If
            If Not txtUnitWeight.Text = "" Then
                cmd.Parameters.AddWithValue("@unitWeight", OdbcType.Real).Value = Val(txtUnitWeight.Text.Trim)
            Else
                cmd.Parameters.AddWithValue("@unitWeight", OdbcType.Decimal).Value = 0
            End If
            cmd.Parameters.AddWithValue("@gst", OdbcType.Decimal).Value = CDec(Val(txtGST.Text.Trim))
            cmd.Parameters.AddWithValue("@cgst", OdbcType.Decimal).Value = CDec(Val(txtCGST.Text.Trim))
            cmd.Parameters.AddWithValue("@sgst", OdbcType.Decimal).Value = CDec(Val(txtSGST.Text.Trim))
            cmd.Parameters.AddWithValue("@igst", OdbcType.Decimal).Value = CDec(Val(txtIGST.Text.Trim))
            cmd.Parameters.AddWithValue("@hsn", OdbcType.NText).Value = txtHSN.Text.Trim
            cmd.Parameters.AddWithValue("@slitWidth", OdbcType.Decimal).Value = Val(txtSlitWidth.Text)
            cmd.Parameters.AddWithValue("@bundlenos", OdbcType.Int).Value = Val(txtBundleNos.Text)
            cmd.Parameters.AddWithValue("@createddt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@createdtm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@createdby", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@isActive", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")

            cmd.ExecuteScalar()
            MsgBox("Item Id: " + intItemId.ToString + " Created", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Source & " : " & ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateItem()
        Call getSysDateTime()
        Dim cmd As New OdbcCommand
        Try
            Call getSysDateTime()
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT updateItem(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.Parameters.AddWithValue("@itemId", OdbcType.Int).Value = CInt(txtItemNo.Text)
            cmd.Parameters.AddWithValue("@typeid", OdbcType.Int).Value = CInt(cmbItemType.SelectedValue.ToString)
            If cmbIsi.SelectedIndex > 0 Then
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = CInt(cmbIsi.SelectedValue.ToString)
            Else
                cmd.Parameters.AddWithValue("@isistdid", OdbcType.Int).Value = 0
            End If
            cmd.Parameters.AddWithValue("@itemdescription", OdbcType.NText).Value = txtDescription.Text.Trim()
            cmd.Parameters.AddWithValue("@itemgrade", OdbcType.NText).Value = txtGrade.Text.Trim()
            cmd.Parameters.AddWithValue("@uomId", OdbcType.Int).Value = CInt(cmbUom.SelectedValue.ToString)
            If Not txtThickness.Text = "" Then
                cmd.Parameters.AddWithValue("@itemthickness", OdbcType.NText).Value = txtThickness.Text
            Else
                cmd.Parameters.AddWithValue("@itemthickness", OdbcType.NText).Value = ""
            End If

            If Not txtWidth.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@itemWidth", OdbcType.NText).Value = txtWidth.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@itemWidth", OdbcType.NText).Value = ""
            End If
            If Not txtLength.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@itemLength", OdbcType.NText).Value = txtLength.Text.Trim
                cmd.Parameters.AddWithValue("@lengthUomId", OdbcType.Int).Value = CInt(cmbUomLength.SelectedValue.ToString)
            Else
                cmd.Parameters.AddWithValue("@itemLength", OdbcType.NText).Value = ""
                cmd.Parameters.AddWithValue("@lengthUomId", OdbcType.Int).Value = 0
            End If
            If Not txtBreadth.Text.Trim = "" Then
                cmd.Parameters.AddWithValue("@pbreadth", OdbcType.NText).Value = txtBreadth.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@pbredth", OdbcType.NText).Value = ""
            End If
            If Not txtOD.Text = "" Then
                cmd.Parameters.AddWithValue("@od", OdbcType.NText).Value = txtOD.Text.Trim
            Else
                cmd.Parameters.AddWithValue("@od", OdbcType.NText).Value = ""
            End If
            If Not txtUnitWeight.Text = "" Then
                cmd.Parameters.AddWithValue("@punitWeight", OdbcType.Decimal).Value = CDec(Val(txtUnitWeight.Text.Trim))
            Else
                cmd.Parameters.AddWithValue("@punitWeight", OdbcType.Decimal).Value = 0
            End If
            cmd.Parameters.AddWithValue("@pgst", OdbcType.Decimal).Value = CDec(Val(txtGST.Text.Trim))
            cmd.Parameters.AddWithValue("@pcgst", OdbcType.Decimal).Value = CDec(Val(txtCGST.Text.Trim))
            cmd.Parameters.AddWithValue("@psgst", OdbcType.Decimal).Value = CDec(Val(txtSGST.Text.Trim))
            cmd.Parameters.AddWithValue("@pigst", OdbcType.Decimal).Value = CDec(Val(txtIGST.Text.Trim))
            cmd.Parameters.AddWithValue("@phsn", OdbcType.NText).Value = txtHSN.Text.Trim
            cmd.Parameters.AddWithValue("@slitWidth", OdbcType.Decimal).Value = Val(txtSlitWidth.Text)
            cmd.Parameters.AddWithValue("@bundlenos", OdbcType.Int).Value = Val(txtBundleNos.Text)
            cmd.Parameters.AddWithValue("@createddt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@createdtm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@createdby", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@recstatus", OdbcType.Int).Value = 1
            cmd.Parameters.AddWithValue("@isActive", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.ExecuteScalar()
            MsgBox("Item Id: " + txtItemNo.Text + " Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub CmbItemTypeSelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbItemType.SelectedIndexChanged
        If loadFlag = False Then
            Call EnableDisable(True)
            If Mid(cmbItemType.Text, 1, 4) = "SLIT" Or cmbItemType.Text = "HR" Or cmbItemType.Text = "GP" Or cmbItemType.Text = "CR" Then
                txtLength.Enabled = False
                cmbUomLength.Enabled = False
                txtWidth.Enabled = True
                txtBreadth.Enabled = False
                txtOD.Enabled = False
                txtBundleNos.Enabled = False
                txtSlitWidth.Enabled = False
            Else
                If Mid(cmbItemType.Text, 1, 3) = "CHS" Then
                    txtOD.Enabled = True
                    txtWidth.Enabled = False
                    txtBreadth.Enabled = False
                Else
                    txtWidth.Enabled = True
                    txtBreadth.Enabled = True
                    txtOD.Enabled = False
                End If
                txtBundleNos.Enabled = True
                txtSlitWidth.Enabled = True
            End If
        End If
    End Sub

    Sub CmdCancelClick(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call initializeControls()
        Call EnableDisable(False)
        cmdEdit.Enabled = True
    End Sub


    Sub ItemKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveItem()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Sub CmbItemTypeKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbItemType.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbItemType.Text
        Dim typedT As String = t.Substring(0, cmbItemType.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbItemType.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Sub CmbIsiKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbIsi.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbIsi.Text
        Dim typedT As String = t.Substring(0, cmbIsi.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbIsi.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub


    Sub CmbUomKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub



    Sub CmbUomLengthKeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUomLength.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUomLength.Text
        Dim typedT As String = t.Substring(0, cmbUomLength.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUomLength.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Sub CmdEditClick(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        EnableDisable(False)
        cmdEdit.Enabled = False
        txtItemNo.Enabled = True
        cmbItemType.Enabled = False
        txtItemNo.Focus()
    End Sub

    Sub CmdGenItemClick(sender As Object, e As EventArgs) Handles cmdGenItem.Click
        'If validateItem Then
        Call genDescription()
        txtDescription.Text = strDescription
        'End If
    End Sub


    Sub TxtItemNoKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemNo.KeyPress
        Try
            If Asc(e.KeyChar) = 13 And txtItemNo.Text.Trim <> "" Then
                If Val(txtItemNo.Text.Trim) > 0 Then
                    ds = getItem(CInt(txtItemNo.Text))
                    If ds.Tables(0).Rows.Count > 0 Then
                        Call populateItem(CInt(txtItemNo.Text))
                    Else
                        MsgBox("No Record Found In This Item ID", MsgBoxStyle.Information, gCompanyShortName)
                        txtItemNo.Focus()
                    End If
                Else
                    txtItemNo.Focus()
                End If
            Else
                If Not isNumber(Asc(e.KeyChar)) Then
                    e.KeyChar = Nothing
                End If
            End If
            'AllowInteger(txtItemNo.Text, e)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Sub populateItem(intItemId As Integer)
        Try
            ds = getItem(intItemId)
            If ds.Tables(0).Rows.Count > 0 Then
                txtItemNo.Text = intItemId.ToString
                txtDescription.Text = ds.Tables(0).Rows(0).Item("Item_Description").ToString
                txtThickness.Text = ds.Tables(0).Rows(0).Item("Item_Thickness").ToString
                txtWidth.Text = ds.Tables(0).Rows(0).Item("Item_width").ToString
                txtLength.Text = ds.Tables(0).Rows(0).Item("Item_Length").ToString
                txtGrade.Text = ds.Tables(0).Rows(0).Item("Item_grade").ToString
                txtBreadth.Text = ds.Tables(0).Rows(0).Item("breadth").ToString
                txtOD.Text = ds.Tables(0).Rows(0).Item("outerdiameter").ToString
                txtUnitWeight.Text = ds.Tables(0).Rows(0).Item("unitweight").ToString
                txtGST.Text = ds.Tables(0).Rows(0).Item("gst").ToString
                txtCGST.Text = ds.Tables(0).Rows(0).Item("cgst").ToString
                txtSGST.Text = ds.Tables(0).Rows(0).Item("sgst").ToString
                txtIGST.Text = ds.Tables(0).Rows(0).Item("igst").ToString
                txtHSN.Text = ds.Tables(0).Rows(0).Item("hsn").ToString
                txtBundleNos.Text = ds.Tables(0).Rows(0).Item("bundle_nos").ToString
                txtSlitWidth.Text = ds.Tables(0).Rows(0).Item("slit_width").ToString
                loadFlag = True
                cmbItemType.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("type_Id").ToString)
                cmbIsi.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("isi_std_id").ToString)
                cmbUomLength.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("Length_uomId").ToString)
                cmbUom.SelectedValue = CInt(ds.Tables(0).Rows(0).Item("uom_id").ToString)
                If (ds.Tables(0).Rows(0).Item("is_Active").ToString) = "1" Then
                    chkIsActive.Checked = True
                Else
                    chkIsActive.Checked = False
                End If
                Call EnableDisable(True)
                loadFlag = False
                If Mid(cmbItemType.Text, 1, 4) = "SLIT" Or cmbItemType.Text = "HR" Or cmbItemType.Text = "GP" Or cmbItemType.Text = "CR" Then
                    txtLength.Enabled = False
                    cmbUomLength.Enabled = False
                    txtWidth.Enabled = True
                    txtBreadth.Enabled = False
                    txtOD.Enabled = False
                    txtBundleNos.Enabled = False
                    txtSlitWidth.Enabled = False
                Else
                    txtLength.Enabled = True
                    cmbUomLength.Enabled = True
                    If Mid(cmbItemType.Text, 1, 3) = "SHS" Or Mid(cmbItemType.Text, 1, 3) = "RHS" Then
                        txtWidth.Enabled = True
                        txtBreadth.Enabled = True
                        txtOD.Enabled = False
                    Else
                        txtBreadth.Enabled = False
                        txtWidth.Enabled = False
                        txtOD.Enabled = True
                    End If
                End If
            Else
                MsgBox("Item Id Not Found", MsgBoxStyle.Information, gCompanyShortName)
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            txtItemNo.Text = ""
        End Try
    End Sub

    Sub TxtItemNoKeyDown(sender As Object, e As KeyEventArgs) Handles txtItemNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                'ds = getItem()
                ds = getItemPaging(0, 10)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemNo.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub TxtThicknessKeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtThickness.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub


    Sub TxtWidthKeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtWidth.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Sub TxtLengthKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtLength.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If InStr(txtLength.Text, ".") > 0 Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub



    Sub TxtBreadthKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBreadth.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If InStr(txtBreadth.Text, ".") > 0 Then
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Sub TxtODKeyPress(sender As Object, e As KeyPressEventArgs) Handles txtOD.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtOD.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub


    Sub TxtThicknessTextChanged(sender As Object, e As EventArgs) Handles txtThickness.KeyPress
        Call calculateWeight()
    End Sub


    Sub TxtODTextChanged(sender As Object, e As EventArgs) Handles txtOD.TextChanged
        Call calculateWeight()
    End Sub

    Sub TxtBreadthTextChanged(sender As Object, e As EventArgs) Handles txtBreadth.TextChanged
        Call calculateWeight()
    End Sub

    Sub TxtWidthTextChanged(sender As Object, e As EventArgs) Handles txtWidth.TextChanged
        Call calculateWeight()
    End Sub

    Private Sub txtThickness_TextChanged(sender As Object, e As EventArgs) Handles txtThickness.TextChanged
        Call calculateWeight()
    End Sub

    Private Sub txtGST_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtGST.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtSGST_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtSGST.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtCGST_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtCGST.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtIGST_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtIGST.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

End Class
