﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:17
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Production
    Inherits System.Windows.Forms.Form

    ''' <summary>
    ''' Designer variable used to keep track of non-visual components.
    ''' </summary>
    Private components As System.ComponentModel.IContainer

    ''' <summary>
    ''' Disposes resources used by the form.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If components IsNot Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    ''' <summary>
    ''' This method is required for Windows Forms designer support.
    ''' Do not change the method contents inside the source code editor. The Forms designer might
    ''' not be able to load this method if it was changed manually.
    ''' </summary>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Production))
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.cmdOk = New System.Windows.Forms.Button()
        Me.cmdText = New System.Windows.Forms.Button()
        Me.cmdExcel = New System.Windows.Forms.Button()
        Me.cmdPdf = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(94, 164)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(94, 20)
        Me.txtAmount.TabIndex = 4
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(187, 118)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'cmdOk
        '
        Me.cmdOk.Location = New System.Drawing.Point(88, 106)
        Me.cmdOk.Name = "cmdOk"
        Me.cmdOk.Size = New System.Drawing.Size(85, 33)
        Me.cmdOk.TabIndex = 6
        Me.cmdOk.Text = "OK"
        Me.cmdOk.UseVisualStyleBackColor = True
        '
        'cmdText
        '
        Me.cmdText.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdText.Image = Global.VST.My.Resources.Resources.notepad
        Me.cmdText.Location = New System.Drawing.Point(151, 48)
        Me.cmdText.Name = "cmdText"
        Me.cmdText.Size = New System.Drawing.Size(44, 46)
        Me.cmdText.TabIndex = 9
        Me.cmdText.UseVisualStyleBackColor = True
        '
        'cmdExcel
        '
        Me.cmdExcel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdExcel.Image = Global.VST.My.Resources.Resources.Excel
        Me.cmdExcel.Location = New System.Drawing.Point(94, 47)
        Me.cmdExcel.Name = "cmdExcel"
        Me.cmdExcel.Size = New System.Drawing.Size(41, 46)
        Me.cmdExcel.TabIndex = 8
        Me.cmdExcel.UseVisualStyleBackColor = True
        '
        'cmdPdf
        '
        Me.cmdPdf.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdPdf.Image = CType(resources.GetObject("cmdPdf.Image"), System.Drawing.Image)
        Me.cmdPdf.Location = New System.Drawing.Point(29, 48)
        Me.cmdPdf.Name = "cmdPdf"
        Me.cmdPdf.Size = New System.Drawing.Size(44, 46)
        Me.cmdPdf.TabIndex = 7
        Me.cmdPdf.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(30, 171)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(43, 40)
        Me.Button2.TabIndex = 10
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Production
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.cmdText)
        Me.Controls.Add(Me.cmdExcel)
        Me.Controls.Add(Me.cmdPdf)
        Me.Controls.Add(Me.cmdOk)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtAmount)
        Me.Name = "Production"
        Me.Text = "Production"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Private WithEvents cmdOk As System.Windows.Forms.Button
    Private WithEvents cmdPdf As System.Windows.Forms.Button
    Private WithEvents cmdExcel As System.Windows.Forms.Button
    Private WithEvents cmdText As System.Windows.Forms.Button
    Private WithEvents Button2 As System.Windows.Forms.Button
End Class
