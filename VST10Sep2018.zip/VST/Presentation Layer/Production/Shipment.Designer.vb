﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 16:11
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Partial Class Shipment
	Inherits System.Windows.Forms.Form
	
	''' <summary>
	''' Designer variable used to keep track of non-visual components.
	''' </summary>
	Private components As System.ComponentModel.IContainer
	
	''' <summary>
	''' Disposes resources used by the form.
	''' </summary>
	''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing Then
			If components IsNot Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(disposing)
	End Sub
	
	''' <summary>
	''' This method is required for Windows Forms designer support.
	''' Do not change the method contents inside the source code editor. The Forms designer might
	''' not be able to load this method if it was changed manually.
	''' </summary>
	Private Sub InitializeComponent()
        Me.grpCustomer = New System.Windows.Forms.GroupBox()
        Me.lblCustName = New System.Windows.Forms.Label()
        Me.label7 = New System.Windows.Forms.Label()
        Me.chkIsActive = New System.Windows.Forms.CheckBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.label9 = New System.Windows.Forms.Label()
        Me.label8 = New System.Windows.Forms.Label()
        Me.label6 = New System.Windows.Forms.Label()
        Me.label4 = New System.Windows.Forms.Label()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.label1 = New System.Windows.Forms.Label()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.txtCustomerNo = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.txtEmailId = New System.Windows.Forms.TextBox()
        Me.txtContactPerson = New System.Windows.Forms.TextBox()
        Me.txtShipmentPin = New System.Windows.Forms.TextBox()
        Me.txtShipmentState = New System.Windows.Forms.TextBox()
        Me.txtShipmentCity = New System.Windows.Forms.TextBox()
        Me.txtShipmentAdd2 = New System.Windows.Forms.TextBox()
        Me.txtShipmentAdd1 = New System.Windows.Forms.TextBox()
        Me.txtCustomerName = New System.Windows.Forms.TextBox()
        Me.txtShipmentNo = New System.Windows.Forms.TextBox()
        Me.grpCustomer.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpCustomer
        '
        Me.grpCustomer.Controls.Add(Me.txtCustomerNo)
        Me.grpCustomer.Controls.Add(Me.txtPhone)
        Me.grpCustomer.Controls.Add(Me.txtEmailId)
        Me.grpCustomer.Controls.Add(Me.txtContactPerson)
        Me.grpCustomer.Controls.Add(Me.txtShipmentPin)
        Me.grpCustomer.Controls.Add(Me.txtShipmentState)
        Me.grpCustomer.Controls.Add(Me.txtShipmentCity)
        Me.grpCustomer.Controls.Add(Me.txtShipmentAdd2)
        Me.grpCustomer.Controls.Add(Me.txtShipmentAdd1)
        Me.grpCustomer.Controls.Add(Me.txtCustomerName)
        Me.grpCustomer.Controls.Add(Me.txtShipmentNo)
        Me.grpCustomer.Controls.Add(Me.lblCustName)
        Me.grpCustomer.Controls.Add(Me.label7)
        Me.grpCustomer.Controls.Add(Me.chkIsActive)
        Me.grpCustomer.Controls.Add(Me.label10)
        Me.grpCustomer.Controls.Add(Me.label9)
        Me.grpCustomer.Controls.Add(Me.label8)
        Me.grpCustomer.Controls.Add(Me.label6)
        Me.grpCustomer.Controls.Add(Me.label4)
        Me.grpCustomer.Controls.Add(Me.label5)
        Me.grpCustomer.Controls.Add(Me.label3)
        Me.grpCustomer.Controls.Add(Me.label2)
        Me.grpCustomer.Controls.Add(Me.label1)
        Me.grpCustomer.Location = New System.Drawing.Point(19, 17)
        Me.grpCustomer.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.grpCustomer.Name = "grpCustomer"
        Me.grpCustomer.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.grpCustomer.Size = New System.Drawing.Size(506, 396)
        Me.grpCustomer.TabIndex = 17
        Me.grpCustomer.TabStop = False
        '
        'lblCustName
        '
        Me.lblCustName.Location = New System.Drawing.Point(199, 56)
        Me.lblCustName.Name = "lblCustName"
        Me.lblCustName.Size = New System.Drawing.Size(276, 20)
        Me.lblCustName.TabIndex = 28
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(19, 57)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(87, 19)
        Me.label7.TabIndex = 27
        Me.label7.Text = "Customer ID"
        '
        'chkIsActive
        '
        Me.chkIsActive.Location = New System.Drawing.Point(106, 367)
        Me.chkIsActive.Name = "chkIsActive"
        Me.chkIsActive.Size = New System.Drawing.Size(101, 20)
        Me.chkIsActive.TabIndex = 12
        Me.chkIsActive.Text = "Is Active"
        Me.chkIsActive.UseVisualStyleBackColor = True
        '
        'label10
        '
        Me.label10.Location = New System.Drawing.Point(51, 339)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(54, 19)
        Me.label10.TabIndex = 25
        Me.label10.Text = "Phone"
        '
        'label9
        '
        Me.label9.Location = New System.Drawing.Point(41, 310)
        Me.label9.Name = "label9"
        Me.label9.Size = New System.Drawing.Size(62, 19)
        Me.label9.TabIndex = 23
        Me.label9.Text = "Email ID"
        '
        'label8
        '
        Me.label8.Location = New System.Drawing.Point(1, 281)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(100, 20)
        Me.label8.TabIndex = 21
        Me.label8.Text = "Contact Person"
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(71, 249)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(29, 19)
        Me.label6.TabIndex = 17
        Me.label6.Text = "Pin"
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(60, 216)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(41, 19)
        Me.label4.TabIndex = 15
        Me.label4.Text = "State"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(68, 185)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(31, 19)
        Me.label5.TabIndex = 13
        Me.label5.Text = "City"
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(44, 118)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(58, 19)
        Me.label3.TabIndex = 9
        Me.label3.Text = "Address"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(56, 87)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(45, 19)
        Me.label2.TabIndex = 7
        Me.label2.Text = "Name" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(18, 28)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(87, 19)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Shipment ID"
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(251, 423)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 19
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(440, 423)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 21
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(347, 423)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 20
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(155, 422)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 18
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'txtCustomerNo
        '
        Me.txtCustomerNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerNo.Location = New System.Drawing.Point(108, 58)
        Me.txtCustomerNo.Name = "txtCustomerNo"
        Me.txtCustomerNo.Size = New System.Drawing.Size(87, 22)
        Me.txtCustomerNo.TabIndex = 30
        '
        'txtPhone
        '
        Me.txtPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPhone.Location = New System.Drawing.Point(108, 338)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(219, 22)
        Me.txtPhone.TabIndex = 39
        '
        'txtEmailId
        '
        Me.txtEmailId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEmailId.Location = New System.Drawing.Point(107, 309)
        Me.txtEmailId.Name = "txtEmailId"
        Me.txtEmailId.Size = New System.Drawing.Size(219, 22)
        Me.txtEmailId.TabIndex = 38
        '
        'txtContactPerson
        '
        Me.txtContactPerson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtContactPerson.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtContactPerson.Location = New System.Drawing.Point(108, 280)
        Me.txtContactPerson.Name = "txtContactPerson"
        Me.txtContactPerson.Size = New System.Drawing.Size(219, 22)
        Me.txtContactPerson.TabIndex = 37
        '
        'txtShipmentPin
        '
        Me.txtShipmentPin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentPin.Location = New System.Drawing.Point(108, 248)
        Me.txtShipmentPin.Name = "txtShipmentPin"
        Me.txtShipmentPin.Size = New System.Drawing.Size(101, 22)
        Me.txtShipmentPin.TabIndex = 36
        '
        'txtShipmentState
        '
        Me.txtShipmentState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentState.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtShipmentState.Location = New System.Drawing.Point(107, 215)
        Me.txtShipmentState.Name = "txtShipmentState"
        Me.txtShipmentState.Size = New System.Drawing.Size(219, 22)
        Me.txtShipmentState.TabIndex = 35
        '
        'txtShipmentCity
        '
        Me.txtShipmentCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentCity.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtShipmentCity.Location = New System.Drawing.Point(107, 184)
        Me.txtShipmentCity.Name = "txtShipmentCity"
        Me.txtShipmentCity.Size = New System.Drawing.Size(219, 22)
        Me.txtShipmentCity.TabIndex = 34
        '
        'txtShipmentAdd2
        '
        Me.txtShipmentAdd2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentAdd2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtShipmentAdd2.Location = New System.Drawing.Point(107, 152)
        Me.txtShipmentAdd2.Name = "txtShipmentAdd2"
        Me.txtShipmentAdd2.Size = New System.Drawing.Size(370, 22)
        Me.txtShipmentAdd2.TabIndex = 33
        '
        'txtShipmentAdd1
        '
        Me.txtShipmentAdd1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentAdd1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtShipmentAdd1.Location = New System.Drawing.Point(108, 117)
        Me.txtShipmentAdd1.Name = "txtShipmentAdd1"
        Me.txtShipmentAdd1.Size = New System.Drawing.Size(370, 22)
        Me.txtShipmentAdd1.TabIndex = 32
        '
        'txtCustomerName
        '
        Me.txtCustomerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtCustomerName.Location = New System.Drawing.Point(107, 86)
        Me.txtCustomerName.Name = "txtCustomerName"
        Me.txtCustomerName.Size = New System.Drawing.Size(370, 22)
        Me.txtCustomerName.TabIndex = 31
        '
        'txtShipmentNo
        '
        Me.txtShipmentNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentNo.Location = New System.Drawing.Point(107, 29)
        Me.txtShipmentNo.Name = "txtShipmentNo"
        Me.txtShipmentNo.Size = New System.Drawing.Size(87, 22)
        Me.txtShipmentNo.TabIndex = 29
        '
        'Shipment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(544, 470)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.grpCustomer)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Shipment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Shipment"
        Me.grpCustomer.ResumeLayout(False)
        Me.grpCustomer.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Private lblCustName As System.Windows.Forms.Label
    Private label1 As System.Windows.Forms.Label
    Private label2 As System.Windows.Forms.Label
    Private label3 As System.Windows.Forms.Label
    Private label5 As System.Windows.Forms.Label
    Private label4 As System.Windows.Forms.Label
    Private label6 As System.Windows.Forms.Label
    Private label7 As System.Windows.Forms.Label
    Private label8 As System.Windows.Forms.Label
    Private label9 As System.Windows.Forms.Label
    Private label10 As System.Windows.Forms.Label
    Private chkIsActive As System.Windows.Forms.CheckBox
    Private grpCustomer As System.Windows.Forms.GroupBox
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents txtShipmentNo As System.Windows.Forms.TextBox
    Private WithEvents txtCustomerName As System.Windows.Forms.TextBox
    Private WithEvents txtShipmentAdd1 As System.Windows.Forms.TextBox
    Private WithEvents txtShipmentAdd2 As System.Windows.Forms.TextBox
    Private WithEvents txtShipmentCity As System.Windows.Forms.TextBox
    Private WithEvents txtShipmentState As System.Windows.Forms.TextBox
    Private WithEvents txtShipmentPin As System.Windows.Forms.TextBox
    Private WithEvents txtContactPerson As System.Windows.Forms.TextBox
    Private WithEvents txtEmailId As System.Windows.Forms.TextBox
    Private WithEvents txtPhone As System.Windows.Forms.TextBox
    Private WithEvents txtCustomerNo As System.Windows.Forms.TextBox
End Class
