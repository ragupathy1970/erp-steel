﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PurchaseOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpentry = New System.Windows.Forms.GroupBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.cmdAddItem = New System.Windows.Forms.Button()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtItemID = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtTotalVal = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtRoundOff = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtIGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtSGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtCGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTaxable = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtNetTotal = New System.Windows.Forms.TextBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.lvwPO = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colHSN = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemid = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colRate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colIGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cmbItemType = New System.Windows.Forms.ComboBox()
        Me.lblcity = New System.Windows.Forms.Label()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lbladd1 = New System.Windows.Forms.Label()
        Me.lblVenName = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtVendor = New System.Windows.Forms.TextBox()
        Me.txtPOno = New System.Windows.Forms.TextBox()
        Me.dtPODate = New System.Windows.Forms.DateTimePicker()
        Me.grpentry.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpentry
        '
        Me.grpentry.Controls.Add(Me.label13)
        Me.grpentry.Controls.Add(Me.Label2)
        Me.grpentry.Controls.Add(Me.Label1)
        Me.grpentry.Controls.Add(Me.Label8)
        Me.grpentry.Controls.Add(Me.Label6)
        Me.grpentry.Controls.Add(Me.txtRate)
        Me.grpentry.Controls.Add(Me.cmbUom)
        Me.grpentry.Controls.Add(Me.cmdAdd)
        Me.grpentry.Controls.Add(Me.txtQty)
        Me.grpentry.Controls.Add(Me.cmdAddItem)
        Me.grpentry.Controls.Add(Me.txtDescription)
        Me.grpentry.Controls.Add(Me.txtItemID)
        Me.grpentry.Location = New System.Drawing.Point(17, 126)
        Me.grpentry.Name = "grpentry"
        Me.grpentry.Size = New System.Drawing.Size(844, 68)
        Me.grpentry.TabIndex = 1
        Me.grpentry.TabStop = False
        '
        'label13
        '
        Me.label13.BackColor = System.Drawing.Color.Transparent
        Me.label13.Location = New System.Drawing.Point(665, 16)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(37, 15)
        Me.label13.TabIndex = 37
        Me.label13.Text = "Rate"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(602, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 15)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Quantity"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(539, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 19)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "UOM"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(188, 13)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 34
        Me.Label8.Text = "Item Description"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(77, 13)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "Item ID"
        '
        'txtRate
        '
        Me.txtRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRate.Location = New System.Drawing.Point(666, 35)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(74, 22)
        Me.txtRate.TabIndex = 20
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(542, 33)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(59, 24)
        Me.cmbUom.TabIndex = 18
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(747, 27)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 21
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(605, 34)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(55, 22)
        Me.txtQty.TabIndex = 19
        '
        'cmdAddItem
        '
        Me.cmdAddItem.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdAddItem.Location = New System.Drawing.Point(159, 33)
        Me.cmdAddItem.Name = "cmdAddItem"
        Me.cmdAddItem.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddItem.TabIndex = 16
        Me.cmdAddItem.Text = "+"
        Me.cmdAddItem.UseVisualStyleBackColor = True
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Location = New System.Drawing.Point(189, 33)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(350, 22)
        Me.txtDescription.TabIndex = 15
        '
        'txtItemID
        '
        Me.txtItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemID.Location = New System.Drawing.Point(81, 33)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.Size = New System.Drawing.Size(75, 22)
        Me.txtItemID.TabIndex = 17
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtTotalVal)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.txtRoundOff)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtIGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.txtSGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.txtCGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtTaxable)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtNetTotal)
        Me.GroupBox3.Controls.Add(Me.label14)
        Me.GroupBox3.Controls.Add(Me.lvwPO)
        Me.GroupBox3.Location = New System.Drawing.Point(16, 200)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(844, 251)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'txtTotalVal
        '
        Me.txtTotalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalVal.Enabled = False
        Me.txtTotalVal.Location = New System.Drawing.Point(367, 190)
        Me.txtTotalVal.Name = "txtTotalVal"
        Me.txtTotalVal.Size = New System.Drawing.Size(87, 22)
        Me.txtTotalVal.TabIndex = 31
        Me.txtTotalVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(288, 190)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(72, 22)
        Me.Label20.TabIndex = 30
        Me.Label20.Text = "Total Value"
        '
        'txtRoundOff
        '
        Me.txtRoundOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoundOff.Enabled = False
        Me.txtRoundOff.ForeColor = System.Drawing.Color.Red
        Me.txtRoundOff.Location = New System.Drawing.Point(543, 183)
        Me.txtRoundOff.Name = "txtRoundOff"
        Me.txtRoundOff.Size = New System.Drawing.Size(87, 22)
        Me.txtRoundOff.TabIndex = 29
        Me.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(476, 184)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 19)
        Me.Label19.TabIndex = 28
        Me.Label19.Text = "Round Off"
        '
        'txtIGSTTotal
        '
        Me.txtIGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIGSTTotal.Enabled = False
        Me.txtIGSTTotal.Location = New System.Drawing.Point(715, 213)
        Me.txtIGSTTotal.Name = "txtIGSTTotal"
        Me.txtIGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtIGSTTotal.TabIndex = 27
        Me.txtIGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(648, 212)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 19)
        Me.Label18.TabIndex = 26
        Me.Label18.Text = "IGST Total"
        '
        'txtSGSTTotal
        '
        Me.txtSGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSGSTTotal.Enabled = False
        Me.txtSGSTTotal.Location = New System.Drawing.Point(716, 184)
        Me.txtSGSTTotal.Name = "txtSGSTTotal"
        Me.txtSGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtSGSTTotal.TabIndex = 25
        Me.txtSGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(643, 183)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(77, 19)
        Me.Label17.TabIndex = 24
        Me.Label17.Text = "SGST Total"
        '
        'txtCGSTTotal
        '
        Me.txtCGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCGSTTotal.Enabled = False
        Me.txtCGSTTotal.Location = New System.Drawing.Point(716, 155)
        Me.txtCGSTTotal.Name = "txtCGSTTotal"
        Me.txtCGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtCGSTTotal.TabIndex = 23
        Me.txtCGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(642, 155)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 19)
        Me.Label16.TabIndex = 22
        Me.Label16.Text = "CGST Total"
        '
        'txtTaxable
        '
        Me.txtTaxable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTaxable.Enabled = False
        Me.txtTaxable.Location = New System.Drawing.Point(544, 154)
        Me.txtTaxable.Name = "txtTaxable"
        Me.txtTaxable.Size = New System.Drawing.Size(87, 22)
        Me.txtTaxable.TabIndex = 21
        Me.txtTaxable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(489, 153)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(56, 19)
        Me.Label15.TabIndex = 20
        Me.Label15.Text = "Taxable "
        '
        'txtNetTotal
        '
        Me.txtNetTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNetTotal.Enabled = False
        Me.txtNetTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNetTotal.Location = New System.Drawing.Point(543, 213)
        Me.txtNetTotal.Name = "txtNetTotal"
        Me.txtNetTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtNetTotal.TabIndex = 19
        Me.txtNetTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(479, 213)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(66, 19)
        Me.label14.TabIndex = 18
        Me.label14.Text = "Net Total"
        '
        'lvwPO
        '
        Me.lvwPO.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwPO.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwPO.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colHSN, Me.colItemid, Me.colDescription, Me.colUom, Me.colQty, Me.colRate, Me.colValue, Me.colCGST, Me.colSGST, Me.colIGST, Me.colSlnoKey, Me.colUomKey})
        Me.lvwPO.FullRowSelect = True
        Me.lvwPO.GridLines = True
        Me.lvwPO.Location = New System.Drawing.Point(9, 20)
        Me.lvwPO.MultiSelect = False
        Me.lvwPO.Name = "lvwPO"
        Me.lvwPO.Size = New System.Drawing.Size(828, 118)
        Me.lvwPO.TabIndex = 1
        Me.lvwPO.UseCompatibleStateImageBehavior = False
        Me.lvwPO.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 42
        '
        'colHSN
        '
        Me.colHSN.Text = "HSN"
        Me.colHSN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colItemid
        '
        Me.colItemid.Text = "Item Id"
        Me.colItemid.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colItemid.Width = 52
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 226
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colRate
        '
        Me.colRate.Text = "Rate"
        Me.colRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colRate.Width = 70
        '
        'colValue
        '
        Me.colValue.Text = "Value"
        Me.colValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colValue.Width = 100
        '
        'colCGST
        '
        Me.colCGST.Text = "CGST"
        Me.colCGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colCGST.Width = 70
        '
        'colSGST
        '
        Me.colSGST.Text = "SGST"
        Me.colSGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colSGST.Width = 70
        '
        'colIGST
        '
        Me.colIGST.Text = "IGST"
        Me.colIGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colIGST.Width = 70
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 1
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(581, 458)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 24
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(770, 458)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 23
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(677, 458)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 22
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(485, 457)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 21
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.cmbItemType)
        Me.GroupBox1.Controls.Add(Me.lblcity)
        Me.GroupBox1.Controls.Add(Me.lbladd2)
        Me.GroupBox1.Controls.Add(Me.lbladd1)
        Me.GroupBox1.Controls.Add(Me.lblVenName)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtVendor)
        Me.GroupBox1.Controls.Add(Me.txtPOno)
        Me.GroupBox1.Controls.Add(Me.dtPODate)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 24)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(844, 100)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label36.Location = New System.Drawing.Point(496, 64)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(66, 19)
        Me.Label36.TabIndex = 85
        Me.Label36.Text = "Item Type"
        '
        'cmbItemType
        '
        Me.cmbItemType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbItemType.FormattingEnabled = True
        Me.cmbItemType.Location = New System.Drawing.Point(573, 63)
        Me.cmbItemType.Name = "cmbItemType"
        Me.cmbItemType.Size = New System.Drawing.Size(265, 24)
        Me.cmbItemType.TabIndex = 84
        '
        'lblcity
        '
        Me.lblcity.Location = New System.Drawing.Point(186, 68)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(227, 15)
        Me.lblcity.TabIndex = 38
        '
        'lbladd2
        '
        Me.lbladd2.Location = New System.Drawing.Point(186, 51)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(227, 15)
        Me.lbladd2.TabIndex = 37
        '
        'lbladd1
        '
        Me.lbladd1.Location = New System.Drawing.Point(186, 33)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(227, 15)
        Me.lbladd1.TabIndex = 36
        '
        'lblVenName
        '
        Me.lblVenName.Location = New System.Drawing.Point(186, 17)
        Me.lblVenName.Name = "lblVenName"
        Me.lblVenName.Size = New System.Drawing.Size(227, 15)
        Me.lblVenName.TabIndex = 35
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label5.Location = New System.Drawing.Point(5, 57)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 19)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Supplier ID"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label4.Location = New System.Drawing.Point(608, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(59, 19)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "PO Date"
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(30, 23)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 19)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "PO No"
        '
        'txtVendor
        '
        Me.txtVendor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVendor.Location = New System.Drawing.Point(84, 54)
        Me.txtVendor.Name = "txtVendor"
        Me.txtVendor.Size = New System.Drawing.Size(87, 22)
        Me.txtVendor.TabIndex = 3
        '
        'txtPOno
        '
        Me.txtPOno.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPOno.Location = New System.Drawing.Point(85, 19)
        Me.txtPOno.Name = "txtPOno"
        Me.txtPOno.Size = New System.Drawing.Size(87, 22)
        Me.txtPOno.TabIndex = 1
        '
        'dtPODate
        '
        Me.dtPODate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtPODate.CustomFormat = "dd-MMM-yyyy"
        Me.dtPODate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtPODate.Location = New System.Drawing.Point(675, 25)
        Me.dtPODate.Name = "dtPODate"
        Me.dtPODate.Size = New System.Drawing.Size(99, 22)
        Me.dtPODate.TabIndex = 2
        Me.dtPODate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'PurchaseOrder
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(877, 501)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.grpentry)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "PurchaseOrder"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Purchase Order"
        Me.grpentry.ResumeLayout(False)
        Me.grpentry.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpentry As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Private WithEvents lvwPO As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Private WithEvents colItemid As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Private WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colRate As System.Windows.Forms.ColumnHeader
    Private WithEvents colValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colIGST As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Private WithEvents txtRate As System.Windows.Forms.TextBox
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents cmdAddItem As System.Windows.Forms.Button
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents txtItemID As System.Windows.Forms.TextBox
    Private WithEvents dtPODate As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents txtVendor As System.Windows.Forms.TextBox
    Private WithEvents txtPOno As System.Windows.Forms.TextBox
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents colHSN As System.Windows.Forms.ColumnHeader
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents lblcity As System.Windows.Forms.Label
    Private WithEvents lbladd2 As System.Windows.Forms.Label
    Private WithEvents lbladd1 As System.Windows.Forms.Label
    Private WithEvents lblVenName As System.Windows.Forms.Label
    Private WithEvents txtTotalVal As System.Windows.Forms.TextBox
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents txtRoundOff As System.Windows.Forms.TextBox
    Private WithEvents Label19 As System.Windows.Forms.Label
    Private WithEvents txtIGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents txtSGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents txtCGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents txtTaxable As System.Windows.Forms.TextBox
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents txtNetTotal As System.Windows.Forms.TextBox
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents Label36 As System.Windows.Forms.Label
    Private WithEvents cmbItemType As System.Windows.Forms.ComboBox
End Class
