﻿
'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:33
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Option Explicit On
Option Strict On 

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.main
Imports VST.Constants

Public Class Masters

	Public shared Function GetMainMenu(byval parentMenuId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT menu_id, title, description, parent_menu_id, is_active, sort_order FROM public.gen_menu_master WHERE parent_menu_id = " & parentMenuId & " AND is_active = '1' ORDER BY sort_order" 
			GetMainMenu = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetMainMenu
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try
	 End Function	
	 
	 Public shared Function GetCompDetails(byval compId As Integer) As DataSet
	 	Dim strSQL As String 
		Try
			strSQL = "SELECT comp_id, comp_name, comp_add1, comp_add2, comp_state, comp_pin, comp_phone, comp_email, comp_shortname, comp_contactperson, comp_gst, comp_city FROM public.gen_companymaster WHERE comp_id = " & compId 
			GetCompDetails = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetCompDetails
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try
	 End Function
	 
	 Public Shared Function getSysDateTime() As DataSet
	 	Dim strSQL As String
	 	Dim ds As DataSet
	 	Try
	 		strSQL = "SELECT to_char(current_date,'dd-MON-yyyy') AS current_date,to_char(current_timestamp,'HH24MISS') AS current_time"
	 		getSysDateTime = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
	 		ds = getSysDateTime
	 		If ds.Tables(0).Rows.Count > 0 Then
                gSysDate = Date.ParseExact(Format(CDate(ds.Tables(0).Rows(0).Item("current_date").ToString), "yyyy-MMM-dd").ToString, "yyyy-MMM-dd", CultureInfo.InvariantCulture)
                gSysTime = CInt(ds.Tables(0).Rows(0).Item("current_time").ToString)
            End If
	 	Catch ex As Exception
	 		MsgBox(ex.Message, MsgBoxStyle.Critical,"Error")
	 		Return Nothing
	 	End Try
	 End Function
	 
	 Public Shared Function getUserDetails(ByVal userName As String,byval password As String) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT user_id, user_name, password, created_dt, lost_login_dt, lost_login_time, is_active FROM public.gen_user_master WHERE user_name = '" & userName & "' AND password = '" & password & "'"  
			getUserDetails = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetUserDetails
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try	 	
	 End Function
	 
	 Public Shared Function getUom() As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT uom_id, uom_desc, uom_short_desc, is_active FROM public.stk_uom_master WHERE is_active = '1'"  
			getuom = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetUom
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try	 	
	 End Function	
	 
	 Public Shared Function getUom(uomid As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT uom_id, uom_desc, uom_short_desc, is_active FROM public.stk_uom_master WHERE is_active = '1' AND uom_id = " & uomid  
			getuom = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetUom
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try	 	
	 End Function	
	 
	 Public Shared Function getISI() As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT isi_std_id, isi_std_desc, isi_std_short_desc, is_active FROM public.gen_isistd_master WHERE is_active = '1'"  
			getISI = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetISI
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try	 	
	 End Function	 
	 
	 Public Shared Function getISI(isistdId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT isi_std_id, isi_std_desc, isi_std_short_desc, is_active FROM public.gen_isistd_master WHERE is_active = '1' AND isi_std_id = " & isistdId  
			getISI = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return GetISI
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,"Error")
			Return Nothing
		End Try	 	
	 End Function	 
	 
	 Public shared Function getCustomer(optional intCustId As Integer = 0) As DataSet
		Dim strSQL As String 
		Try
			If intCustId > 0 Then
				strSQL = "SELECT cust_name, cust_id, cust_address1, cust_address2, cust_city, cust_state, cust_pin, cust_gst, cust_contact_person, cust_emailid, cust_phone, created_dt, created_tm, created_by, rec_status, is_active FROM public.gen_customer_master WHERE is_active = '1' AND cust_id = " & intCustId & " ORDER BY cust_name"
			Else
                strSQL = "SELECT cust_name AS ""NAME"", cust_id AS ""ID"", cust_address1 AS ""ADDRESS"", cust_address2 ""ADDRESS2"", cust_city AS ""CITY"", cust_state AS ""STATE"", cust_pin AS ""PIN CODE"", cust_gst AS ""GST"" FROM public.gen_customer_master WHERE is_active = '1' ORDER BY cust_name"
            End If
			getCustomer= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getCustomer
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try
	 End Function	
	 
	 Public shared Function getVendor(optional intVenId As Integer = 0) As DataSet
		Dim strSQL As String 
		Try
			If intVenId > 0 Then
				strSQL = "SELECT ven_name, ven_id, ven_address1, ven_address2, ven_city, ven_state, ven_pin, ven_gst, ven_contact_person, ven_emailid, ven_phone, created_dt, created_tm, created_by, rec_status, is_active FROM public.gen_vendor WHERE is_active = '1' AND ven_id = " & intVenId & " ORDER BY ven_name"
			Else
                strSQL = "SELECT ven_name AS ""NAME"", ven_id AS ""ID"", ven_address1 AS ""ADDRESS"", ven_address2 ""ADDRESS2"", ven_city AS ""CITY"", ven_state AS ""STATE"", ven_pin AS ""PIN CODE"", ven_gst AS ""GST"" FROM public.gen_vendor WHERE is_active = '1' ORDER BY ven_name"
            End If
			getVendor= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getVendor
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try
	 End Function

    Public Shared Function getStoppage(Optional intstoppageId As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT stoppage_id, stoppage_dt, mill_id, time_from, time_to, pro_shift, remarks, created_dt, created_tm, created_by, rec_status FROM public.pro_stoppage WHERE  stoppage_id= " & intstoppageId
            getStoppage = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getStoppage
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public shared Function getShipment(optional intShipId As Integer = 0,optional parentCustId As Integer=0) As DataSet
		Dim strSQL As String 
		Try
			If intShipId = 0 And parentCustId = 0 Then
				strSQL = "SELECT cust_name,ship_id, cust_id, ship_address1, ship_address2, ship_city, ship_state, ship_contact_person, ship_phone, created_dt, created_tm, created_by, rec_status, is_active, ship_pin,ship_emailid FROM public.gen_shipping WHERE is_active = '1' ORDER BY cust_name"
			Else If intShipId > 0 And parentCustId > 0 Then
				strSQL = "SELECT cust_name,ship_id, cust_id, ship_address1, ship_address2, ship_city, ship_state, ship_contact_person, ship_phone, created_dt, created_tm, created_by, rec_status, is_active, ship_pin,ship_emailid FROM public.gen_shipping WHERE cust_id = "& parentCustId &" AND ship_id = " & intShipId & " AND is_active = '1' ORDER BY cust_name"
			Else If intShipId > 0 Then
				strSQL = "SELECT cust_name,ship_id, cust_id, ship_address1, ship_address2, ship_city, ship_state, ship_contact_person, ship_phone, created_dt, created_tm, created_by, rec_status, is_active, ship_pin,ship_emailid FROM public.gen_shipping WHERE ship_id = " & intShipId & " AND is_active = '1' ORDER BY cust_name"
			Else
				strSQL = "SELECT cust_name,ship_id, cust_id, ship_address1, ship_address2, ship_city, ship_state, ship_contact_person, ship_phone, created_dt, created_tm, created_by, rec_status, is_active, ship_pin,ship_emailid FROM public.gen_shipping WHERE cust_id = "& parentCustId &" AND is_active = '1' ORDER BY cust_name"
			End If
			
			getShipment= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getShipment
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try
	 End Function

    Public Shared Function getOrder() As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT pro_ord_id, pro_ord_dt, c.cust_name, cust_ord_no, cust_ord_dt, delivery_dt, delivery_id, pro_status, is_jobwork, isi_std_id FROM public.pro_order_hdr p INNER JOIN public.gen_customer_master c ON c.cust_id = p.cust_id ORDER BY p.pro_ord_id"
            getOrder = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getOrder
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getPO() As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT po_id, po_dt, v.ven_name,po_status FROM public.pur_order_hdr p INNER JOIN public.gen_vendor v ON v.ven_id = p.ven_id ORDER BY p.po_id"
            getPO = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getPO
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getCoil(Optional intCoilID As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intCoilID > 0 Then
                strSQL = "SELECT item_description, item_id FROM stk_item_master inner join stk_item_type on stk_item_master.type_id = stk_item_type.item_type_id where stk_item_type.category_id = 1 and item_id = " & intCoilID
            Else
                strSQL = "SELECT item_description, item_id FROM stk_item_master inner join stk_item_type on stk_item_master.type_id = stk_item_type.item_type_id where stk_item_type.category_id = 1"
            End If
            getCoil = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getCoil
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getPOHdr(ByVal poid As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT po_id, po_dt, ven_id, po_status, created_dt, created_tm, created_by, rec_status, roundoff, modify_dt, modify_tm, modify_by	FROM public.pur_order_hdr WHERE po_id = " & poid
            getPOHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getPOHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getPOTrn(ByVal poid As Integer, Optional ByVal itemid As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemid = 0 Then
                strSQL = "SELECT t.po_id, t.po_sno, t.item_id, t.uom_id, t.po_qty, t.po_rate, t.rec_qty, t.cgst, t.sgst, t.igst,u.uom_short_desc FROM public.pur_order_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE po_id = " & poid & " ORDER BY t.po_id,t.po_sno"
            Else
                strSQL = "SELECT t.po_id, t.po_sno, t.item_id, t.uom_id, t.po_qty, t.po_rate, t.rec_qty, t.cgst, t.sgst, t.igst,u.uom_short_desc FROM public.pur_order_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE po_id = " & poid & " AND item_id = " & itemid & " ORDER BY t.po_id,t.po_sno"
            End If

            getPOTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getPOTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function

    Public Shared Function getReceiptHdr(ByVal receiptid As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT pur_receipt_id, pur_receipt_dt, ven_id, ven_invoice_amt, ven_invoice_no, ven_invoice_dt, vehicle_no, lr_no, lr_dt, so_no, so_dt, do_no, do_dt, delivery_no, delivery_dt, bill_discount, freight_charges, other_charges, round_off, remarks, created_dt, created_tm, created_by, modify_dt, modify_tm, modify_by, rec_status FROM public.pur_receipt_hdr WHERE pur_receipt_id = " & receiptid
            getReceiptHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getReceiptHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getReceiptTrn(ByVal receiptid As Integer, Optional ByVal itemid As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemid = 0 Then
                strSQL = "SELECT t.pur_receipt_id, t.sno,t.po_id, t.item_id, t.uom_id, t.coil_id, t.rate, t.quantity, t.received_qty, t.cgst, t.sgst, t.igst,t.discount,u.uom_short_desc FROM public.pur_receipt_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pur_receipt_id = " & receiptid & " ORDER BY t.pur_receipt_id,t.sno"
            Else
                strSQL = "SELECT t.pur_receipt_id, t.sno,t.po_id, t.item_id, t.uom_id, t.coil_id, t.rate, t.quantity, t.received_qty, t.cgst, t.sgst, t.igst,t.discount,u.uom_short_desc FROM public.pur_receipt_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pur_receipt_id = " & receiptid & " AND item_id = " & itemid & " ORDER BY t.pur_receipt_id,t.sno"
            End If

            getReceiptTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getReceiptTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function

    Public Shared Function getInvoiceHdr(ByVal invoiceno As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT invoice_no, invoice_dt, cust_id, ship_id, lr_no, lr_dt, vehicle_no, created_dt, created_tm, created_by, rec_status, bill_discount, freight_charges, other_charges, round_off, remarks	FROM public.inv_sales_hdr WHERE invoice_no = " & invoiceno
            getInvoiceHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getInvoiceHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getInvoiceTrn(ByVal invoiceno As Integer, Optional ByVal itemid As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemid = 0 Then
                strSQL = "SELECT t.invoice_no, t.inv_sno, t.stkcode, t.item_id, t.uom_id, t.quantity, t.rate, t.discount, t.cgst, t.sgst, t.igst, t.qty_innos, t.qty_intones, t.item_good_rejection,u.uom_short_desc FROM public.inv_sales_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE invoice_no = " & invoiceno & " ORDER BY t.invoice_no,t.inv_sno"
            Else
                strSQL = "SELECT t.invoice_no, t.inv_sno, t.stkcode, t.item_id, t.uom_id, t.quantity, t.rate, t.discount, t.cgst, t.sgst, t.igst, t.qty_innos, t.qty_intones, t.item_good_rejection,u.uom_short_desc FROM public.inv_sales_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE invoice_no = " & invoiceno & " AND item_id = " & itemid & " ORDER BY t.invoice_no,t.inv_sno"
            End If

            getInvoiceTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getInvoiceTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function
    Public Shared Function getOrderHdr(ByVal orderId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT pro_ord_id, pro_ord_dt, cust_id, cust_ord_no, cust_ord_dt, delivery_dt, delivery_id, pro_status, is_jobwork, isi_std_id, rec_status FROM public.pro_order_hdr WHERE pro_ord_id = " & orderId  
			getOrderHdr= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getOrderHdr
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try	 	
	 End Function
	 
	 Public Shared Function getOrderTrn(ByVal orderId As Integer,optional itemID As Integer = 0) As DataSet
		Dim strSQL As String 
		Try
			If itemID =0 Then
                strSQL = "SELECT t.pro_ord_id, t.pro_sno, t.item_id, t.uom_id, t.pro_qty, t.pro_rate, t.pro_qty_intones,t.pro_qty_innos,t.pro_qty_inmtrs,t.pro_cgst,t.pro_sgst,t.pro_igst, t.pro_produced_qty, t.pro_shipped_qty, t.rec_status,u.uom_short_desc FROM public.pro_order_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_ord_id = " & orderId & " ORDER BY t.pro_ord_id,t.pro_sno"
            Else
                strSQL = "SELECT t.pro_ord_id, t.pro_sno, t.item_id, t.uom_id, t.pro_qty, t.pro_rate, t.pro_qty_intones,t.pro_qty_innos,t.pro_qty_inmtrs,t.pro_cgst,t.pro_sgst,t.pro_igst, t.pro t.pro_produced_qty, t.pro_shipped_qty, t.rec_status,u.uom_short_desc FROM public.pro_order_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_ord_id = " & orderId & " AND item_id = " & itemID & " ORDER BY t.pro_ord_id,t.pro_sno"
            End If
			
			getOrderTrn= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getOrderTrn
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
			
		End Try	 	
	 End Function	
	 
	 Public Shared Function getPendingOrder(ByVal orderId As Integer,byval planId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT t.pro_ord_id, t.pro_sno, t.item_id, t.uom_id, t.pro_qty, t.pro_rate, t.pro_qty_intones, t.pro_produced_qty, t.pro_shipped_qty, t.rec_status,u.uom_short_desc FROM public.pro_order_trn t inner join stk_uom_master u on u.uom_id = t.uom_id where not exists (select 1 from pro_plan_trn p where p.pro_ord_id = t.pro_ord_id and p.item_id = t.item_id and p.plan_id = "& planId &") and t.pro_ord_id = " & orderId
			getPendingOrder= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getPendingOrder
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
			
		End Try	 	
	 End Function		 
	 
	 
	 Public Shared Function getPlanHdr(ByVal planId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT plan_id, plan_dt, plan_month, created_dt, created_tm, created_by, modified_dt, modified_tm, modified_by, rec_status FROM public.pro_plan_hdr WHERE plan_id = " & planId 
			getPlanHdr= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getPlanHdr
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
		End Try	 	
	 End Function	 
	 
	 Public Shared Function getPlanTrn(ByVal planId As Integer) As DataSet
		Dim strSQL As String 
		Try
			strSQL = "SELECT t.plan_id, t.plan_sno,t.pro_ord_id, t.item_id, t.uom_id, t.pro_qty, t.plan_qty, t.rec_status,u.uom_short_desc,o.pro_produced_qty FROM public.pro_plan_trn t INNER JOIN stk_uom_master u ON u.uom_id = t.uom_id LEFT JOIN pro_order_trn o ON o.pro_ord_id = t.pro_ord_id AND o.item_id = t.item_id WHERE plan_id = "& planId &" ORDER BY t.plan_id,t.plan_sno" 
			getPlanTrn= ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
			Return getPlanTrn
		Catch ex As Exception
			MsgBox(ex.ToString, MsgBoxStyle.Critical,gCompanyShortName)
			Return Nothing
			
		End Try	 	
	 End Function

    Public Shared Function getIssueHdr(ByVal issueId As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT pro_issue_id, pro_issue_dt, pro_machine_id, is_jobwork, customer_id, created_dt, created_tm, created_by, modify_dt, modify_tm, modify_by, rec_status FROM public.pro_issue_hdr WHERE pro_issue_id = " & issueId
            getIssueHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getIssueHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getIssueTrn(ByVal issueId As Integer, Optional itemID As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemID = 0 Then
                strSQL = "SELECT t.pro_issue_id, t.pro_sno, t.stkcode, t.item_id, t.uom_id, t.quantity,u.uom_short_desc FROM public.pro_issue_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_issue_id = " & issueId & " ORDER BY t.pro_issue_id,t.pro_sno"
            Else
                strSQL = "SELECT t.pro_issue_id, t.pro_sno, t.stkcode, t.item_id, t.uom_id, t.quantity,u.uom_short_desc FROM public.pro_issue_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_issue_id = " & issueId & " AND item_id = " & itemID & " ORDER BY t.pro_issue_id,t.pro_sno"
            End If

            getIssueTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getIssueTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function
    Public Shared Function getSlitHdr(ByVal intSlitId As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT pro_slit_id, pro_slit_dt, coil_weight, pro_machine_id, pro_slit_total, created_dt, created_tm, created_by, rec_status, pro_shift, plan_id, coil_id, item_id, stkcode FROM public.pro_slit_hdr WHERE pro_slit_id = " & intSlitId
            getSlitHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getSlitHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getSlitTrn(ByVal intSlitId As Integer, Optional itemID As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemID = 0 Then
                strSQL = "SELECT t.pro_slit_id, t.pro_slit_sno, t.pro_item_id, t.pro_slit_width, t.pro_qty_innos FROM public.pro_slit_trn t WHERE pro_slit_id = " & intSlitId & " ORDER BY t.pro_slit_id,t.pro_slit_sno"
            Else
                strSQL = "SELECT t.pro_slit_id, t.pro_slit_sno, t.pro_item_id, t.pro_slit_width, t.pro_qty_innos FROM public.pro_slit_trn t WHERE pro_slit_id = " & intSlitId & " AND item_id = " & itemID & " ORDER BY t.pro_slit_id,t.pro_slit_sno"
            End If

            getSlitTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getSlitTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function
    Public Shared Function getRollHdr(ByVal intRollId As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT pro_roll_id, pro_roll_dt, pro_machine_id, pro_shift, created_dt, created_tm, created_by, rec_status FROM public.pro_roll_hdr WHERE pro_roll_id = " & intRollId
            getRollHdr = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getRollHdr
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getRollTrn(ByVal intRollId As Integer, Optional itemID As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If itemID = 0 Then
                strSQL = "SELECT t.pro_roll_id, t.pro_sno, t.item_id, t.uom_id, t.pro_qty, t.pro_qty_innos,t.pro_qty_intones, u.uom_short_desc FROM public.pro_roll_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_roll_id = " & intRollId & " ORDER BY t.pro_roll_id,t.pro_sno"
            Else
                strSQL = "SELECT t.pro_roll_id, t.pro_sno, t.item_id, t.uom_id, t.pro_qty, t.pro_qty_innos,t.pro_qty_intones, u.uom_short_desc FROM public.pro_roll_trn t inner join stk_uom_master u on u.uom_id = t.uom_id WHERE pro_roll_id = " & intRollId & " AND item_id = " & itemID & " ORDER BY t.pro_roll_id,t.pro_sno"
            End If

            getRollTrn = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getRollTrn
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing

        End Try
    End Function

    Public Shared Function getItem(Optional intItemId As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intItemId > 0 Then
                strSQL = "SELECT item_description, item_id, type_id, isi_std_id, item_grade, uom_id, item_rate, created_dt, created_tm, created_by, rec_status, is_active, item_size, item_thickness, item_width, item_length, breadth, outerdiameter, unitweight, gst, sgst, cgst, igst, hsn, length_uomid, bundle_nos, slit_width FROM public.stk_item_master WHERE item_id = " & intItemId
            Else
                'strSQL = "SELECT item_description, item_id, type_id, isi_std_id, item_grade, uom_id, item_rate, created_dt, created_tm, created_by, rec_status, is_active, item_size, item_thickness, item_width, item_length, breadth, outerdiameter, unitweight, gst, sgst, cgst, igst, hsn, length_uomid, bundle_nos, slit_width FROM public.stk_item_master WHERE is_active = '1' ORDER BY item_description"
                strSQL = "SELECT item_description as ""DESCRIPTION"",item_id as ""ITEM ID"", item_rate as ""RATE"", hsn as ""HSN"", opening_stk as ""OPENING STOCK"", received as ""RECEIVED"", issued AS ""ISSUED"", opening_stk_innos AS ""OPENING STOCK In NOS"", received_innos AS ""RECEIVED In NOS"", issued_innos AS ""ISSUED In NOS"" FROM public.stk_item_master WHERE is_active='1' ORDER BY item_description"
            End If
            getItem = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getItem
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getItemPaging(pagenum As Integer, pagesize As Integer) As DataSet
        Try
            Dim strSQL As String
            strSQL = "SELECT * FROM ( SELECT item_description as ""DESCRIPTION"",item_id as ""ITEM ID"", item_rate as ""RATE"", hsn as ""HSN"", opening_stk as ""OPENING STOCK"", received as ""RECEIVED"", issued AS ""ISSUED"", opening_stk_innos AS ""OPENING STOCK In NOS"", received_innos AS ""RECEIVED In NOS"", issued_innos AS ""ISSUED In NOS"", ROW_NUMBER() OVER (ORDER BY item_ID) AS ROW FROM public.stk_item_master WHERE is_active='1' ORDER BY item_description) A WHERE row > " & pagenum * pagesize & " and row <= " & (pagenum + 1) * pagesize
            getItemPaging = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getItemPaging
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getItemCust(intCustID As Integer, intItemId As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT item_id, type_id, cust_id FROM public.stk_stock_customer WHERE item_id = " & intItemId & " AND cust_id = " & intCustID
            getItemCust = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getItemCust
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getItemList(intItemTypeId As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT item_description as ""DESCRIPTION"", item_id as ""ITEM ID"", hsn as ""HSN"" FROM public.stk_item_master WHERE type_id = " & intItemTypeId
            getItemList = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getItemList
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Critical, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getSlits(Optional intItemId As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intItemId > 0 Then
                strSQL = "SELECT item_description, item_id, type_id, isi_std_id, item_grade, uom_id, item_rate, created_dt, created_tm, created_by, rec_status, is_active, item_size, item_thickness, item_width, item_length, breadth, outerdiameter, unitweight, gst, sgst, cgst, igst, hsn, length_uomid, slit_width FROM public.stk_item_master WHERE is_active = '1' AND type_id = 2 AND item_id = " & intItemId
            Else
                strSQL = "SELECT item_description as ""DESCRIPTION"", item_id as ""ITEM ID"" FROM public.stk_item_master WHERE is_active = '1' AND type_id = 2 ORDER BY item_description"
            End If
            getSlits = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getSlits
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function getPipes(Optional intItemId As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intItemId > 0 Then
                strSQL = "Select item_description, item_id FROM stk_item_master inner join stk_item_type On stk_item_master.type_id = stk_item_type.item_type_id where stk_item_type.category_id = 3 And item_id = " & intItemId
            Else
                strSQL = "Select item_description as ""DESCRIPTION"" , item_id as ""ITEM ID"" FROM stk_item_master inner join stk_item_type On stk_item_master.type_id = stk_item_type.item_type_id where stk_item_type.category_id = 3 ORDER BY item_description"
            End If
            getPipes = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getPipes
        Catch ex As Exception
            MsgBox(ex.ToString, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getItemType(Optional intTypeId As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intTypeId > 0 Then
                strSQL = "SELECT type_name, type_short_name, item_type_id FROM public.stk_item_type WHERE is_active = '1' AND item_type_id = " & intTypeId & " ORDER BY type_name"
            Else
                strSQL = "SELECT type_name, type_short_name, item_type_id FROM public.stk_item_type WHERE is_active = '1' ORDER BY type_name"
            End If
            getitemType = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getItemType
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function
    Public Shared Function getMill(Optional intMachineID As Integer = 0) As DataSet
        Dim strSQL As String
        Try
            If intMachineID > 0 Then
                strSQL = "SELECT mill_name,mill_id, mill_shortname FROM public.gen_mill_master WHERE is_active = '1' AND mill_id = " & intMachineID & " ORDER BY mill_name"
            Else
                strSQL = "SELECT mill_name,mill_id, mill_shortname FROM public.gen_mill_master WHERE is_active = '1' ORDER BY mill_name"
            End If
            getMill = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getMill
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function

    Public Shared Function chkPlanHdr(ByVal intYear As Integer, ByVal intMonth As Integer) As DataSet
	 	Dim strSQL As String
	 	Try
	 		strSQL = "SELECT plan_id,plan_month,to_char(plan_dt,'YYYY') as planyear FROM pro_plan_hdr WHERE plan_month = " & intMonth & " AND to_char(Plan_dt,'YYYY') = '" & intyear.ToString.Trim & "'"
	 		chkPlanHdr = ODBCDataAccsess.GetDataSet(strSQL,ODBCDataAccsess.DbCon)
	 		Return chkPlanHdr
	 	Catch ex As Exception
	 		MsgBox(ex.Message, MsgBoxStyle.Information,gCompanyShortName)
	 		Return Nothing
	 	End Try
	 End Function

    Public Shared Function updateReceiptInPurchaseOrder(intPono As Integer, intItemID As Integer, dblReceivedQty As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE Pur_order_trn SET rec_qty = COALESCE(rec_qty, 0) + " & dblReceivedQty & " WHERE po_id = " & intPono & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function subtractReceiptInPurchaseOrder(intPono As Integer, intItemID As Integer, dblReceivedQty As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE Pur_order_trn SET rec_qty = COALESCE(rec_qty, 0) - " & dblReceivedQty & " WHERE po_id = " & intPono & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function updateReceiptInStock(intCustomerID As Integer, intItemID As Integer, dblRecQty As Double) As Boolean
        Dim strSQL As String
        Dim ds As DataSet
        ds = getItem(intItemID)
        If ds.Tables(0).Rows.Count > 0 Then
            strSQL = "UPDATE stk_item_master SET received = COALESCE(received, 0) + " & dblRecQty & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
        End If
        ds = getItemCust(intCustomerID, intItemID)
        If ds.Tables(0).Rows.Count > 0 Then
            strSQL = "UPDATE stk_stock_customer SET received_intones = COALESCE(received_intones, 0) + " & dblRecQty & " WHERE item_Id = " & intItemID & " cust_id = " & intCustomerID
        Else
            strSQL = "INSERT INTO stk_stock_customer (cust_id,item_id,received_intones) VALUES (" & intCustomerID & "," & intItemID & "," & dblRecQty & ")"
        End If
        ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
        Return True
    End Function

    Public Shared Function subtractReceiptInStock(intCustomerID As Integer, intItemID As Integer, dblRecQty As Double) As Boolean
        Dim strSQL As String
        Dim ds As DataSet
        ds = getItem(intItemID)
        If ds.Tables(0).Rows.Count > 0 Then
            strSQL = "UPDATE stk_item_master SET received = COALESCE(received, 0) - " & dblRecQty & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
        End If
        ds = getItemCust(intCustomerID, intItemID)
        If ds.Tables(0).Rows.Count > 0 Then
            strSQL = "UPDATE stk_stock_customer SET received_intones = COALESCE(received_intones, 0) - " & dblRecQty & " WHERE item_Id = " & intItemID & " cust_id = " & intCustomerID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
        End If
        Return True
    End Function
    Public Shared Function updateSalesInStock(intCustomerID As Integer, intItemID As Integer, dblQtynos As Double, dblQtyTones As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE stk_stock_customer SET issued = COALESCE(issued, 0) + " & dblQtynos & ",issued_intones = COALESCE(issued_intones, 0) + " & dblQtyTones & " WHERE cust_id = " & intCustomerID & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            strSQL = "UPDATE stk_item_master SET issued = COALESCE(issued, 0) + " & dblQtyTones & ",issued_innos = COALESCE(issued_innos, 0) + " & dblQtynos & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function subtractSalesInStock(intCustomerID As Integer, intItemID As Integer, dblQtynos As Double, dblQtyTones As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE stk_stock_customer SET issued = COALESCE(issued, 0) - " & dblQtynos & ",issued_intones = COALESCE(issued_intones, 0) - " & dblQtyTones & " WHERE cust_id = " & intCustomerID & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            strSQL = "UPDATE stk_item_master SET issued = COALESCE(issued, 0) - " & dblQtyTones & ",issued_innos = COALESCE(issued_innos, 0) - " & dblQtynos & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function updateIssuesInStock(intCustomerID As Integer, intItemID As Integer, dblQtyTones As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE stk_stock_customer SET issued_intones = COALESCE(issued_intones, 0) + " & dblQtyTones & " WHERE cust_id = " & intCustomerID & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            strSQL = "UPDATE stk_item_master SET issued = COALESCE(issued, 0) + " & dblQtyTones & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function subtractIssuesInStock(intCustomerID As Integer, intItemID As Integer, dblQtyTones As Double) As Object
        Dim strSQL As String
        Try
            strSQL = "UPDATE stk_stock_customer SET issued_intones = COALESCE(issued_intones, 0) - " & dblQtyTones & " WHERE cust_id = " & intCustomerID & " AND item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            strSQL = "UPDATE stk_item_master SET issued = COALESCE(issued, 0) - " & dblQtyTones & " WHERE item_Id = " & intItemID
            ODBCDataAccsess.getExecuteQuery(strSQL, ODBCDataAccsess.DbCon)
            Return True
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Function getScode(intTypeID As Integer) As DataSet
        Dim strSQL As String
        Try
            strSQL = "SELECT itemtypecode||lpad(cast(coalesce(itemtypeno,0)+1 as text),8,'0') as StkCode FROM stk_item_type WHERE item_type_id = " & intTypeID
            getScode = ODBCDataAccsess.GetDataSet(strSQL, ODBCDataAccsess.DbCon)
            Return getScode
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return Nothing
        End Try
    End Function
End Class


Public Class DgvControl
    Inherits DataGridView
    Protected Overrides Function ProcessDialogKey(ByVal keyData As Keys) As Boolean
        Dim key As Keys = (keyData And Keys.KeyCode)
        If key = Keys.Enter Then
            Return True
        End If
        Return MyBase.ProcessDialogKey(keyData)
    End Function
End Class
