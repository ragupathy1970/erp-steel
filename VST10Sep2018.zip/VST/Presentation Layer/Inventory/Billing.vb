﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports System.Collections
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production
Public Class Billing
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim i As Integer
    Dim lvw As ListViewItem
    Dim ds1 As DataSet
    Dim ds2 As DataSet
    Dim dblCGSTper As Double
    Dim dblSGSTper As Double
    Dim dblIGSTper As Double
    Dim strHSN As String
    Dim strCustGST As String
    Dim strScode As String
    Dim dblUnitWeight As Double
    Dim dblLength As Double
    Dim intNos As Integer
    Dim dblItemValue As Double = 0
    Dim dblTaxable As Double = 0
    Dim dblRoundOff As Double
    Dim dblTotal As Double
    Dim dblcgsttotal As Double
    Dim dblsgsttotal As Double
    Dim dbligsttotal As Double
    Dim dblTotalVal As Double
    Dim dblCGSTValue As Double
    Dim dblSGSTValue As Double
    Dim dblIGSTValue As Double
    Dim trans As OdbcTransaction
    Dim strSQL As String
    Dim csno As Integer = 0
    Dim chsn As Integer = 1
    Dim cScode As Integer = 2
    Dim citem As Integer = 3
    Dim cuom As Integer = 5
    Dim obj As Object
    Dim cqty As Integer = 6
    Dim crate As Integer = 7
    Dim cValue As Integer = 8
    Dim cDiscount As Integer = 9
    Dim cMt As Integer = 10
    Dim cNos As Integer = 11
    Dim cCGST As Integer = 12
    Dim cSGST As Integer = 13
    Dim cIGST As Integer = 14
    Dim cGoodorRej As Integer = 15
    Dim cSlnoKey As Integer = 16
    Dim cUomKey As Integer = 17
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim intBundles As Integer = 0
    Dim editFlag As Boolean = False
    Dim MyArrayList As New ArrayList

    Private Sub Billing_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ds = getUom()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbUom.DataSource = ds.Tables(0)
            cmbUom.DisplayMember = "uom_short_desc"
            cmbUom.ValueMember = "uom_id"
        End If
        ds = getItemType()
        If ds.Tables(0).Rows.Count > 0 Then
            cmbItemType.DataSource = ds.Tables(0)
            cmbItemType.DisplayMember = "type_name"
            cmbItemType.ValueMember = "item_type_id"
        End If

        MyArrayList.Add(New cListItem("Good", 1))
        MyArrayList.Add(New cListItem("Rejected", 2))
        cmbgoodrej.DataSource = MyArrayList
        cmbgoodrej.DisplayMember = "Text"
        cmbgoodrej.ValueMember = "Value"
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
    End Sub

    Sub InitializeControls()
        Call getSysDateTime()
        dtInvoiceDate.Value = gSysDate
        dtLrDate.Value = gSysDate
        cmbUom.Text = ""
        cmbgoodrej.SelectedIndex = -1
        txtInvoiceNo.Text = ""
        txtCustomerID.Text = ""
        txtShipmentID.Text = ""
        txtPONo.Text = ""
        txtVehicleNo.Text = ""
        txtLrNo.Text = ""
        txtPONo.Text = ""
        txtScode.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtRate.Text = ""
        txtDiscount.Text = ""
        txtUOM.Text = ""
        lvwSales.Items.Clear()
        txtBillDiscount.Text = ""
        txtRemarks.Text = ""
        txtFrieghtCharges.Text = ""
        txtOtherCharges.Text = ""
        txtTotalVal.Text = ""
        txtTaxable.Text = ""
        txtRoundOff.Text = ""
        txtNetTotal.Text = ""
        txtCGSTTotal.Text = ""
        txtSGSTTotal.Text = ""
        txtIGSTTotal.Text = ""
        lblcustName.Text = ""
        lbladd1.Text = ""
        lbladd2.Text = ""
        lblcity.Text = ""
        i = 0
        dblCGSTper = 0
        dblSGSTper = 0
        dblIGSTper = 0
        strHSN = ""
        dblItemValue = 0
        dblTaxable = 0
        dblRoundOff = 0
        dblTotal = 0
        dblcgsttotal = 0
        dblsgsttotal = 0
        dbligsttotal = 0
        dblTotalVal = 0
        dblCGSTValue = 0
        dblSGSTValue = 0
        dblIGSTValue = 0
        intBundles = 0
        intDelRecSno = 0
        thisScreenMode = ScreenMode.Add
    End Sub
    Sub EnableDisable(toggle As Boolean)
        txtInvoiceNo.Enabled = Not toggle
        dtInvoiceDate.Enabled = toggle
        dtLrDate.Enabled = toggle
        cmbUom.Enabled = toggle
        txtCustomerID.Enabled = toggle
        txtShipmentID.Enabled = toggle
        txtPONo.Enabled = toggle
        txtVehicleNo.Enabled = toggle
        txtLrNo.Enabled = toggle
        txtPONo.Enabled = toggle
        txtScode.Enabled = toggle
        txtDescription.Enabled = False
        txtQty.Enabled = toggle
        txtRate.Enabled = toggle
        txtDiscount.Enabled = toggle
        lvwSales.Enabled = toggle
        txtBillDiscount.Enabled = False
        txtRemarks.Enabled = toggle
        txtFrieghtCharges.Enabled = False
        txtOtherCharges.Enabled = False
        grpEntry.Enabled = True
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
        cmdSave.Enabled = True
        cmdCancel.Enabled = True

    End Sub

    Public Sub clearItem()
        txtItemID.Text = ""
        txtScode.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtRate.Text = ""
        txtDiscount.Text = ""
        cmbUom.Text = ""
        txtUOM.Text = ""
    End Sub
    Private Sub txtItemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                'ds = getItem()
                If cmbgoodrej.Text = "" Then
                    MsgBox("Please select item type GOOD or REJECTED", MsgBoxStyle.Information, gCompanyShortName)
                    cmbgoodrej.Focus()
                    Exit Sub
                End If
                If cmbgoodrej.SelectedValue = 1 Then
                    ds = getItemList(cmbItemType.SelectedValue)
                Else
                    'ds = getItemListRej(cmbItemType.SelectedValue)
                End If
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemID.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemID.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemID.Text = "" Then
                If cmbgoodrej.Text = "" Then
                    MsgBox("Please select item type GOOD or REJECTED", MsgBoxStyle.Information, gCompanyShortName)
                    cmbgoodrej.Focus()
                    Exit Sub
                End If
                ds1 = getItem(CInt(txtItemID.Text))
                Call populateItemDesc(ds1)
            End If
        End If
    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
            strHSN = ds2.Tables(0).Rows(0).Item("hsn").ToString
            dblCGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("cgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("cgst").ToString)))
            dblSGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("sgst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("sgst").ToString)))
            dblIGSTper = CDbl(IIf(IsDBNull(ds2.Tables(0).Rows(0).Item("igst").ToString), 0, Val(ds2.Tables(0).Rows(0).Item("igst").ToString)))
        Else
            dblIGSTper = 0
            dblSGSTper = 0
            dblCGSTper = 0
            MsgBox("No item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If

    End Sub

    Private Sub Billing_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveSales()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
        If e.KeyCode = Keys.F2 Then
            'Call populateSalesToEntry()
        End If
    End Sub

    Public Sub saveSales()
        Try
            If validateSales() Then
                'If validateItem() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "Select nextval('inv_sales_id_seq') AS inv_sales_id"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        txtInvoiceNo.Text = obj.ToString
                        'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call insertSalesHdr()
                        Call insertSalesTrn()
                        'trans.Commit()
                    Case 2
                        Call updateSalesHdr()
                        Call updateSalesTrn()

                    Case 3
                        If MsgBox("Are you sure you want to delete this sales invoice ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteSalesTrn()
                            Call deleteSalesHdr()
                            'trans.Commit()

                        End If

                End Select
                Call InitializeControls()
                EnableDisable(True)
            End If
            'End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
                EnableDisable(True)
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub insertSalesHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertSalesHdr(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = Val(txtInvoiceNo.Text)
            dt = Date.ParseExact(Format(CDate(dtInvoiceDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@invoicedt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = Val(txtCustomerID.Text.Trim())
            cmd.Parameters.AddWithValue("@shipid", OdbcType.Int).Value = Val(txtShipmentID.Text.Trim())
            cmd.Parameters.AddWithValue("@vehicleno", OdbcType.NText).Value = txtVehicleNo.Text
            cmd.Parameters.AddWithValue("@lrno", OdbcType.NText).Value = txtLrNo.Text
            dt = Date.ParseExact(Format(CDate(dtLrDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@lrdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@billdiscount", OdbcType.Decimal).Value = Val(txtBillDiscount.Text)
            cmd.Parameters.AddWithValue("@freightcharges", OdbcType.Decimal).Value = Val(txtFrieghtCharges.Text)
            cmd.Parameters.AddWithValue("@othercharges", OdbcType.Decimal).Value = Val(txtOtherCharges.Text)
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = Val(txtRoundOff.Text)
            cmd.Parameters.AddWithValue("@remarks", OdbcType.NText).Value = txtRemarks.Text.Trim
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub insertSalesTrn()
        Dim cmd As New OdbcCommand()
        Dim dblqtynos As Integer
        Dim dblqtytones As Double
        Dim intItemId As Integer
        Try
            For n = 0 To lvwSales.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertSalesTrn(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text.Trim())
                cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(citem).Text)
                cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(cUomKey).Text)
                cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cqty).Text)
                cmd.Parameters.AddWithValue("@srate", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(crate).Text)
                cmd.Parameters.AddWithValue("@sdiscount", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cDiscount).Text)
                cmd.Parameters.AddWithValue("@scgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cCGST).Text)
                cmd.Parameters.AddWithValue("@ssgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cSGST).Text)
                cmd.Parameters.AddWithValue("@sigst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cIGST).Text)
                cmd.Parameters.AddWithValue("@qtynos", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cNos).Text)
                cmd.Parameters.AddWithValue("@qtytones", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cMT).Text)
                cmd.Parameters.AddWithValue("@goodorrej", OdbcType.Int).Value = IIf(lvwSales.Items(n).SubItems(cGoodorRej).Text.Trim = "Good", 1, 2)
                cmd.ExecuteScalar()
                dblqtynos = Val(lvwSales.Items(n).SubItems(cNos).Text)
                dblqtytones = Val(lvwSales.Items(n).SubItems(cMt).Text)
                intItemID = CInt(lvwSales.Items(n).SubItems(citem).Text)
                Call updateSalesInStock(txtCustomerID.Text, intItemID, dblQtynos, dblQtyTones)
            Next
            MsgBox("Invoce : " & txtInvoiceNo.Text & " created")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateSalesHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateSalesHdr(?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text)
            dt = Date.ParseExact(Format(CDate(dtInvoiceDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@invoicedt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = Val(txtCustomerID.Text.Trim())
            cmd.Parameters.AddWithValue("@shipid", OdbcType.Int).Value = Val(txtShipmentID.Text.Trim())
            cmd.Parameters.AddWithValue("@vehicleno", OdbcType.NText).Value = txtVehicleNo.Text
            cmd.Parameters.AddWithValue("@lrno", OdbcType.NText).Value = txtLrNo.Text
            dt = Date.ParseExact(Format(CDate(dtLrDate.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@lrdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@billdiscount", OdbcType.Decimal).Value = Val(txtBillDiscount.Text)
            cmd.Parameters.AddWithValue("@freightcharges", OdbcType.Decimal).Value = Val(txtFrieghtCharges.Text)
            cmd.Parameters.AddWithValue("@othercharges", OdbcType.Decimal).Value = Val(txtOtherCharges.Text)
            cmd.Parameters.AddWithValue("@roundoff", OdbcType.Decimal).Value = Val(txtRoundOff.Text)
            cmd.Parameters.AddWithValue("@remarks", OdbcType.NText).Value = txtRemarks.Text.Trim
            'cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = format(gSysDate,"yyyyMMMdd")
            'cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            'cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Sub updateSalesTrn()
        Dim cmd As New OdbcCommand
        Dim dblqtynos As Integer
        Dim dblqtytones As Double
        Dim intItemId As Integer
        Try
            ds = getInvoiceTrn(CInt(txtInvoiceNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    dblqtynos = Val(ds.Tables(0).Rows(n).Item("qty_innos").ToString)
                    dblqtytones = Val(ds.Tables(0).Rows(n).Item("qty_intones").ToString)
                    Call subtractSalesInStock(CInt(txtCustomerID.Text), intItemId, dblqtynos, dblqtytones)
                Next
            End If
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delSalesTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@receiptid", OdbcType.Int).Value = CInt(txtInvoiceNo.Text)
                    cmd.Parameters.AddWithValue("@rsno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwSales.Items.Count - 1
                If Not lvwSales.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateSalesTrn(?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@srate", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@sdiscount", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cDiscount).Text)
                    cmd.Parameters.AddWithValue("@scgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@ssgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@sigst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@qtynos", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cNos).Text)
                    cmd.Parameters.AddWithValue("@qtytones", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cMt).Text)
                    cmd.Parameters.AddWithValue("@goodorrej", OdbcType.Int).Value = IIf(lvwSales.Items(n).SubItems(cGoodorRej).Text.Trim = "Good", 1, 2)
                    cmd.Parameters.AddWithValue("@oldSlno", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                    dblqtynos = Val(lvwSales.Items(n).SubItems(cNos).Text)
                    dblqtytones = Val(lvwSales.Items(n).SubItems(cMt).Text)
                    intItemId = CInt(lvwSales.Items(n).SubItems(citem).Text)
                    Call updateSalesInStock(txtCustomerID.Text, intItemId, dblqtynos, dblqtytones)
                End If
            Next
            For n = 0 To lvwSales.Items.Count - 1
                If lvwSales.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertSalesTrn(?,?,?,?,?,?,?,?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text.Trim())
                    cmd.Parameters.AddWithValue("@sno", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(citem).Text)
                    cmd.Parameters.AddWithValue("@uomid", OdbcType.Int).Value = CInt(lvwSales.Items(n).SubItems(cUomKey).Text)
                    cmd.Parameters.AddWithValue("@qty", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cqty).Text)
                    cmd.Parameters.AddWithValue("@srate", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(crate).Text)
                    cmd.Parameters.AddWithValue("@sdiscount", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cDiscount).Text)
                    cmd.Parameters.AddWithValue("@scgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cCGST).Text)
                    cmd.Parameters.AddWithValue("@ssgst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cSGST).Text)
                    cmd.Parameters.AddWithValue("@sigst", OdbcType.Double).Value = Val(lvwSales.Items(n).SubItems(cIGST).Text)
                    cmd.Parameters.AddWithValue("@qtynos", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cNos).Text)
                    cmd.Parameters.AddWithValue("@qtytones", OdbcType.Int).Value = Val(lvwSales.Items(n).SubItems(cMt).Text)
                    cmd.Parameters.AddWithValue("@goodorrej", OdbcType.Int).Value = IIf(lvwSales.Items(n).SubItems(cGoodorRej).Text.Trim = "Good", 1, 2)
                    cmd.ExecuteScalar()
                    dblqtynos = Val(lvwSales.Items(n).SubItems(cNos).Text)
                    dblqtytones = Val(lvwSales.Items(n).SubItems(cMt).Text)
                    intItemId = CInt(lvwSales.Items(n).SubItems(citem).Text)
                    Call updateSalesInStock(txtCustomerID.Text, intItemId, dblqtynos, dblqtytones)
                End If
            Next

            'Call setSerialNumbers
            MsgBox("Invoice number modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteSalesHdr()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteSalesHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteSalesTrn()
        Try
            Dim cmd As New OdbcCommand
            Dim dblqtynos As Integer
            Dim dblqtytones As Double
            Dim intItemId As Integer
            Dim ds As DataSet
            ds = getInvoiceTrn(CInt(txtInvoiceNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds.Tables(0).Rows(n).Item("item_id").ToString)
                    dblqtynos = Val(ds.Tables(0).Rows(n).Item("qty_innos").ToString)
                    dblqtytones = Val(ds.Tables(0).Rows(n).Item("qty_intones").ToString)
                    Call subtractSalesInStock(CInt(txtCustomerID.Text), intItemId, dblqtynos, dblqtytones)
                Next
            End If
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteSalesTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@invoiceno", OdbcType.Int).Value = CInt(txtInvoiceNo.Text)
            cmd.ExecuteScalar()
            MsgBox("Invoice : " & txtInvoiceNo.Text & " Deleted")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Private Function validateSales() As Boolean
        If thisScreenMode = ScreenMode.Delete Or thisScreenMode = ScreenMode.Edit Then
            If txtInvoiceNo.Text = "" Then
                MsgBox("Please enter invoice number", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
        Else
            If txtCustomerID.Text = "" Then
                MsgBox("Customer ID should not be empty", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerID.Focus()
                Return False
                Exit Function
            End If
            If lvwSales.Items.Count = 0 Then
                MsgBox("Please add sales item", MsgBoxStyle.Information, gCompanyShortName)
                txtScode.Focus()
                Return False
                Exit Function
            End If
        End If
        Return True
    End Function
    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        'If editFlag = False Then
        InvoiceAddItem()
        'End If
    End Sub

    Sub updateInvoiceItem()
        ds1 = getItem(Val(txtScode.Text))
        Call populateItemDesc(ds1)
        dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
        lvw = lvwSales.Items.Add(i.ToString)
        lvw.SubItems.Add(strHSN)
        lvw.SubItems.Add(txtScode.Text.ToString)
        lvw.SubItems.Add(txtItemID.Text.ToString)
        lvw.SubItems.Add(txtDescription.Text.ToString)
        lvw.SubItems.Add(cmbUom.Text.ToString)
        lvw.SubItems.Add(txtQty.Text.ToString)
        lvw.SubItems.Add(txtRate.Text.ToString)
        lvw.SubItems.Add(Format(dblItemValue, "#0.00"))
        lvw.SubItems.Add(txtDiscount.Text.ToString)
        Select Case cmbUom.Text.Trim
            Case "MT"
                lvw.SubItems.Add(txtQty.Text) 'mtns
                lvw.SubItems.Add(txtUOM.Text.ToString()) ' nos
            Case "Nos"
                lvw.SubItems.Add(txtUOM.Text.ToString) 'mtns
                lvw.SubItems.Add(txtQty.Text) ' nos
            Case "Kgs"
                lvw.SubItems.Add(Val(txtQty.Text) / 1000) 'mtns
                lvw.SubItems.Add(txtUOM.Text.ToString) 'nos
            Case Else
                lvw.SubItems.Add("")
                lvw.SubItems.Add("")
        End Select
        dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
        dblTaxable = dblTaxable - Val(txtDiscount.Text)
        dblItemValue = dblItemValue - Val(txtDiscount.Text)
        If Mid(strCustGST, 1, 2) = "33" Or strCustGST = "" Then
            dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
            dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
            lvw.SubItems.Add(Format(dblCGSTValue, "#0.00"))
            lvw.SubItems.Add(Format(dblSGSTValue, "#0.00"))
            lvw.SubItems.Add("")
        Else
            dblIGSTValue = Math.Round(dblItemValue * dblIGSTper / 100, 2)
            lvw.SubItems.Add("")
            lvw.SubItems.Add("")
            lvw.SubItems.Add(Format(dblIGSTValue, "#0.00"))
        End If
        lvw.SubItems.Add("")
        lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
        dblcgsttotal = dblcgsttotal + dblCGSTValue
        dblsgsttotal = dblsgsttotal + dblSGSTValue
        dbligsttotal = dbligsttotal + dblIGSTValue
        dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
        dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
        dblTotal = dblTotalVal - dblRoundOff
        txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
        txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
        txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
        txtTaxable.Text = Format(dblTaxable, "#0.00")
        txtTotalVal.Text = Format(dblTotalVal, "#0.00")
        txtRoundOff.Text = Format(dblRoundOff, "#0.00")
        txtNetTotal.Text = Format(dblTotal, "#0.00")
        editFlag = False
        Call clearItem()
    End Sub

    Sub InvoiceAddItem()
        Try
            If validateItem() Then
                i += 1
                dblItemValue = CDbl(txtQty.Text) * CDbl(txtRate.Text)
                lvw = lvwSales.Items.Add(i.ToString)
                lvw.SubItems.Add(strHSN)
                lvw.SubItems.Add(txtScode.Text.ToString)
                lvw.SubItems.Add(txtItemID.Text.ToString)
                lvw.SubItems.Add(txtDescription.Text.ToString)
                lvw.SubItems.Add(cmbUom.Text.ToString)
                lvw.SubItems.Add(txtQty.Text.ToString)
                lvw.SubItems.Add(txtRate.Text.ToString)
                lvw.SubItems.Add(Format(dblItemValue, "#0.00"))
                lvw.SubItems.Add(txtDiscount.Text.ToString)
                Select Case cmbUom.Text.Trim
                    Case "MT"
                        lvw.SubItems.Add(txtQty.Text) 'mtns
                        lvw.SubItems.Add(txtUOM.Text.ToString()) ' nos
                    Case "Nos"
                        lvw.SubItems.Add(txtUOM.Text.ToString) 'mtns
                        lvw.SubItems.Add(txtQty.Text) ' nos
                    Case "Kgs"
                        lvw.SubItems.Add(Val(txtQty.Text) / 1000) 'mtns
                        lvw.SubItems.Add(txtUOM.Text.ToString) 'nos
                    Case Else
                        lvw.SubItems.Add("")
                        lvw.SubItems.Add("")
                End Select
                dblTaxable = dblTaxable + CDbl(txtQty.Text) * CDbl(txtRate.Text)
                dblTaxable = dblTaxable - Val(txtDiscount.Text)
                dblItemValue = dblItemValue - Val(txtDiscount.Text)
                If Mid(strCustGST, 1, 2) = "33" Or strCustGST = "" Then
                    dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
                    dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
                    lvw.SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    lvw.SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    lvw.SubItems.Add("")
                Else
                    dblIGSTValue = Math.Round(dblItemValue * dblIGSTper / 100, 2)
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add("")
                    lvw.SubItems.Add(Format(dblIGSTValue, "#0.00"))
                End If
                lvw.SubItems.Add(IIf(cmbgoodrej.SelectedValue = 1, "Good", "Rejected"))
                lvw.SubItems.Add("")
                lvw.SubItems.Add(cmbUom.SelectedValue.ToString)
                dblcgsttotal = dblcgsttotal + dblCGSTValue
                dblsgsttotal = dblsgsttotal + dblSGSTValue
                dbligsttotal = dbligsttotal + dblIGSTValue
                dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
                dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                dblTotal = dblTotalVal - dblRoundOff
                txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
                txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
                txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
                txtTaxable.Text = Format(dblTaxable, "#0.00")
                txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                txtNetTotal.Text = Format(dblTotal, "#0.00")
                Call clearItem()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Function validateItem() As Boolean
        If txtItemID.Text.Trim = "" Then
            MsgBox("Please Enter Item Id", MsgBoxStyle.Information, gCompanyShortName)
            txtScode.Focus()
            Return False
            Exit Function
        End If
        If cmbUom.Text = "" Then
            MsgBox("Please Select UOM", MsgBoxStyle.Information, gCompanyShortName)
            cmbUom.Focus()
            Return False
            Exit Function
        End If
        If txtRate.Text = "" Then
            MsgBox("Please Enter Rate", MsgBoxStyle.Information, gCompanyShortName)
            txtRate.Focus()
            Return False
            Exit Function
        End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Quantity", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
            Exit Function
        End If
        Return True
    End Function
    Private Sub txtItemID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtQty.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtRate_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtRate.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtRate.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtDiscount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtDiscount.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtDiscount.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtPono_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPONo.KeyPress

        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtInvoiceNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtInvoiceNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtInvoiceNo.Text <> "" Then
            ds = getInvoiceHdr(CInt(txtInvoiceNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateInvoiceHdr(CInt(txtInvoiceNo.Text))
                Call populateInvoiceTrn(CInt(txtInvoiceNo.Text))
                Call EnableDisable(True)
                cmdEdit.Enabled = False
                cmdDelete.Enabled = False
            Else
                MsgBox("No Record Found In This Invoice Number", MsgBoxStyle.Information, gCompanyShortName)
                txtInvoiceNo.Focus()
            End If

        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Sub populateInvoiceHdr(intInvoiceID As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            dtInvoiceDate.Text = ds.Tables(0).Rows(0).Item("invoice_dt").ToString
            txtCustomerID.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
            txtShipmentID.Text = ds.Tables(0).Rows(0).Item("ship_id").ToString
            txtVehicleNo.Text = ds.Tables(0).Rows(0).Item("vehicle_no").ToString
            txtLrNo.Text = ds.Tables(0).Rows(0).Item("lr_no").ToString
            dtLrDate.Text = ds.Tables(0).Rows(0).Item("lr_dt").ToString
            txtBillDiscount.Text = ds.Tables(0).Rows(0).Item("bill_discount").ToString
            txtFrieghtCharges.Text = ds.Tables(0).Rows(0).Item("freight_charges").ToString
            txtOtherCharges.Text = ds.Tables(0).Rows(0).Item("other_charges").ToString
            txtRoundOff.Text = ds.Tables(0).Rows(0).Item("round_off").ToString
            txtRemarks.Text = ds.Tables(0).Rows(0).Item("remarks").ToString
            ds1 = getCustomer(Val(txtCustomerID.Text))
            populateCustAddress(ds1)
            If Val(txtShipmentID.Text) > 0 Then
                ds1 = getShipment(Val(txtShipmentID.Text))
                populateShipAddress(ds1)
            End If
        End If
    End Sub


    Sub populateInvoiceTrn(intInvoiceID As Integer)
        ds = getInvoiceTrn(intInvoiceID)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                dblCGSTValue = 0
                dblSGSTValue = 0
                dblIGSTValue = 0
                lvw = lvwSales.Items.Add(ds.Tables(0).Rows(n).Item("inv_sno").ToString)
                With lvw
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("hsn").ToString)
                        .SubItems.Add("")
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_short_desc").ToString)
                    Select Case ds.Tables(0).Rows(n).Item("uom_short_desc").ToString
                        Case "Nos"
                            .SubItems.Add(Format(Val(ds.Tables(0).Rows(n).Item("quantity").ToString), "#0"))
                        Case Else
                            .SubItems.Add(ds.Tables(0).Rows(n).Item("quantity").ToString)
                    End Select
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("rate").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("quantity")) Then
                        .SubItems.Add("")
                    Else
                        .SubItems.Add(Format(CDbl(ds.Tables(0).Rows(n).Item("rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("quantity").ToString), "#0.00"))
                    End If
                    If Val(ds.Tables(0).Rows(n).Item("discount").ToString) > 0 Then
                        .SubItems.Add(ds.Tables(0).Rows(n).Item("discount").ToString)
                    Else
                        .SubItems.Add("0")
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("qty_intones").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("qty_innos").ToString)
                    dblCGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("cgst")), 0, ds.Tables(0).Rows(n).Item("cgst").ToString))
                    .SubItems.Add(Format(dblCGSTValue, "#0.00"))
                    dblSGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("sgst")), 0, ds.Tables(0).Rows(n).Item("sgst").ToString))
                    .SubItems.Add(Format(dblSGSTValue, "#0.00"))
                    dblIGSTValue = CDbl(IIf(IsDBNull(ds.Tables(0).Rows(n).Item("igst")), 0, ds.Tables(0).Rows(n).Item("igst").ToString))
                    .SubItems.Add(Format(dblIGSTValue, "#0.00"))
                    .SubItems.Add(IIf(val(ds.Tables(0).Rows(n).Item("item_good_rejection").ToString) = 1, "Good", "Rejection"))
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("inv_sno").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("uom_id").ToString)
                    If IsDBNull(ds.Tables(0).Rows(n).Item("rate")) Or IsDBNull(ds.Tables(0).Rows(n).Item("quantity")) Then
                    Else
                        dblTaxable = dblTaxable + CDbl(ds.Tables(0).Rows(n).Item("rate").ToString) * CDbl(ds.Tables(0).Rows(n).Item("quantity").ToString)
                        dblcgsttotal = dblcgsttotal + dblCGSTValue
                        dblsgsttotal = dblsgsttotal + dblSGSTValue
                        dbligsttotal = dbligsttotal + dblIGSTValue
                        dblCGSTValue = 0
                        dblSGSTValue = 0
                        dblIGSTValue = 0
                    End If

                End With
                i += 1
            Next
            dblTotalVal = dblTotalVal + dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
            dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
            dblTotal = dblTotalVal - dblRoundOff
            txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
            txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
            txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
            txtTaxable.Text = Format(dblTaxable, "#0.00")
            txtTotalVal.Text = Format(dblTotalVal, "#0.00")
            txtRoundOff.Text = Format(dblRoundOff, "#0.00")
            txtNetTotal.Text = Format(dblTotal, "#0.00")

        End If
    End Sub
    Private Sub txtBillDiscount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtBillDiscount.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtBillDiscount.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtFrieghtCharges_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtFrieghtCharges.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtFrieghtCharges.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtOtherCharges_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtOtherCharges.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
                If InStr(txtOtherCharges.Text, ".") > 0 Then
                    e.KeyChar = Nothing
                End If
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub cmbUom_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbUom.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbUom.Text
        Dim typedT As String = t.Substring(0, cmbUom.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbUom.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub txtPono_KeyDown(sender As Object, e As KeyEventArgs) Handles txtPONo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getPO()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtPONo.Text = rTagValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Order Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtInvoiceNo.Focus()
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        grpEntry.Enabled = False
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtInvoiceNo.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveSales()
    End Sub

    Private Sub lvwSales_KeyDown(sender As Object, e As KeyEventArgs) Handles lvwSales.KeyDown
        If e.KeyCode = 46 Then
            Try
                If Not lvwSales.SelectedItems Is Nothing Then
                    If MsgBox("Are You Sure You Want To Delete ? ", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                        dblItemValue = (CDbl(lvwSales.SelectedItems(0).SubItems(crate).Text) * CDbl(lvwSales.SelectedItems(0).SubItems(cqty).Text))
                        ds1 = getItem(CInt(lvwSales.SelectedItems(0).SubItems(citem).Text.ToString))
                        If ds1.Tables(0).Rows.Count > 0 Then
                            dblCGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("cgst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("cgst").ToString)))
                            dblSGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("sgst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("sgst").ToString)))
                            dblIGSTper = CDbl(IIf(IsDBNull(ds1.Tables(0).Rows(0).Item("igst").ToString), 0, Val(ds1.Tables(0).Rows(0).Item("igst").ToString)))
                        End If
                        dblTotal = dblTotal - dblItemValue
                        dblCGSTValue = Math.Round(dblItemValue * dblCGSTper / 100, 2)
                        dblSGSTValue = Math.Round(dblItemValue * dblSGSTper / 100, 2)
                        dblcgsttotal = dblcgsttotal - dblCGSTValue
                        dblsgsttotal = dblsgsttotal - dblSGSTValue
                        dbligsttotal = dbligsttotal - dblIGSTValue
                        dblTotalVal = dblTaxable + dblcgsttotal + dblsgsttotal + dbligsttotal
                        dblRoundOff = Math.Round(dblTotalVal, 2) - CInt((dblTotalVal))
                        dblTotal = dblTotalVal - dblRoundOff
                        txtCGSTTotal.Text = Format(dblcgsttotal, "#0.00")
                        txtSGSTTotal.Text = Format(dblsgsttotal, "#0.00")
                        txtIGSTTotal.Text = Format(dbligsttotal, "#0.00")
                        txtTaxable.Text = Format(dblTaxable, "#0.00")
                        txtTotalVal.Text = Format(dblTotalVal, "#0.00")
                        txtRoundOff.Text = Format(dblRoundOff, "#0.00")
                        txtNetTotal.Text = Format(dblTotal, "#0.00")
                        If thisScreenMode = ScreenMode.Edit Then
                            If Not Val(lvwSales.SelectedItems(0).SubItems(cSlnoKey).Text.ToString) = 0 Then
                                intDelRecSno += 1
                                ReDim Preserve arrDelTrn(intDelRecSno)
                                arrDelTrn(intDelRecSno) = lvwSales.SelectedItems(0).SubItems(cSlnoKey).Text.ToString
                            End If
                        End If
                        lvwSales.Items.RemoveAt(lvwSales.SelectedItems(0).Index)
                        Call setSlno()
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub setSlno()
        i = 0
        For n = 0 To lvwSales.Items.Count - 1
            i += 1
            lvwSales.Items(n).Text = i.ToString
        Next
    End Sub

    Private Sub txtFrieghtCharges_TextChanged(sender As Object, e As EventArgs) Handles txtFrieghtCharges.TextChanged
        txtTaxable.Text = dblTaxable.ToString
        txtTaxable.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text)
        If Mid(strCustGST, 1, 2) = "33" Or strCustGST = "" Then
            txtCGSTTotal.Text = Val(txtTaxable.Text) * 0.09
            txtSGSTTotal.Text = Val(txtTaxable.Text) * 0.09
        Else
            txtIGSTTotal.Text = Val(txtTaxable.Text) * 0.18
        End If
        txtNetTotal.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text) + Val(txtCGSTTotal.Text) + Val(txtSGSTTotal.Text) + Val(txtIGSTTotal.Text)
    End Sub

    Private Sub txtOtherCharges_TextChanged(sender As Object, e As EventArgs) Handles txtOtherCharges.TextChanged
        txtTaxable.Text = dblTaxable.ToString
        txtTaxable.Text = Val(txtTaxable.Text) + Val(txtOtherCharges.Text) + Val(txtFrieghtCharges.Text)
        If Mid(strCustGST, 1, 2) = "33" Or strCustGST = "" Then
            txtCGSTTotal.Text = Val(txtTaxable.Text) * 0.09
            txtSGSTTotal.Text = Val(txtTaxable.Text) * 0.09
        Else
            txtIGSTTotal.Text = Val(txtTaxable.Text) * 0.18
        End If
        txtNetTotal.Text = Val(txtTaxable.Text) + Val(txtFrieghtCharges.Text) + Val(txtOtherCharges.Text) + Val(txtCGSTTotal.Text) + Val(txtSGSTTotal.Text) + Val(txtIGSTTotal.Text)
    End Sub

    Sub populateSalesToEntry()
        If Not lvwSales.SelectedItems Is Nothing Then
            editFlag = True
            txtScode.Text = lvwSales.SelectedItems(0).SubItems(citem).Text
            ds1 = getItem(CInt(txtScode.Text))
            txtDescription.Text = ds1.Tables(0).Rows(0).Item("item_description").ToString
            cmbUom.Text = lvwSales.SelectedItems(0).SubItems(cuom).Text
            txtQty.Text = lvwSales.SelectedItems(0).SubItems(cqty).Text
            txtRate.Text = lvwSales.SelectedItems(0).SubItems(crate).Text
            txtDiscount.Text = lvwSales.SelectedItems(0).SubItems(cDiscount).Text
        End If
    End Sub

    Private Sub lvwSales_DoubleClick(sender As Object, e As EventArgs) Handles lvwSales.DoubleClick
        'Call populateSalesToEntry()
    End Sub

    Private Sub txtCustomerID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Customer Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtCustomerID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtCustomerID_Leave(sender As Object, e As EventArgs) Handles txtCustomerID.Leave
        If Not txtCustomerID.Text = "" Then
            ds1 = getCustomer(Val(txtCustomerID.Text))
            Call populateCustAddress(ds1)
        End If
    End Sub
    Public Sub populateCustAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblcustName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
            lbladd1.Text = ds2.Tables(0).Rows(0).Item("cust_address1").ToString
            lbladd2.Text = ds2.Tables(0).Rows(0).Item("cust_address2").ToString
            lblcity.Text = ds2.Tables(0).Rows(0).Item("cust_city").ToString
        Else
            MsgBox("No Customer Id Found", MsgBoxStyle.Information, gCompanyShortName)
            txtCustomerID.Text = ""
            lblcustName.Text = ""
        End If
    End Sub
    Public Sub populateShipAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lbldName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
            lbldadd1.Text = ds2.Tables(0).Rows(0).Item("ship_address1").ToString
            lbldadd2.Text = ds2.Tables(0).Rows(0).Item("ship_address2").ToString
            lbldcity.Text = ds2.Tables(0).Rows(0).Item("ship_city").ToString
        Else
            MsgBox("No shippment Address Found", MsgBoxStyle.Information, gCompanyShortName)
            txtShipmentID.Text = ""
        End If

    End Sub

    Private Sub txtScode_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtScode.KeyPress
        If Not (isAlpha(Asc(e.KeyChar)) Or isNumber(Asc(e.KeyChar))) Then
            e.KeyChar = Nothing
        End If
    End Sub


    Private Sub cmbUom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbUom.SelectedIndexChanged
        lbltxtUOM.Text = "Nos"
        If cmbUom.Text = "Nos" Then
            lbltxtUOM.Text = "MT"
        End If
        If cmbUom.Text = "MT" Then
            lbltxtUOM.Text = "Nos"
        End If
        txtUOM.Text = ""
        txtQty.Text = ""
    End Sub

    Private Sub txtQty_TextChanged(sender As Object, e As EventArgs) Handles txtQty.TextChanged
        If (cmbUom.Text = "MT" Or cmbUom.Text = "Kgs" Or cmbUom.Text = "bdl") And Val(txtItemID.Text) > 0 Then
            ds1 = getItem(CInt(txtItemID.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                If IsDBNull(ds1.Tables(0).Rows(0).Item("unitWeight")) Then
                    dblUnitWeight = 0
                Else
                    dblUnitWeight = CDbl(ds1.Tables(0).Rows(0).Item("unitWeight").ToString)
                End If
                If IsDBNull(ds1.Tables(0).Rows(0).Item("item_length")) Or ds1.Tables(0).Rows(0).Item("item_length").ToString = "" Then
                    dblLength = 0
                Else
                    dblLength = CDbl(ds1.Tables(0).Rows(0).Item("item_length").ToString)
                End If
                intBundles = CInt(ds1.Tables(0).Rows(0).Item("bundle_nos").ToString)
                If dblUnitWeight > 0 And dblLength > 0 Then
                    If cmbUom.Text = "MT" Then
                        intNos = Math.Round(Val(txtQty.Text) * 1000 / (dblUnitWeight * dblLength), 0)
                    End If
                    If cmbUom.Text = "Kgs" Then
                        intNos = Math.Round(Val(txtQty.Text) / (dblUnitWeight * dblLength), 0)
                    End If
                    If cmbUom.Text = "bdl" Then
                        intNos = Math.Round(Val(txtQty.Text) * intBundles, 0)
                    End If
                    txtUOM.Text = intNos
                End If
            End If
        End If
        If cmbUom.Text = "Nos" And Val(txtItemID.Text) > 0 Then
            ds1 = getItem(CInt(txtItemID.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                If IsDBNull(ds1.Tables(0).Rows(0).Item("unitWeight")) Then
                    dblUnitWeight = 0
                Else
                    dblUnitWeight = CDbl(ds1.Tables(0).Rows(0).Item("unitWeight").ToString)
                End If
                If IsDBNull(ds1.Tables(0).Rows(0).Item("item_length")) Or ds1.Tables(0).Rows(0).Item("item_length").ToString = "" Then
                    dblLength = 0
                Else
                    dblLength = CDbl(ds1.Tables(0).Rows(0).Item("item_length").ToString)
                End If
            End If
            If dblUnitWeight > 0 And dblLength > 0 Then
                txtUOM.Text = Format((Val(txtQty.Text) * dblUnitWeight * dblLength / 1000), "#0.000")  'mtns
            End If
        End If
    End Sub

    Private Sub cmbgoodrej_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbgoodrej.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbgoodrej.Text
        Dim typedT As String = t.Substring(0, cmbgoodrej.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbgoodrej.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub cmbItemType_KeyPress(sender As Object, e As KeyPressEventArgs) Handles cmbItemType.KeyPress
        If e.KeyChar = ControlChars.Back AndAlso e.KeyChar = ControlChars.Back Then
            Return
        End If
        Dim t As String = cmbItemType.Text
        Dim typedT As String = t.Substring(0, cmbItemType.SelectionStart)
        Dim newT As String = typedT + e.KeyChar
        Dim i As Integer = cmbItemType.FindString(newT)
        If i = -1 Then
            e.Handled = True
        End If
    End Sub
End Class