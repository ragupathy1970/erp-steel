﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 19-02-2018
' Time: 16:11
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Imports System
Imports System.Configuration
Imports System.Data
Imports System.Net
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.common
Imports VST.constants
Imports VST.Production

Partial Public Class Customer
    Dim thisScreenMode As Integer
    Dim ds As DataSet
    Dim obj As Object
    Dim intCustomerID As Integer
    Dim strSQL As String
    Dim trans As OdbcTransaction
    Public Sub New()
        ' The Me.InitializeComponent call is required for Windows Forms designer support.
        Me.InitializeComponent()

        '
        ' TODO : Add constructor code after InitializeComponents
        '
    End Sub

    Public Sub InitializeControls()
        txtCustomerNo.Text = ""
        txtCustomerName.Text = ""
        txtCustomerAdd1.Text = ""
        txtCustomerAdd2.Text = ""
        txtCustomerCity.Text = ""
        txtCustomerState.Text = ""
        txtCustomerPin.Text = ""
        txtCustomerGST.Text = ""
        txtContactPerson.Text = ""
        txtEmailId.Text = ""
        txtPhone.Text = ""
        chkIsActive.Checked = False
        EnableDisable(True)
    End Sub

    Public Sub EnableDisable(toggle As Boolean)
        txtCustomerNo.Enabled = Not toggle
        txtCustomerName.Enabled = toggle
        txtCustomerAdd1.Enabled = toggle
        txtCustomerAdd2.Enabled = toggle
        txtCustomerCity.Enabled = toggle
        txtCustomerState.Enabled = toggle
        txtCustomerPin.Enabled = toggle
        txtCustomerGST.Enabled = toggle
        txtContactPerson.Enabled = toggle
        txtEmailId.Enabled = toggle
        txtPhone.Enabled = toggle
        chkIsActive.Checked = toggle
    End Sub


    Sub CustomerLoad(sender As Object, e As EventArgs) Handles MyBase.Load
        Call InitializeControls()
        Call EnableDisable(True)
        thisScreenMode = ScreenMode.Add
    End Sub



    Public Sub saveCustomer()
        Try
            If validateCustomer() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "SELECT max(cust_id) AS customer_id FROM public.gen_Customer_Master"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        If IsDBNull(obj) Then
                            intCustomerID = 1
                        Else
                            intCustomerID = CInt(obj.ToString) + 1
                        End If
                        txtCustomerNo.Text = intCustomerID.ToString
                        trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertCustomer()
                        trans.Commit()
                    Case 2
                        Call UpdateCustomer()

                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Customer ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteCustomer()
                            trans.Commit()
                            MsgBox("Customer ID : " & txtCustomerNo.Text & " Deleted", MsgBoxStyle.Information, gCompanyShortName)
                        End If

                End Select
                Call InitializeControls()
                cmdEdit.Enabled = True
                cmdDelete.Enabled = True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub

    Sub InsertCustomer()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertCustomer(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@customerId", OdbcType.Int).Value = CInt(txtCustomerNo.Text)
            cmd.Parameters.AddWithValue("@customerName", OdbcType.NText).Value = txtCustomerName.Text.Trim
            cmd.Parameters.AddWithValue("@customerAdd1", OdbcType.NText).Value = txtCustomerAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@customerAdd2", OdbcType.NText).Value = txtCustomerAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@customerCity", OdbcType.NText).Value = txtCustomerCity.Text.Trim
            cmd.Parameters.AddWithValue("@customerState", OdbcType.NText).Value = txtCustomerState.Text.Trim
            cmd.Parameters.AddWithValue("@customerPin", OdbcType.NText).Value = txtCustomerPin.Text.Trim
            cmd.Parameters.AddWithValue("@customerGST", OdbcType.NText).Value = txtCustomerGST.Text.Trim
            cmd.Parameters.AddWithValue("@customerCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@customerEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@customerPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
            MsgBox("Customer Id : " & txtCustomerNo.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception

            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub


    Sub UpdateCustomer()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.UpdateCustomer(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@customerId", OdbcType.Int).Value = CInt(txtCustomerNo.Text)
            cmd.Parameters.AddWithValue("@customerName", OdbcType.NText).Value = txtCustomerName.Text.Trim
            cmd.Parameters.AddWithValue("@customerAdd1", OdbcType.NText).Value = txtCustomerAdd1.Text.Trim
            cmd.Parameters.AddWithValue("@customerAdd2", OdbcType.NText).Value = txtCustomerAdd2.Text.Trim
            cmd.Parameters.AddWithValue("@customerCity", OdbcType.NText).Value = txtCustomerCity.Text.Trim
            cmd.Parameters.AddWithValue("@customerState", OdbcType.NText).Value = txtCustomerState.Text.Trim
            cmd.Parameters.AddWithValue("@customerPin", OdbcType.NText).Value = txtCustomerPin.Text.Trim
            cmd.Parameters.AddWithValue("@customerGST", OdbcType.NText).Value = txtCustomerGST.Text.Trim
            cmd.Parameters.AddWithValue("@customerCotactPerson", OdbcType.NText).Value = txtContactPerson.Text.Trim
            cmd.Parameters.AddWithValue("@customerEmailId", OdbcType.NText).Value = txtEmailId.Text.Trim
            cmd.Parameters.AddWithValue("@customerPhone", OdbcType.NText).Value = txtPhone.Text.Trim
            cmd.Parameters.AddWithValue("@isActie", OdbcType.Bit).Value = IIf(chkIsActive.Checked = True, "1", "0")
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            cmd.ExecuteScalar()
            MsgBox("Customer Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteCustomer()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteCustomer(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@customerid", OdbcType.Int).Value = CInt(txtCustomerNo.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Sub populateCustomer(intCustomerNo As Integer)
        If ds.Tables(0).Rows.Count > 0 Then
            txtCustomerNo.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
            txtCustomerName.Text = ds.Tables(0).Rows(0).Item("cust_name").ToString
            txtCustomerAdd1.Text = ds.Tables(0).Rows(0).Item("cust_address1").ToString
            txtCustomerAdd2.Text = ds.Tables(0).Rows(0).Item("cust_address2").ToString
            txtCustomerCity.Text = ds.Tables(0).Rows(0).Item("cust_city").ToString
            txtCustomerState.Text = ds.Tables(0).Rows(0).Item("cust_state").ToString
            txtCustomerPin.Text = ds.Tables(0).Rows(0).Item("cust_pin").ToString
            txtCustomerGST.Text = ds.Tables(0).Rows(0).Item("cust_gst").ToString
            txtContactPerson.Text = ds.Tables(0).Rows(0).Item("cust_contact_person").ToString
            txtEmailId.Text = ds.Tables(0).Rows(0).Item("cust_emailid").ToString
            txtPhone.Text = ds.Tables(0).Rows(0).Item("cust_phone").ToString
            If ds.Tables(0).Rows(0).Item("is_active").ToString = "1" Then
                chkIsActive.Checked = True
            Else
                chkIsActive.Checked = False
            End If
        End If
    End Sub

    Sub CustomerKeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveCustomer()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Public Function validateCustomer() As Boolean
        If thisScreenMode = 2 Or thisScreenMode = 3 Then
            If txtCustomerNo.Text = "" Then
                MsgBox("Customer Id is Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        Else
            If txtCustomerName.Text = "" Then
                MsgBox("Customer Name Should Not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If txtCustomerAdd1.Text = "" Then
                MsgBox("Customer Address should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If txtCustomerCity.Text = "" Then
                MsgBox("Customer City Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If txtCustomerPin.Text = "" Then
                MsgBox("Customer Pin Should not be Empty", MsgBoxStyle.Information, gCompanyShortName)
                Return False
                Exit Function
            End If
            If Not txtEmailId.Text.Trim = "" Then
                Try
                    Dim chkemail = New Mail.MailAddress(txtEmailId.Text.Trim)
                    Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
                    Dim emailAddressMatch As Match = Regex.Match(txtEmailId.Text.Trim, pattern)
                    If emailAddressMatch.Success Then
                    Else
                        MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                        Return False
                        txtEmailId.Focus()
                        Exit Function
                    End If
                Catch ex As Exception
                    MsgBox("Invalid EmailID Please Check email address", MsgBoxStyle.Information, gCompanyShortName)
                    txtEmailId.Focus()
                    Return False
                    Exit Function
                End Try
            End If
        End If
        Return True
    End Function

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveCustomer()
    End Sub

    Private Sub txtCustomerNo_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerNo.KeyPress
        If Asc(e.KeyChar) = 13 And txtCustomerNo.Text.Trim <> "" Then
            ds = getCustomer(CInt(txtCustomerNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateCustomer(CInt(txtCustomerNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Customer ID", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerNo.Focus()
            End If

        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If

    End Sub

    Private Sub txtCustomerName_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerName.KeyPress
        If Not isAlpha(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If

    End Sub

    Private Sub txtCustomerCity_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerCity.KeyPress
        If Not isAlpha(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtCustomerState_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerState.KeyPress
        If Not isAlpha(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If

    End Sub

    Private Sub txtCustomerPin_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerPin.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If

    End Sub

    Private Sub txtCustomerGST_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerGST.KeyPress
        If Not (isNumber(Asc(e.KeyChar)) Or isAlpha(Asc(e.KeyChar))) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtContactPerson_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtContactPerson.KeyPress
        If Not isAlpha(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtPhone_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPhone.KeyPress
        If Not isNumber(Asc(e.KeyChar)) And Not Asc(e.KeyChar) = 44 Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtCustomerNo.Focus()
    End Sub

    Private Sub cmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtCustomerNo.Focus()
    End Sub

    Private Sub txtCustomerNo_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerNo.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerNo.Text = rValue.ToString
                        End If
                    End If
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub txtCustomerNo_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtCustomerNo.PreviewKeyDown
        If e.KeyCode = Keys.Tab And txtCustomerNo.Text <> "" Then
            ds = getCustomer(CInt(txtCustomerNo.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateCustomer(CInt(txtCustomerNo.Text))
                Call EnableDisable(True)
            Else
                MsgBox("No Record Found In This Customer ID", MsgBoxStyle.Information, gCompanyShortName)
                txtCustomerNo.Focus()
            End If
        End If

    End Sub
End Class
