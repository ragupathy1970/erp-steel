﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Billing
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkIsJobwork = New System.Windows.Forms.CheckBox()
        Me.cmbgoodrej = New System.Windows.Forms.ComboBox()
        Me.lbldcity = New System.Windows.Forms.Label()
        Me.lbldadd2 = New System.Windows.Forms.Label()
        Me.lbldadd1 = New System.Windows.Forms.Label()
        Me.lbldName = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtShipmentID = New System.Windows.Forms.TextBox()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.cmbItemType = New System.Windows.Forms.ComboBox()
        Me.lblcity = New System.Windows.Forms.Label()
        Me.lbladd2 = New System.Windows.Forms.Label()
        Me.lbladd1 = New System.Windows.Forms.Label()
        Me.lblcustName = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtVehicleNo = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.dtLrDate = New System.Windows.Forms.DateTimePicker()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.txtLrNo = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtPONo = New System.Windows.Forms.TextBox()
        Me.txtCustomerID = New System.Windows.Forms.TextBox()
        Me.dtInvoiceDate = New System.Windows.Forms.DateTimePicker()
        Me.txtInvoiceNo = New System.Windows.Forms.TextBox()
        Me.grpEntry = New System.Windows.Forms.GroupBox()
        Me.lbltxtUOM = New System.Windows.Forms.Label()
        Me.txtUOM = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtItemID = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtRate = New System.Windows.Forms.TextBox()
        Me.cmbUom = New System.Windows.Forms.ComboBox()
        Me.cmdAdd = New System.Windows.Forms.Button()
        Me.txtQty = New System.Windows.Forms.TextBox()
        Me.txtDescription = New System.Windows.Forms.TextBox()
        Me.txtScode = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtRemarks = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtBillDiscount = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtFrieghtCharges = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtOtherCharges = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtTotalVal = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtRoundOff = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtIGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtSGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtCGSTTotal = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTaxable = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtNetTotal = New System.Windows.Forms.TextBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.lvwSales = New System.Windows.Forms.ListView()
        Me.colSno = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colHSN = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colScode = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colItemID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDescription = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUom = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colQty = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colRate = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colValue = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colDiscount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colMt = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colNos = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colCGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colIGST = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colGoodorRej = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colSlnoKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.colUomKey = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.grpEntry.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkIsJobwork)
        Me.GroupBox1.Controls.Add(Me.cmbgoodrej)
        Me.GroupBox1.Controls.Add(Me.lbldcity)
        Me.GroupBox1.Controls.Add(Me.lbldadd2)
        Me.GroupBox1.Controls.Add(Me.lbldadd1)
        Me.GroupBox1.Controls.Add(Me.lbldName)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.txtShipmentID)
        Me.GroupBox1.Controls.Add(Me.Label36)
        Me.GroupBox1.Controls.Add(Me.cmbItemType)
        Me.GroupBox1.Controls.Add(Me.lblcity)
        Me.GroupBox1.Controls.Add(Me.lbladd2)
        Me.GroupBox1.Controls.Add(Me.lbladd1)
        Me.GroupBox1.Controls.Add(Me.lblcustName)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Controls.Add(Me.txtVehicleNo)
        Me.GroupBox1.Controls.Add(Me.Label23)
        Me.GroupBox1.Controls.Add(Me.dtLrDate)
        Me.GroupBox1.Controls.Add(Me.Label22)
        Me.GroupBox1.Controls.Add(Me.txtLrNo)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtPONo)
        Me.GroupBox1.Controls.Add(Me.txtCustomerID)
        Me.GroupBox1.Controls.Add(Me.dtInvoiceDate)
        Me.GroupBox1.Controls.Add(Me.txtInvoiceNo)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 10)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(942, 148)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        '
        'chkIsJobwork
        '
        Me.chkIsJobwork.AutoSize = True
        Me.chkIsJobwork.Location = New System.Drawing.Point(712, 120)
        Me.chkIsJobwork.Name = "chkIsJobwork"
        Me.chkIsJobwork.Size = New System.Drawing.Size(82, 20)
        Me.chkIsJobwork.TabIndex = 93
        Me.chkIsJobwork.Text = "Job Work"
        Me.chkIsJobwork.UseVisualStyleBackColor = True
        '
        'cmbgoodrej
        '
        Me.cmbgoodrej.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbgoodrej.FormattingEnabled = True
        Me.cmbgoodrej.Location = New System.Drawing.Point(629, 118)
        Me.cmbgoodrej.Name = "cmbgoodrej"
        Me.cmbgoodrej.Size = New System.Drawing.Size(81, 24)
        Me.cmbgoodrej.TabIndex = 92
        '
        'lbldcity
        '
        Me.lbldcity.Location = New System.Drawing.Point(705, 92)
        Me.lbldcity.Name = "lbldcity"
        Me.lbldcity.Size = New System.Drawing.Size(227, 15)
        Me.lbldcity.TabIndex = 91
        '
        'lbldadd2
        '
        Me.lbldadd2.Location = New System.Drawing.Point(705, 75)
        Me.lbldadd2.Name = "lbldadd2"
        Me.lbldadd2.Size = New System.Drawing.Size(227, 15)
        Me.lbldadd2.TabIndex = 90
        '
        'lbldadd1
        '
        Me.lbldadd1.Location = New System.Drawing.Point(705, 57)
        Me.lbldadd1.Name = "lbldadd1"
        Me.lbldadd1.Size = New System.Drawing.Size(227, 15)
        Me.lbldadd1.TabIndex = 89
        '
        'lbldName
        '
        Me.lbldName.Location = New System.Drawing.Point(705, 41)
        Me.lbldName.Name = "lbldName"
        Me.lbldName.Size = New System.Drawing.Size(227, 15)
        Me.lbldName.TabIndex = 88
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.Transparent
        Me.Label21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label21.Location = New System.Drawing.Point(537, 40)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(58, 19)
        Me.Label21.TabIndex = 87
        Me.Label21.Text = "Ship To"
        '
        'txtShipmentID
        '
        Me.txtShipmentID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtShipmentID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtShipmentID.Location = New System.Drawing.Point(601, 40)
        Me.txtShipmentID.Name = "txtShipmentID"
        Me.txtShipmentID.Size = New System.Drawing.Size(75, 22)
        Me.txtShipmentID.TabIndex = 4
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.Transparent
        Me.Label36.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label36.Location = New System.Drawing.Point(275, 118)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(66, 19)
        Me.Label36.TabIndex = 85
        Me.Label36.Text = "Item Type"
        '
        'cmbItemType
        '
        Me.cmbItemType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbItemType.FormattingEnabled = True
        Me.cmbItemType.Location = New System.Drawing.Point(352, 117)
        Me.cmbItemType.Name = "cmbItemType"
        Me.cmbItemType.Size = New System.Drawing.Size(265, 24)
        Me.cmbItemType.TabIndex = 84
        '
        'lblcity
        '
        Me.lblcity.Location = New System.Drawing.Point(194, 71)
        Me.lblcity.Name = "lblcity"
        Me.lblcity.Size = New System.Drawing.Size(254, 15)
        Me.lblcity.TabIndex = 76
        '
        'lbladd2
        '
        Me.lbladd2.Location = New System.Drawing.Point(194, 54)
        Me.lbladd2.Name = "lbladd2"
        Me.lbladd2.Size = New System.Drawing.Size(254, 15)
        Me.lbladd2.TabIndex = 75
        '
        'lbladd1
        '
        Me.lbladd1.Location = New System.Drawing.Point(194, 36)
        Me.lbladd1.Name = "lbladd1"
        Me.lbladd1.Size = New System.Drawing.Size(254, 15)
        Me.lbladd1.TabIndex = 74
        '
        'lblcustName
        '
        Me.lblcustName.Location = New System.Drawing.Point(194, 20)
        Me.lblcustName.Name = "lblcustName"
        Me.lblcustName.Size = New System.Drawing.Size(254, 15)
        Me.lblcustName.TabIndex = 73
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.Transparent
        Me.Label25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label25.Location = New System.Drawing.Point(524, 93)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(75, 19)
        Me.Label25.TabIndex = 60
        Me.Label25.Text = "Vehicle No."
        '
        'txtVehicleNo
        '
        Me.txtVehicleNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtVehicleNo.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtVehicleNo.Location = New System.Drawing.Point(600, 90)
        Me.txtVehicleNo.Name = "txtVehicleNo"
        Me.txtVehicleNo.Size = New System.Drawing.Size(75, 22)
        Me.txtVehicleNo.TabIndex = 8
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.Transparent
        Me.Label23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label23.Location = New System.Drawing.Point(43, 123)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(66, 19)
        Me.Label23.TabIndex = 56
        Me.Label23.Text = "L.R. Date"
        '
        'dtLrDate
        '
        Me.dtLrDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtLrDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtLrDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtLrDate.Location = New System.Drawing.Point(113, 122)
        Me.dtLrDate.Name = "dtLrDate"
        Me.dtLrDate.Size = New System.Drawing.Size(99, 22)
        Me.dtLrDate.TabIndex = 7
        Me.dtLrDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.Transparent
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label22.Location = New System.Drawing.Point(57, 99)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(53, 19)
        Me.Label22.TabIndex = 54
        Me.Label22.Text = "L.R.No."
        '
        'txtLrNo
        '
        Me.txtLrNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtLrNo.Location = New System.Drawing.Point(113, 96)
        Me.txtLrNo.Name = "txtLrNo"
        Me.txtLrNo.Size = New System.Drawing.Size(75, 22)
        Me.txtLrNo.TabIndex = 6
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label12.Location = New System.Drawing.Point(509, 16)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(88, 16)
        Me.Label12.TabIndex = 50
        Me.Label12.Text = "Invoice Date"
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label11.Location = New System.Drawing.Point(36, 21)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(72, 19)
        Me.Label11.TabIndex = 49
        Me.Label11.Text = "Invoice No."
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(57, 72)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(57, 19)
        Me.Label10.TabIndex = 48
        Me.Label10.Text = "PO No."
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label7.Location = New System.Drawing.Point(24, 48)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(81, 19)
        Me.Label7.TabIndex = 46
        Me.Label7.Text = "Customer ID"
        '
        'txtPONo
        '
        Me.txtPONo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPONo.Location = New System.Drawing.Point(114, 71)
        Me.txtPONo.Name = "txtPONo"
        Me.txtPONo.Size = New System.Drawing.Size(75, 22)
        Me.txtPONo.TabIndex = 5
        '
        'txtCustomerID
        '
        Me.txtCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCustomerID.Location = New System.Drawing.Point(114, 45)
        Me.txtCustomerID.Name = "txtCustomerID"
        Me.txtCustomerID.Size = New System.Drawing.Size(75, 22)
        Me.txtCustomerID.TabIndex = 3
        '
        'dtInvoiceDate
        '
        Me.dtInvoiceDate.Cursor = System.Windows.Forms.Cursors.Default
        Me.dtInvoiceDate.CustomFormat = "dd-MMM-yyyy"
        Me.dtInvoiceDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtInvoiceDate.Location = New System.Drawing.Point(600, 14)
        Me.dtInvoiceDate.Name = "dtInvoiceDate"
        Me.dtInvoiceDate.Size = New System.Drawing.Size(99, 22)
        Me.dtInvoiceDate.TabIndex = 2
        Me.dtInvoiceDate.Value = New Date(2018, 2, 9, 0, 0, 0, 0)
        '
        'txtInvoiceNo
        '
        Me.txtInvoiceNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtInvoiceNo.Location = New System.Drawing.Point(114, 17)
        Me.txtInvoiceNo.Name = "txtInvoiceNo"
        Me.txtInvoiceNo.Size = New System.Drawing.Size(75, 22)
        Me.txtInvoiceNo.TabIndex = 1
        '
        'grpEntry
        '
        Me.grpEntry.Controls.Add(Me.lbltxtUOM)
        Me.grpEntry.Controls.Add(Me.txtUOM)
        Me.grpEntry.Controls.Add(Me.Label3)
        Me.grpEntry.Controls.Add(Me.txtItemID)
        Me.grpEntry.Controls.Add(Me.Label33)
        Me.grpEntry.Controls.Add(Me.txtDiscount)
        Me.grpEntry.Controls.Add(Me.label13)
        Me.grpEntry.Controls.Add(Me.Label2)
        Me.grpEntry.Controls.Add(Me.Label1)
        Me.grpEntry.Controls.Add(Me.Label8)
        Me.grpEntry.Controls.Add(Me.Label6)
        Me.grpEntry.Controls.Add(Me.txtRate)
        Me.grpEntry.Controls.Add(Me.cmbUom)
        Me.grpEntry.Controls.Add(Me.cmdAdd)
        Me.grpEntry.Controls.Add(Me.txtQty)
        Me.grpEntry.Controls.Add(Me.txtDescription)
        Me.grpEntry.Controls.Add(Me.txtScode)
        Me.grpEntry.Location = New System.Drawing.Point(28, 162)
        Me.grpEntry.Name = "grpEntry"
        Me.grpEntry.Size = New System.Drawing.Size(941, 56)
        Me.grpEntry.TabIndex = 27
        Me.grpEntry.TabStop = False
        '
        'lbltxtUOM
        '
        Me.lbltxtUOM.BackColor = System.Drawing.Color.Transparent
        Me.lbltxtUOM.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lbltxtUOM.Location = New System.Drawing.Point(788, 8)
        Me.lbltxtUOM.Name = "lbltxtUOM"
        Me.lbltxtUOM.Size = New System.Drawing.Size(37, 19)
        Me.lbltxtUOM.TabIndex = 57
        Me.lbltxtUOM.Text = "Nos"
        '
        'txtUOM
        '
        Me.txtUOM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtUOM.Location = New System.Drawing.Point(788, 27)
        Me.txtUOM.Name = "txtUOM"
        Me.txtUOM.Size = New System.Drawing.Size(57, 22)
        Me.txtUOM.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label3.Location = New System.Drawing.Point(89, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 19)
        Me.Label3.TabIndex = 55
        Me.Label3.Text = "Item ID"
        '
        'txtItemID
        '
        Me.txtItemID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtItemID.Location = New System.Drawing.Point(91, 25)
        Me.txtItemID.Name = "txtItemID"
        Me.txtItemID.Size = New System.Drawing.Size(75, 22)
        Me.txtItemID.TabIndex = 10
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.Transparent
        Me.Label33.Location = New System.Drawing.Point(703, 8)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(64, 15)
        Me.Label33.TabIndex = 53
        Me.Label33.Text = "Discount"
        '
        'txtDiscount
        '
        Me.txtDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDiscount.Location = New System.Drawing.Point(706, 27)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(74, 22)
        Me.txtDiscount.TabIndex = 14
        '
        'label13
        '
        Me.label13.BackColor = System.Drawing.Color.Transparent
        Me.label13.Location = New System.Drawing.Point(625, 8)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(37, 15)
        Me.label13.TabIndex = 49
        Me.label13.Text = "Rate"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(562, 7)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 15)
        Me.Label2.TabIndex = 48
        Me.Label2.Text = "Quantity"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Location = New System.Drawing.Point(503, 6)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 19)
        Me.Label1.TabIndex = 47
        Me.Label1.Text = "UOM"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label8.Location = New System.Drawing.Point(172, 5)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 19)
        Me.Label8.TabIndex = 46
        Me.Label8.Text = "Item Description"
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label6.Location = New System.Drawing.Point(8, 5)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(53, 19)
        Me.Label6.TabIndex = 45
        Me.Label6.Text = "SCode"
        '
        'txtRate
        '
        Me.txtRate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRate.Location = New System.Drawing.Point(626, 27)
        Me.txtRate.Name = "txtRate"
        Me.txtRate.Size = New System.Drawing.Size(74, 22)
        Me.txtRate.TabIndex = 13
        '
        'cmbUom
        '
        Me.cmbUom.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbUom.FormattingEnabled = True
        Me.cmbUom.Location = New System.Drawing.Point(506, 25)
        Me.cmbUom.Name = "cmbUom"
        Me.cmbUom.Size = New System.Drawing.Size(50, 24)
        Me.cmbUom.TabIndex = 11
        '
        'cmdAdd
        '
        Me.cmdAdd.BackColor = System.Drawing.Color.DarkBlue
        Me.cmdAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdAdd.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.cmdAdd.Location = New System.Drawing.Point(848, 19)
        Me.cmdAdd.Name = "cmdAdd"
        Me.cmdAdd.Size = New System.Drawing.Size(86, 32)
        Me.cmdAdd.TabIndex = 16
        Me.cmdAdd.Text = "&Add"
        Me.cmdAdd.UseVisualStyleBackColor = False
        '
        'txtQty
        '
        Me.txtQty.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtQty.Location = New System.Drawing.Point(565, 26)
        Me.txtQty.Name = "txtQty"
        Me.txtQty.Size = New System.Drawing.Size(55, 22)
        Me.txtQty.TabIndex = 12
        '
        'txtDescription
        '
        Me.txtDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDescription.Enabled = False
        Me.txtDescription.Location = New System.Drawing.Point(173, 25)
        Me.txtDescription.Name = "txtDescription"
        Me.txtDescription.Size = New System.Drawing.Size(325, 22)
        Me.txtDescription.TabIndex = 38
        '
        'txtScode
        '
        Me.txtScode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtScode.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper
        Me.txtScode.Location = New System.Drawing.Point(10, 25)
        Me.txtScode.Name = "txtScode"
        Me.txtScode.Size = New System.Drawing.Size(75, 22)
        Me.txtScode.TabIndex = 9
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtRemarks)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.txtBillDiscount)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.txtFrieghtCharges)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.txtOtherCharges)
        Me.GroupBox3.Controls.Add(Me.Label4)
        Me.GroupBox3.Controls.Add(Me.txtTotalVal)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.txtRoundOff)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtIGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.txtSGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.txtCGSTTotal)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.txtTaxable)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.txtNetTotal)
        Me.GroupBox3.Controls.Add(Me.label14)
        Me.GroupBox3.Controls.Add(Me.lvwSales)
        Me.GroupBox3.Location = New System.Drawing.Point(28, 220)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(941, 229)
        Me.GroupBox3.TabIndex = 28
        Me.GroupBox3.TabStop = False
        '
        'txtRemarks
        '
        Me.txtRemarks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRemarks.Location = New System.Drawing.Point(69, 166)
        Me.txtRemarks.Multiline = True
        Me.txtRemarks.Name = "txtRemarks"
        Me.txtRemarks.Size = New System.Drawing.Size(295, 51)
        Me.txtRemarks.TabIndex = 23
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.Transparent
        Me.Label24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label24.Location = New System.Drawing.Point(2, 166)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 19)
        Me.Label24.TabIndex = 59
        Me.Label24.Text = "Remarks"
        '
        'txtBillDiscount
        '
        Me.txtBillDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtBillDiscount.Location = New System.Drawing.Point(277, 139)
        Me.txtBillDiscount.Name = "txtBillDiscount"
        Me.txtBillDiscount.Size = New System.Drawing.Size(87, 22)
        Me.txtBillDiscount.TabIndex = 17
        Me.txtBillDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(184, 139)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(84, 22)
        Me.Label26.TabIndex = 50
        Me.Label26.Text = "Bill Discount"
        '
        'txtFrieghtCharges
        '
        Me.txtFrieghtCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtFrieghtCharges.Location = New System.Drawing.Point(481, 139)
        Me.txtFrieghtCharges.Name = "txtFrieghtCharges"
        Me.txtFrieghtCharges.Size = New System.Drawing.Size(87, 22)
        Me.txtFrieghtCharges.TabIndex = 18
        Me.txtFrieghtCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(385, 139)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(89, 22)
        Me.Label5.TabIndex = 48
        Me.Label5.Text = "Freight Chgs."
        '
        'txtOtherCharges
        '
        Me.txtOtherCharges.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtOtherCharges.Location = New System.Drawing.Point(482, 167)
        Me.txtOtherCharges.Name = "txtOtherCharges"
        Me.txtOtherCharges.Size = New System.Drawing.Size(87, 22)
        Me.txtOtherCharges.TabIndex = 19
        Me.txtOtherCharges.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(395, 167)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 22)
        Me.Label4.TabIndex = 46
        Me.Label4.Text = "Other Chgs."
        '
        'txtTotalVal
        '
        Me.txtTotalVal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTotalVal.Enabled = False
        Me.txtTotalVal.Location = New System.Drawing.Point(482, 196)
        Me.txtTotalVal.Name = "txtTotalVal"
        Me.txtTotalVal.Size = New System.Drawing.Size(87, 22)
        Me.txtTotalVal.TabIndex = 26
        Me.txtTotalVal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(403, 196)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(72, 22)
        Me.Label20.TabIndex = 44
        Me.Label20.Text = "Total Value"
        '
        'txtRoundOff
        '
        Me.txtRoundOff.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtRoundOff.Enabled = False
        Me.txtRoundOff.ForeColor = System.Drawing.Color.Red
        Me.txtRoundOff.Location = New System.Drawing.Point(651, 169)
        Me.txtRoundOff.Name = "txtRoundOff"
        Me.txtRoundOff.Size = New System.Drawing.Size(87, 22)
        Me.txtRoundOff.TabIndex = 28
        Me.txtRoundOff.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(584, 170)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(69, 19)
        Me.Label19.TabIndex = 42
        Me.Label19.Text = "Round Off"
        '
        'txtIGSTTotal
        '
        Me.txtIGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtIGSTTotal.Enabled = False
        Me.txtIGSTTotal.Location = New System.Drawing.Point(823, 199)
        Me.txtIGSTTotal.Name = "txtIGSTTotal"
        Me.txtIGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtIGSTTotal.TabIndex = 32
        Me.txtIGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(756, 198)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(69, 19)
        Me.Label18.TabIndex = 40
        Me.Label18.Text = "IGST Total"
        '
        'txtSGSTTotal
        '
        Me.txtSGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtSGSTTotal.Enabled = False
        Me.txtSGSTTotal.Location = New System.Drawing.Point(824, 170)
        Me.txtSGSTTotal.Name = "txtSGSTTotal"
        Me.txtSGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtSGSTTotal.TabIndex = 31
        Me.txtSGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(751, 169)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(77, 19)
        Me.Label17.TabIndex = 38
        Me.Label17.Text = "SGST Total"
        '
        'txtCGSTTotal
        '
        Me.txtCGSTTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtCGSTTotal.Enabled = False
        Me.txtCGSTTotal.Location = New System.Drawing.Point(824, 141)
        Me.txtCGSTTotal.Name = "txtCGSTTotal"
        Me.txtCGSTTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtCGSTTotal.TabIndex = 30
        Me.txtCGSTTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(750, 141)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(79, 19)
        Me.Label16.TabIndex = 36
        Me.Label16.Text = "CGST Total"
        '
        'txtTaxable
        '
        Me.txtTaxable.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtTaxable.Enabled = False
        Me.txtTaxable.Location = New System.Drawing.Point(652, 140)
        Me.txtTaxable.Name = "txtTaxable"
        Me.txtTaxable.Size = New System.Drawing.Size(87, 22)
        Me.txtTaxable.TabIndex = 27
        Me.txtTaxable.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(597, 141)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(56, 19)
        Me.Label15.TabIndex = 34
        Me.Label15.Text = "Taxable "
        '
        'txtNetTotal
        '
        Me.txtNetTotal.BackColor = System.Drawing.SystemColors.Window
        Me.txtNetTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtNetTotal.Enabled = False
        Me.txtNetTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNetTotal.Location = New System.Drawing.Point(651, 199)
        Me.txtNetTotal.Name = "txtNetTotal"
        Me.txtNetTotal.Size = New System.Drawing.Size(87, 22)
        Me.txtNetTotal.TabIndex = 29
        Me.txtNetTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'label14
        '
        Me.label14.Location = New System.Drawing.Point(587, 199)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(66, 19)
        Me.label14.TabIndex = 32
        Me.label14.Text = "Net Total"
        '
        'lvwSales
        '
        Me.lvwSales.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lvwSales.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lvwSales.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.colSno, Me.colHSN, Me.colScode, Me.colItemID, Me.colDescription, Me.colUom, Me.colQty, Me.colRate, Me.colValue, Me.colDiscount, Me.colMt, Me.colNos, Me.colCGST, Me.colSGST, Me.colIGST, Me.colGoodorRej, Me.colSlnoKey, Me.colUomKey})
        Me.lvwSales.FullRowSelect = True
        Me.lvwSales.GridLines = True
        Me.lvwSales.Location = New System.Drawing.Point(8, 12)
        Me.lvwSales.MultiSelect = False
        Me.lvwSales.Name = "lvwSales"
        Me.lvwSales.Size = New System.Drawing.Size(920, 121)
        Me.lvwSales.TabIndex = 1
        Me.lvwSales.UseCompatibleStateImageBehavior = False
        Me.lvwSales.View = System.Windows.Forms.View.Details
        '
        'colSno
        '
        Me.colSno.Text = "S.No"
        Me.colSno.Width = 41
        '
        'colHSN
        '
        Me.colHSN.Text = "HSN"
        Me.colHSN.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colScode
        '
        Me.colScode.Text = "SCode"
        Me.colScode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colScode.Width = 75
        '
        'colItemID
        '
        Me.colItemID.Text = "Item ID"
        Me.colItemID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colDescription
        '
        Me.colDescription.Text = "Description"
        Me.colDescription.Width = 325
        '
        'colUom
        '
        Me.colUom.Text = "UOM"
        Me.colUom.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'colQty
        '
        Me.colQty.Text = "Qty"
        Me.colQty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.colQty.Width = 48
        '
        'colRate
        '
        Me.colRate.Text = "Rate"
        Me.colRate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colRate.Width = 70
        '
        'colValue
        '
        Me.colValue.Text = "Value"
        Me.colValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colValue.Width = 100
        '
        'colDiscount
        '
        Me.colDiscount.Text = "Discount"
        Me.colDiscount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.colDiscount.Width = 70
        '
        'colMt
        '
        Me.colMt.Text = "MT"
        Me.colMt.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colNos
        '
        Me.colNos.Text = "Nos"
        Me.colNos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colCGST
        '
        Me.colCGST.Text = "CGST"
        Me.colCGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colSGST
        '
        Me.colSGST.Text = "SGST"
        Me.colSGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colIGST
        '
        Me.colIGST.Text = "IGST"
        Me.colIGST.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'colGoodorRej
        '
        Me.colGoodorRej.Text = "Good or Rejected"
        Me.colGoodorRej.Width = 140
        '
        'colSlnoKey
        '
        Me.colSlnoKey.Text = "Slnokey"
        Me.colSlnoKey.Width = 0
        '
        'colUomKey
        '
        Me.colUomKey.Text = "uomKey"
        Me.colUomKey.Width = 0
        '
        'cmdDelete
        '
        Me.cmdDelete.BackColor = System.Drawing.Color.Red
        Me.cmdDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdDelete.Location = New System.Drawing.Point(693, 457)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(86, 32)
        Me.cmdDelete.TabIndex = 21
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.Color.HotPink
        Me.cmdCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdCancel.Location = New System.Drawing.Point(882, 457)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.Size = New System.Drawing.Size(86, 32)
        Me.cmdCancel.TabIndex = 23
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'cmdSave
        '
        Me.cmdSave.BackColor = System.Drawing.Color.Green
        Me.cmdSave.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdSave.Location = New System.Drawing.Point(789, 457)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(86, 32)
        Me.cmdSave.TabIndex = 22
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.UseVisualStyleBackColor = False
        '
        'cmdEdit
        '
        Me.cmdEdit.BackColor = System.Drawing.Color.Orange
        Me.cmdEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.cmdEdit.Location = New System.Drawing.Point(597, 456)
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.Size = New System.Drawing.Size(86, 32)
        Me.cmdEdit.TabIndex = 20
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.UseVisualStyleBackColor = False
        '
        'Billing
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(996, 499)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdEdit)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.grpEntry)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.KeyPreview = True
        Me.Name = "Billing"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Billing"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpEntry.ResumeLayout(False)
        Me.grpEntry.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Private WithEvents lblcity As System.Windows.Forms.Label
    Private WithEvents lbladd2 As System.Windows.Forms.Label
    Private WithEvents lbladd1 As System.Windows.Forms.Label
    Private WithEvents lblcustName As System.Windows.Forms.Label
    Private WithEvents Label25 As System.Windows.Forms.Label
    Private WithEvents txtVehicleNo As System.Windows.Forms.TextBox
    Private WithEvents Label23 As System.Windows.Forms.Label
    Private WithEvents dtLrDate As System.Windows.Forms.DateTimePicker
    Private WithEvents Label22 As System.Windows.Forms.Label
    Private WithEvents txtLrNo As System.Windows.Forms.TextBox
    Private WithEvents Label12 As System.Windows.Forms.Label
    Private WithEvents Label11 As System.Windows.Forms.Label
    Private WithEvents Label10 As System.Windows.Forms.Label
    Private WithEvents Label7 As System.Windows.Forms.Label
    Private WithEvents txtPONo As System.Windows.Forms.TextBox
    Private WithEvents txtCustomerID As System.Windows.Forms.TextBox
    Private WithEvents dtInvoiceDate As System.Windows.Forms.DateTimePicker
    Private WithEvents txtInvoiceNo As System.Windows.Forms.TextBox
    Friend WithEvents grpEntry As System.Windows.Forms.GroupBox
    Private WithEvents Label33 As System.Windows.Forms.Label
    Private WithEvents txtDiscount As System.Windows.Forms.TextBox
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents Label8 As System.Windows.Forms.Label
    Private WithEvents Label6 As System.Windows.Forms.Label
    Private WithEvents txtRate As System.Windows.Forms.TextBox
    Private WithEvents cmbUom As System.Windows.Forms.ComboBox
    Private WithEvents cmdAdd As System.Windows.Forms.Button
    Private WithEvents txtQty As System.Windows.Forms.TextBox
    Private WithEvents txtDescription As System.Windows.Forms.TextBox
    Private WithEvents txtScode As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Private WithEvents txtRemarks As System.Windows.Forms.TextBox
    Private WithEvents Label24 As System.Windows.Forms.Label
    Private WithEvents txtBillDiscount As System.Windows.Forms.TextBox
    Private WithEvents Label26 As System.Windows.Forms.Label
    Private WithEvents txtFrieghtCharges As System.Windows.Forms.TextBox
    Private WithEvents Label5 As System.Windows.Forms.Label
    Private WithEvents txtOtherCharges As System.Windows.Forms.TextBox
    Private WithEvents Label4 As System.Windows.Forms.Label
    Private WithEvents txtTotalVal As System.Windows.Forms.TextBox
    Private WithEvents Label20 As System.Windows.Forms.Label
    Private WithEvents txtRoundOff As System.Windows.Forms.TextBox
    Private WithEvents Label19 As System.Windows.Forms.Label
    Private WithEvents txtIGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label18 As System.Windows.Forms.Label
    Private WithEvents txtSGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label17 As System.Windows.Forms.Label
    Private WithEvents txtCGSTTotal As System.Windows.Forms.TextBox
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents txtTaxable As System.Windows.Forms.TextBox
    Private WithEvents Label15 As System.Windows.Forms.Label
    Private WithEvents txtNetTotal As System.Windows.Forms.TextBox
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents lvwSales As System.Windows.Forms.ListView
    Private WithEvents colSno As System.Windows.Forms.ColumnHeader
    Friend WithEvents colHSN As System.Windows.Forms.ColumnHeader
    Private WithEvents colScode As System.Windows.Forms.ColumnHeader
    Private WithEvents colDescription As System.Windows.Forms.ColumnHeader
    Private WithEvents colUom As System.Windows.Forms.ColumnHeader
    Friend WithEvents colQty As System.Windows.Forms.ColumnHeader
    Private WithEvents colRate As System.Windows.Forms.ColumnHeader
    Private WithEvents colValue As System.Windows.Forms.ColumnHeader
    Friend WithEvents colDiscount As System.Windows.Forms.ColumnHeader
    Friend WithEvents colCGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colSGST As System.Windows.Forms.ColumnHeader
    Friend WithEvents colIGST As System.Windows.Forms.ColumnHeader
    Private WithEvents colSlnoKey As System.Windows.Forms.ColumnHeader
    Private WithEvents colUomKey As System.Windows.Forms.ColumnHeader
    Private WithEvents cmdDelete As System.Windows.Forms.Button
    Private WithEvents cmdCancel As System.Windows.Forms.Button
    Private WithEvents cmdSave As System.Windows.Forms.Button
    Private WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents colMt As System.Windows.Forms.ColumnHeader
    Friend WithEvents colNos As System.Windows.Forms.ColumnHeader
    Private WithEvents Label3 As System.Windows.Forms.Label
    Private WithEvents txtItemID As System.Windows.Forms.TextBox
    Private WithEvents lbltxtUOM As System.Windows.Forms.Label
    Private WithEvents txtUOM As System.Windows.Forms.TextBox
    Friend WithEvents colItemID As System.Windows.Forms.ColumnHeader
    Private WithEvents Label36 As System.Windows.Forms.Label
    Private WithEvents cmbItemType As System.Windows.Forms.ComboBox
    Private WithEvents Label21 As System.Windows.Forms.Label
    Private WithEvents txtShipmentID As System.Windows.Forms.TextBox
    Private WithEvents lbldcity As System.Windows.Forms.Label
    Private WithEvents lbldadd2 As System.Windows.Forms.Label
    Private WithEvents lbldadd1 As System.Windows.Forms.Label
    Private WithEvents lbldName As System.Windows.Forms.Label
    Private WithEvents cmbgoodrej As System.Windows.Forms.ComboBox
    Friend WithEvents chkIsJobwork As System.Windows.Forms.CheckBox
    Friend WithEvents colGoodorRej As System.Windows.Forms.ColumnHeader
End Class
