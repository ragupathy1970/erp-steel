﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Text
Imports System.Data.Odbc
Imports System.Data.Odbc.OdbcConnection
Imports System.Windows.Forms
Imports System.Globalization
Imports VST.Main
Imports VST.Masters
Imports VST.Common
Imports VST.Constants
Imports VST.Production


Public Class SlitProduction
    Dim thisScreenMode As Integer
    Dim i As Integer
    Dim dblThickness As Double
    Dim strSQL As String
    Dim lvw As ListViewItem
    Dim ds As DataSet
    Dim ds1 As DataSet
    Dim ds2 As DataSet
    Dim csno As Integer = 0
    Dim cItem As Integer = 1
    Dim cactualWidth As Integer = 3
    Dim cQty As Integer = 4
    Dim obj As Object
    Dim cSlnoKey As Integer = 5
    Dim trans As OdbcTransaction
    Dim arrDelTrn() As String
    Dim intDelRecSno As Integer = 0
    Dim strDelRecSno As String = ""
    Dim intCustomerID As Integer
    Dim intItemId As Integer
    Dim dblProQty As Double


    Private Sub SlitProduction_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call InitializeControls()
        Call EnableDisable(True)
        thisScreenMode = ScreenMode.Add
    End Sub

    Sub InitializeControls()
        i = 0
        dblThickness = 0
        Call getSysDateTime()
        txtSlitId.Text = ""
        dtSlit.Value = gSysDate
        txtScode.Text = ""
        txtCoilID.Text = ""
        lblCoilName.Text = ""
        txtMachineID.Text = ""
        lblMachine.Text = ""
        txtItemId.Text = ""
        txtDescription.Text = ""
        txtWidth.Text = ""
        txtQty.Text = ""
        intDelRecSno = 0
        lvwSlit.Items.Clear()
        cmdAdd.Enabled = True
        cmdEdit.Enabled = True
        cmdCancel.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub EnableDisable(toggle As Boolean)
        txtSlitId.Enabled = Not toggle
        dtSlit.Enabled = toggle
        txtCoilID.Enabled = toggle
        txtMachineID.Enabled = toggle
        txtScode.Enabled = toggle
        txtItemId.Enabled = toggle
        txtDescription.Enabled = False
        txtWidth.Enabled = toggle
        txtQty.Enabled = toggle
    End Sub

    Private Sub cmdAdd_Click(sender As Object, e As EventArgs) Handles cmdAdd.Click
        Call addItem()
    End Sub

    Sub addItem()
        If validateItem() Then
            i += 1
            lvw = lvwSlit.Items.Add(i.ToString)
            lvw.SubItems.Add(txtItemId.Text)
            lvw.SubItems.Add(txtDescription.Text)
            lvw.SubItems.Add(txtWidth.Text)
            lvw.SubItems.Add(txtQty.Text)
            Call clearItem()
        End If
    End Sub

    Private Function validateItem() As Boolean
        If txtItemId.Text = "" Then
            MsgBox("Please Enter Item ID", MsgBoxStyle.Information, gCompanyShortName)
            txtItemId.Focus()
            Return False
            Exit Function
        End If
        If txtWidth.Text = "" Then
            MsgBox("Please Enter Width", MsgBoxStyle.Information, gCompanyShortName)
            txtWidth.Focus()
            Return False
            Exit Function
        End If
        If txtQty.Text = "" Then
            MsgBox("Please Enter Number of Slits", MsgBoxStyle.Information, gCompanyShortName)
            txtQty.Focus()
            Return False
            Exit Function
        End If
        For n = 0 To lvwSlit.Items.Count - 1
            If txtItemId.Text.Trim = lvwSlit.Items(n).SubItems(cItem).Text.Trim Then
                MsgBox("Item Already Exists in this setup", MsgBoxStyle.Information, gCompanyShortName)
                txtItemId.Focus()
                Return False
                Exit Function
            End If
        Next
        Return True
    End Function
    Public Sub clearItem()
        txtItemId.Text = ""
        txtDescription.Text = ""
        txtQty.Text = ""
        txtWidth.Text = ""
        txtQty.Text = ""
    End Sub
    Sub CmdCancel_Click(sender As Object, e As EventArgs) Handles cmdCancel.Click
        Call InitializeControls()
        thisScreenMode = ScreenMode.Add
        Call EnableDisable(True)
        cmdEdit.Enabled = True
        cmdDelete.Enabled = True
    End Sub

    Sub txtIemID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtItemId.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getSlits(0)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtItemId.Text = rValue.ToString
                        End If
                    End If

                Else
                    MsgBox("There is No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Sub TxtItemID_PreviewKeyDown(sender As Object, e As PreviewKeyDownEventArgs) Handles txtItemId.PreviewKeyDown
        If e.KeyCode = Keys.Tab Then
            If Not txtItemId.Text = "" Then
                ds1 = getSlits(CInt(txtItemId.Text))
                Call populateItemDesc(ds1)
            End If
        End If

    End Sub

    Public Sub populateItemDesc(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            txtDescription.Text = ds2.Tables(0).Rows(0).Item("item_description").ToString
        Else
            MsgBox("No Item found in this number", MsgBoxStyle.Information, gCompanyShortName)
        End If
    End Sub

    Sub TxtQty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtQty.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtWidth_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtWidth.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtItemId_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtItemId.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub


    Private Sub SlitProduction_KeyDown(sender As Object, e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.F5 Then
            Call saveSlit()
        End If
        If e.KeyCode = Keys.Enter Then
            SendKeys.Send("{TAB}")
        End If
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub
    Private Sub txtScode_keypress(sender As Object, e As KeyPressEventArgs) Handles txtScode.KeyPress
        If Not (isNumber(Asc(e.KeyChar)) Or isAlpha(Asc(e.KeyChar))) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtSlitId_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtSlitId.KeyPress
        If Asc(e.KeyChar) = 13 And Val(txtSlitId.Text) > 0 Then
            ds = getSlitHdr(CInt(txtSlitId.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                Call populateSlitHdr(CInt(txtSlitId.Text))
                Call populateSlitTrn(CInt(txtSlitId.Text))
                EnableDisable(True)
            Else
                MsgBox("No Record Found In This Slit ID", MsgBoxStyle.Information, gCompanyShortName)
                txtSlitId.Focus()
            End If
        End If
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If

    End Sub
    Sub populateSlitHdr(intSlitID)
        dtSlit.Text = ds.Tables(0).Rows(0).Item("pro_slit_dt").ToString
        txtCoilID.Text = ds.Tables(0).Rows(0).Item("item_id").ToString
        txtMachineID.Text = ds.Tables(0).Rows(0).Item("pro_machine_id").ToString
        Select Case ds.Tables(0).Rows(0).Item("pro_shift").ToString
            Case "A"
                rdoShift1.Checked = True
            Case "B"
                rdoShift2.Checked = True
            Case "C"
                rdoShift3.Checked = True
            Case Else
                rdoShift4.Checked = True
        End Select
        ds1 = getItem(Val(txtCoilID.Text))
        If ds1.Tables(0).Rows.Count > 0 Then
            lblCoilName.Text = ds1.Tables(0).Rows(0).Item("item_description").ToString
        End If
        ds1 = getMill(txtMachineID.Text)
        If ds1.Tables(0).Rows.Count > 0 Then
            lblMachine.Text = ds1.Tables(0).Rows(0).Item("mill_name").ToString
        End If
        If Val(ds.Tables(0).Rows(0).Item("is_jobwork").ToString) = 2 Then
            chkIsJobwork.Checked = True
        Else
            chkIsJobwork.Checked = False
        End If
        txtCustomerID.Text = ds.Tables(0).Rows(0).Item("cust_id").ToString
        ds1 = getCustomer(Val(txtCustomerID.Text))
        If ds1.Tables(0).Rows.Count > 0 Then
            lblCustName.Text = ds1.Tables(0).Rows(0).Item("cust_name").ToString
        End If
    End Sub
    Sub populateSlitTrn(intSlitID)
        ds = getSlitTrn(intSlitID)
        If ds.Tables(0).Rows.Count > 0 Then
            For n = 0 To ds.Tables(0).Rows.Count - 1
                lvw = lvwSlit.Items.Add(ds.Tables(0).Rows(n).Item("pro_slit_sno").ToString)
                With lvw
                    ds1 = getItem(CInt(ds.Tables(0).Rows(n).Item("pro_item_id").ToString))
                    If ds1.Tables(0).Rows.Count > 0 Then
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_id").ToString)
                        .SubItems.Add(ds1.Tables(0).Rows(0).Item("item_description").ToString)
                    End If
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_slit_width").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_qty_innos").ToString)
                    .SubItems.Add(ds.Tables(0).Rows(n).Item("pro_slit_sno").ToString)
                End With
                i += 1
            Next
        End If
    End Sub
    Private Sub txtOrderID_KeyPress(sender As Object, e As KeyPressEventArgs)
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtMachineID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtMachineID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            If Asc(e.KeyChar) = 46 Then
            Else
                e.KeyChar = Nothing
            End If
        End If
    End Sub

    Private Sub txtMachineID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMachineID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getMill(0)
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()
                    If Not String.IsNullOrEmpty(sControl.Text) Then
                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtMachineID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Machine Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub
    Private Sub txtCoilId_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCoilID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCoil()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCoilID.Text = rValue.ToString
                            lblCoilName.Text = rTagValue.ToString
                        End If
                    End If

                Else
                    MsgBox("No Item Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub

    Private Sub cmdEdit_Click(sender As Object, e As EventArgs) Handles cmdEdit.Click
        thisScreenMode = ScreenMode.Edit
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtSlitId.Focus()
    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click
        Call saveSlit()
    End Sub
    Sub saveSlit()
        Try
            If validateSlit() Then
                Call getSysDateTime()
                Select Case thisScreenMode
                    Case 1
                        strSQL = "Select nextval('pro_slit_id_seq') AS pro_slit_id"
                        obj = ODBCDataAccsess.getExecuteScalar(strSQL, ODBCDataAccsess.DbCon)
                        txtSlitId.Text = obj.ToString
                        'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                        Call InsertSlitHdr()
                        Call InsertSlitTrn()
                        'trans.Commit()
                    Case 2

                        Call updateSlitHdr()
                        Call updateSlitTrn()

                    Case 3
                        If MsgBox("Are You Sure You want to Delete this Slit Setup ?", MsgBoxStyle.YesNo, gCompanyShortName) = vbYes Then
                            'trans = ODBCDataAccsess.DbCon.BeginTransaction(IsolationLevel.ReadCommitted)
                            Call deleteSlitTrn()
                            Call deleteSlitHdr()
                            'trans.Commit()

                        End If

                End Select
                Call InitializeControls()
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Try
                trans.Rollback()
                Call InitializeControls()
            Catch ex1 As Exception
                MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            End Try
        End Try
    End Sub
    Sub InsertSlitHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.InsertSlitHdr(?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text)
            dt = Date.ParseExact(Format(CDate(dtSlit.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@proslitdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@promachineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            cmd.Parameters.AddWithValue("@proslittotal", OdbcType.Int).Value = 0
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.Parameters.AddWithValue("@procoilid", OdbcType.Int).Value = Val(txtCoilID.Text)
            cmd.Parameters.AddWithValue("@stkid", OdbcType.Text).Value = txtScode.Text
            cmd.Parameters.AddWithValue("@isjobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            If chkIsJobwork.Checked = True Then
                cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = Val(txtCustomerID.Text)
            Else
                cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = 0
            End If
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub InsertSlitTrn()
        Dim cmd As New OdbcCommand()
        Try
            For n = 0 To lvwSlit.Items.Count - 1
                cmd = ODBCDataAccsess.DbCon.CreateCommand()
                cmd.CommandText = "SELECT public.InsertSlitTrn(?,?,?,?,?)"
                cmd.CommandType = CommandType.StoredProcedure
                cmd.Transaction = trans
                cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text.Trim)
                cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(csno).Text)
                cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                cmd.Parameters.AddWithValue("@proslitwidth", OdbcType.Int).Value = Val(lvwSlit.Items(n).SubItems(cactualWidth).Text)
                cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Decimal).Value = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                cmd.ExecuteScalar()
                intCustomerID = CInt(txtCustomerID.Text)
                intItemId = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                dblProQty = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                updateReceiptInStock(intCustomerID, intItemId, dblProQty)
            Next

            MsgBox("Slit ID : " & txtSlitId.Text & " Created", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateSlitHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim dt As Date
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.updateSlitHdr(?,?,?,?,?,?,?,?,?,?,?,?,?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text)
            dt = Date.ParseExact(Format(CDate(dtSlit.Value.ToString), "dd-MMM-yyyy").ToString, "dd-MMM-yyyy", CultureInfo.InvariantCulture)
            cmd.Parameters.AddWithValue("@proslitdt", OdbcType.Date).Value = Format(dt, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@promachineid", OdbcType.Int).Value = Val(txtMachineID.Text)
            cmd.Parameters.AddWithValue("@proslittotal", OdbcType.Int).Value = 0
            cmd.Parameters.AddWithValue("@created_dt", OdbcType.Date).Value = Format(gSysDate, "yyyyMMMdd")
            cmd.Parameters.AddWithValue("@created_tm", OdbcType.Int).Value = gSysTime
            cmd.Parameters.AddWithValue("@created_by", OdbcType.Int).Value = gUserId
            cmd.Parameters.AddWithValue("@rec_status", OdbcType.Int).Value = 1
            If rdoShift1.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "A"
            ElseIf rdoShift2.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "B"
            ElseIf rdoShift3.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "C"
            ElseIf rdoShift4.Checked = True Then
                cmd.Parameters.AddWithValue("@proshift", OdbcType.Text).Value = "G"
            End If
            cmd.Parameters.AddWithValue("@procoilid", OdbcType.Int).Value = Val(txtCoilID.Text)
            cmd.Parameters.AddWithValue("@stkid", OdbcType.Text).Value = txtScode.Text
            cmd.Parameters.AddWithValue("@isjobwork", OdbcType.Int).Value = IIf(chkIsJobwork.Checked = True, 2, 1)
            If chkIsJobwork.Checked = True Then
                cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = Val(txtCustomerID.Text)
            Else
                cmd.Parameters.AddWithValue("@custid", OdbcType.Int).Value = 0
            End If
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub updateSlitTrn()
        Dim cmd As New OdbcCommand
        Dim ds1 As DataSet
        Try
            ds1 = getSlitTrn(CInt(txtSlitId.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds1.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds1.Tables(0).Rows(n).Item("pro_item_id").ToString)
                    dblProQty = Val(ds1.Tables(0).Rows(n).Item("pro_qty_innos").ToString)
                    Call subtractReceiptInStock(CInt(txtCustomerID.Text), intItemId, dblProQty)
                Next
            End If
            If intDelRecSno > 0 Then
                For n = 1 To arrDelTrn.Length - 1
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.delSlitTrn(?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@proslit", OdbcType.Int).Value = CInt(txtSlitId.Text)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = arrDelTrn(n)
                    cmd.ExecuteScalar()
                Next
            End If

            For n = 0 To lvwSlit.Items.Count - 1
                If Not lvwSlit.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.updateSlitTrn(?,?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text.Trim)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                    cmd.Parameters.AddWithValue("@proslitwidth", OdbcType.Int).Value = Val(lvwSlit.Items(n).SubItems(cactualWidth).Text)
                    cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Decimal).Value = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                    cmd.Parameters.AddWithValue("@slnokey", OdbcType.Int).Value = Val(lvwSlit.Items(n).SubItems(cSlnoKey).Text)
                    cmd.ExecuteScalar()
                    intCustomerID = CInt(txtCustomerID.Text)
                    intItemId = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                    dblProQty = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                    updateReceiptInStock(intCustomerID, intItemId, dblProQty)
                End If
            Next
            For n = 0 To lvwSlit.Items.Count - 1
                If lvwSlit.Items(n).SubItems(cSlnoKey).Text = "" Then
                    cmd = ODBCDataAccsess.DbCon.CreateCommand()
                    cmd.CommandText = "SELECT public.InsertSlitTrn(?,?,?,?,?)"
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Transaction = trans
                    cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text.Trim)
                    cmd.Parameters.AddWithValue("@prosno", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(csno).Text)
                    cmd.Parameters.AddWithValue("@itemid", OdbcType.Int).Value = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                    cmd.Parameters.AddWithValue("@proslitwidth", OdbcType.Int).Value = Val(lvwSlit.Items(n).SubItems(cactualWidth).Text)
                    cmd.Parameters.AddWithValue("@proqtyinnos", OdbcType.Decimal).Value = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                    cmd.ExecuteScalar()
                    intCustomerID = CInt(txtCustomerID.Text)
                    intItemId = CInt(lvwSlit.Items(n).SubItems(cItem).Text)
                    dblProQty = Val(lvwSlit.Items(n).SubItems(cQty).Text)
                    updateReceiptInStock(intCustomerID, intItemId, dblProQty)
                End If
            Next
            Call EnableDisable(True)
            Call InitializeControls()
            MsgBox("Slit Number Modified", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteSlitHdr()
        Try
            Dim cmd As New OdbcCommand
            Dim ds1 As DataSet
            ds1 = getSlitTrn(CInt(txtSlitId.Text))
            If ds1.Tables(0).Rows.Count > 0 Then
                For n = 0 To ds1.Tables(0).Rows.Count - 1
                    intItemId = CInt(ds1.Tables(0).Rows(n).Item("pro_item_id").ToString)
                    dblProQty = Val(ds1.Tables(0).Rows(n).Item("pro_qty_innos").ToString)
                    Call subtractReceiptInStock(CInt(txtCustomerID.Text), intItemId, dblProQty)
                Next
            End If
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.Transaction = trans
            cmd.CommandText = "SELECT public.DeleteSlitHdr(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text)
            cmd.ExecuteScalar()
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Sub deleteSlitTrn()
        Try
            Dim cmd As New OdbcCommand
            cmd = ODBCDataAccsess.DbCon.CreateCommand()
            cmd.CommandText = "SELECT public.deleteSlitTrn(?)"
            cmd.CommandType = CommandType.StoredProcedure
            cmd.Transaction = trans
            cmd.Parameters.AddWithValue("@proslitid", OdbcType.Int).Value = CInt(txtSlitId.Text)
            cmd.ExecuteScalar()
            MsgBox("Slit ID : " & txtSlitId.Text & " Deleted", MsgBoxStyle.Information, gCompanyShortName)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub
    Private Function validateSlit() As Boolean
        If thisScreenMode = ScreenMode.Edit Or thisScreenMode = ScreenMode.Delete Then
            If txtSlitId.Text = "" Then
                MsgBox("Enter Production Slit Number", MsgBoxStyle.Information, gCompanyShortName)
                txtSlitId.Focus()
                Return False
            End If
        Else
            If thisScreenMode = ScreenMode.Add Then
                If txtCoilID.Text = "" Then
                    MsgBox("Please Enter Coil ID", MsgBoxStyle.Information, gCompanyShortName)
                    txtCoilID.Focus()
                    Return False
                End If
                If txtMachineID.Text = "" Then
                    MsgBox("Please Enter Machine ID", MsgBoxStyle.Information, gCompanyShortName)
                    txtMachineID.Focus()
                    Return False
                End If
                If rdoShift1.Checked = False And rdoShift2.Checked = False And rdoShift3.Checked = False And rdoShift4.Checked = False Then
                    MsgBox("Please Select Shift", MsgBoxStyle.Information, gCompanyShortName)
                    rdoShift4.Focus()
                    Return False
                End If
            End If
            If lvwSlit.Items.Count = 0 Then
                MsgBox("Please Add Item", MsgBoxStyle.Information, gCompanyShortName)
                txtItemId.Focus()
                Return False
                Exit Function
            End If
        End If
        Return True
    End Function

    Private Sub txtMachineID_Leave(sender As Object, e As EventArgs) Handles txtMachineID.Leave
        If Val(txtMachineID.Text) > 0 Then
            ds = getMill(CInt(txtMachineID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                lblMachine.Text = ds.Tables(0).Rows(0).Item("mill_name").ToString
            Else
                MsgBox("Machine id not found", MsgBoxStyle.Information, gCompanyShortName)
                txtMachineID.Text = ""
                lblMachine.Text = ""
                Exit Sub
            End If
        End If
    End Sub


    Private Sub txtCoilID_Leave(sender As Object, e As EventArgs) Handles txtCoilID.Leave
        If Val(txtCoilID.Text) > 0 Then
            ds = getCoil(Val(txtCoilID.Text))
            If ds.Tables(0).Rows.Count > 0 Then
                lblCoilName.Text = ds.Tables(0).Rows(0).Item("item_description").ToString
            Else
                lblCoilName.Text = ""
                txtCoilID.Text = ""
                MsgBox("No coil id found", MsgBoxStyle.Information, gCompanyShortName)
                Exit Sub
            End If
        End If
    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        thisScreenMode = ScreenMode.Delete
        Call EnableDisable(False)
        cmdEdit.Enabled = False
        cmdDelete.Enabled = False
        txtSlitId.Focus()
    End Sub

    Private Sub txtCustomerID_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtCustomerID.KeyPress
        If Not isNumber(Asc(e.KeyChar)) Then
            e.KeyChar = Nothing
        End If
    End Sub

    Private Sub txtCustomerID_KeyDown(sender As Object, e As KeyEventArgs) Handles txtCustomerID.KeyDown
        If e.KeyCode = 120 Then
            Dim rValue As String
            Dim rTagValue As String
            Dim frmSearch As New Search
            Dim sControl As New Windows.Forms.Control
            Dim ds As New DataSet
            Try
                rValue = ""
                rTagValue = ""
                ds = getCustomer()
                If ds.Tables(0).Rows.Count > 0 Then
                    sControl.Text = ""
                    sControl.Tag = ""
                    Call frmSearch.FillList(ds, sControl, rValue, rTagValue)
                    frmSearch.ShowDialog()

                    If Not String.IsNullOrEmpty(sControl.Text) Then

                        If Not (sControl.Text.Trim = "" And sControl.Tag.ToString.Trim = "") Then
                            rValue = sControl.Text
                            rTagValue = sControl.Tag.ToString
                            txtCustomerID.Text = rValue.ToString
                        End If
                    End If
                Else
                    MsgBox("There is No Customer Found", MsgBoxStyle.Information, gCompanyShortName)
                End If
            Catch ex As Exception
                MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            End Try
        End If
    End Sub
    Private Sub txtCustomerID_Leave(sender As Object, e As EventArgs) Handles txtCustomerID.Leave
        If Not txtCustomerID.Text = "" Then
            ds1 = getCustomer(Val(txtCustomerID.Text))
            Call populateCustAddress(ds1)
        End If
    End Sub
    Public Sub populateCustAddress(ds2 As DataSet)
        If ds2.Tables(0).Rows.Count > 0 Then
            lblCustName.Text = ds2.Tables(0).Rows(0).Item("cust_name").ToString
        Else
            MsgBox("No Customer Id Found", MsgBoxStyle.Information, gCompanyShortName)
            txtCustomerID.Text = ""
            lblCustName.Text = ""
        End If
    End Sub

End Class
