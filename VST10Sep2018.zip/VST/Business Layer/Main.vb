﻿'
' Created by SharpDevelop.
' User: Ragupathy
' Date: 04-01-2018
' Time: 13:33
' 
' To change this template use Tools | Options | Coding | Edit Standard Headers.
'
Option Explicit On
Option Strict On 

Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Data
Imports System.Reflection
Imports VST.Main
Imports VST.Masters
Imports VST.Constants
Imports VST.configuration
Imports VST.ODBCDataAccsess

Public Class Main
	Inherits Form
	
	Public shared frmLogin As New Login
	Public shared frmVSTMain As VST
	Public frmProduction As Production
	Public frmProductionPlan As ProductionPlan
	Public frmOrder As Order
	Public frmItem As Item
	Public frmCustomer As Customer
	Public frmVendor As Vendor
    Public frmShipment As Shipment
    Public frmProductionSlit As SlitProduction
    Public frmTestReport As testReport
    Public frmPurchaseOrder As PurchaseOrder
    Public frmPurchaseReceipt As PurchaseReceipt
    Public frmIssueProduction As IssueProduction
    Public frmBilling As Billing
    Public frmStoppageDetail As StoppageDetail
    Public frmMillRolling As MillRolling
    Public frmRejection As Rejection


    Public Shared Sub Main()
		Dim DbStr As New Configuration
		Dim frmVSTMain As New VST
		Dim conString As String
		Try
			conString =  DbStr.connectionString.ToString
			Call DbConnection(conString)
			If DbCon.State = 1 Then
				'gVersion = Assembly.GetExecutingAssembly.GetName().Version.ToString
				'MsgBox(gVersion)
				Application.Run(frmLogin)
			End If
		Catch ex As Exception
			MsgBox(ex.ToString,vbCritical,gCompanyShortName)
		End Try
	End Sub

    '	Public Sub loadVST
    '		If checkUserNamePassword Then
    '			Dim dsm As New DataSet
    '			Dim frmVSTMain As New VST
    '			frmVSTMain.Text = gCompanyShortName
    '			frmVSTMain.Show
    '		Else
    '			gUserName = ""
    '			gPassword = ""
    '			frmLogin.Show
    '		End If
    '		
    '	End Sub

    Public Shared Function checkUserNamePassword() As Boolean
        Try
            If gUserName = "" And gPassword = "" Then
                Return False
            Else
                getCompanyDetails()
                If getUserNamePassword() Then
                    Dim frmVSTMain As New VST
                    frmLogin.Hide()
                    frmVSTMain.IsMdiContainer = True
                    frmVSTMain.Text = gCompanyShortName
                    frmVSTMain.Show()
                    Return True
                Else
                    MsgBox("Invalid User Name or Password", MsgBoxStyle.Information, gCompanyShortName)
                    gUserName = ""
                    gPassword = ""
                    frmLogin.Focus()
                    Return False
                    Exit Function
                End If
                Return True
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Shared Sub getCompanyDetails()
        Try
            Dim ds As New DataSet
            ds = GetCompDetails(1)
            If ds.Tables(0).Rows.Count > 0 Then
                With ds.Tables(0).Rows(0)
                    gCompanyName = .Item("comp_name").ToString
                    gCompanyShortName = .Item("comp_shortname").ToString
                    gCompanyAdd1 = .Item("comp_Add1").ToString
                    gcompanyAdd2 = .Item("comp_Add2").ToString
                    gcompanyCity = .Item("comp_city").ToString

                End With
            End If
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
        End Try
    End Sub

    Public Shared Function getUserNamePassword() As Boolean
        Dim ds As DataSet
        Try
            ds = getUserDetails(gUserName, gPassword)
            If ds.Tables(0).Rows.Count > 0 Then
                If ds.Tables(0).Rows(0).Item("is_active").ToString = "1" Then
                    With ds.Tables(0).Rows(0)
                        gUserId = CInt(.Item("user_id").ToString)
                        gUserName = .Item("user_name").ToString.Trim
                    End With
                    Return True
                Else
                    MsgBox(gUserName + " your Login Permission Denied", MsgBoxStyle.Information, gCompanyShortName)
                    Return False
                End If
            Else
                Return False
            End If

        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Information, gCompanyShortName)
            Return False
        End Try
    End Function

    Public Sub tsmi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
		Dim menuTag As String
		Try
	        menutag =DirectCast(sender, ToolStripMenuItem).Tag.ToString
	        Select Case CInt(menuTag)
	        	Case 1 
	        	Case 2 
	        		Dim frmProduction As New Production
	        		frmProduction.MdiParent = VST.ActiveForm
	        		frmProduction.IsMdiContainer = False
	        		frmProduction.Show()
	        	Case 3
	        	Case 4
                    Call Quit()
                Case 6
                    Dim frmPurchaseOrder As New PurchaseOrder
                    frmPurchaseOrder.IsMdiContainer = False
                    frmPurchaseOrder.MdiParent = VST.ActiveForm
                    frmPurchaseOrder.Show()
                Case 7
                    Dim frmPurchaseReceipt As New PurchaseReceipt
                    frmPurchaseReceipt.IsMdiContainer = False
                    frmPurchaseReceipt.MdiParent = VST.ActiveForm
                    frmPurchaseReceipt.Show()
                Case 8
                    Dim frmIssueProduction As New IssueProduction
                    frmIssueProduction.IsMdiContainer = False
                    frmIssueProduction.MdiParent = VST.ActiveForm
                    frmIssueProduction.Show()
                Case 12
                    Call Quit
	        	Case 13
	        		Dim frmorder As New Order
	        		frmorder.IsMdiContainer = False
	        		frmorder.MdiParent = VST.ActiveForm
	        		frmOrder.Show()
	        	Case 14
	        		Dim frmProductionPlan As New ProductionPlan
	        		frmProductionPlan.IsMdiContainer = False
	        		frmProductionPlan.MdiParent = VST.ActiveForm
                    frmProductionPlan.Show()
                Case 15
                    Dim frmSlitProduction As New SlitProduction
                    frmSlitProduction.IsMdiContainer = False
                    frmSlitProduction.MdiParent = VST.ActiveForm
                    frmSlitProduction.Show()
                Case 16
                    Dim frmMillRolling As New MillRolling
                    frmMillRolling.IsMdiContainer = False
                    frmMillRolling.MdiParent = VST.ActiveForm
                    frmMillRolling.Show()
                Case 18
                    Dim frmItem As New Item
	        		frmItem.MdiParent = VST.ActiveForm
	        		frmItem.IsMdiContainer = False
	        		frmItem.Show
	        	Case 19
	        		Dim frmVendor As New Vendor
	        		frmVendor.MdiParent = VST.ActiveForm
	        		frmVendor.IsMdiContainer = False
	        		frmVendor.Show
	        	Case 20
	        		Dim frmCustomer As New Customer
	        		frmCustomer.MdiParent = VST.ActiveForm
	        		frmCustomer.IsMdiContainer = False
	        		frmCustomer.Show
	        	Case 21
	        		Dim frmShipment As New Shipment
	        		frmShipment.MdiParent = VST.ActiveForm
	        		frmShipment.IsMdiContainer = False
                    frmShipment.Show()
                Case 22
                    Dim frmStoppageDetail As New StoppageDetail
                    frmStoppageDetail.MdiParent = VST.ActiveForm
                    frmStoppageDetail.IsMdiContainer = False
                    frmStoppageDetail.Show()
                Case 23
                    Dim frmBilling As New Billing
                    frmBilling.MdiParent = VST.ActiveForm
                    frmBilling.IsMdiContainer = False
                    frmBilling.Show()
                Case 24
                    Dim frmRejection As New Rejection
                    frmRejection.MdiParent = VST.ActiveForm
                    frmRejection.IsMdiContainer = False
                    frmRejection.Show()
            End Select
		Catch ex As Exception
			MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
		End Try
    End Sub

Public shared Function Quit As Boolean
	Try	
		If ODBCDataAccsess.DbCon.State = 1	Then
			ODBCDataAccsess.DbCon.Close
		End If
		Dim openForms As Integer = Application.OpenForms.Count
		Dim i As Integer
		for i = 0 To openForms-1
			 Application.OpenForms(i).Close()
		Next
		End
	Catch ex As Exception
		MsgBox(ex.Message, MsgBoxStyle.Critical,gCompanyShortName)
	End Try
	Return True
End Function


End Class
